INSERT INTO `gmarkdb`.`permissions` (`id`, `wording`, `description`, `state`) VALUES (NULL, 'Voir la page d\'inscription', 'Donne accès à la page d\'inscription', '0');
