<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home/index';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
/* customs router*/
$route['home'] = 'home/home';
$route['login_validated'] = 'dashboard/login';

$route['dashboard'] = 'dashboard/dashboard';

$route['utils'] = 'utils/utils';
$route['addcountry'] = 'utils/add_country';
$route['addcity'] = 'utils/add_city';
$route['addgender'] = 'utils/add_gender';
$route['addclass'] = 'utils/add_class';
$route['addfeetype'] = 'utils/add_feetype';
$route['addlevel'] = 'utils/add_level';
$route['addgrade'] = 'utils/add_grade';
$route['addevaluationtype'] = 'utils/add_evaluationtype';

$route['admin'] = 'admin/admin';
$route['school'] = 'admin/school';
$route['addschool'] = 'admin/add_school';
$route['academicyear'] = 'admin/academicyear';
$route['addacademicyear'] = 'admin/add_academicyear';
$route['fee'] = 'admin/fee';
$route['addfee'] = 'admin/add_fee';
$route['modalitypayment'] = 'admin/modalitypayment';
$route['blockpayment'] = 'admin/block_payment';
$route['addblockpayment'] = 'admin/add_block_payment';
$route['steppayment'] = 'admin/step_payment';
$route['addsteppayment'] = 'admin/add_step_payment';
$route['permission'] = 'admin/permission';
$route['addpermission'] = 'admin/add_permission';
$route['role'] = 'admin/role';
$route['addrole'] = 'admin/add_role';
$route['users'] = 'admin/users';
$route['adduser'] = 'admin/add_user';

$route['registration'] = 'registration/registration';
$route['student'] = 'registration/student';
$route['addstudent'] = 'registration/add_student';
$route['academicregistration'] = 'registration/academicregistration';
$route['addacademicregistration'] = 'registration/add_academicregistration';
$route['courseregistration'] = 'registration/courseregistration';
$route['registrationsummary'] = 'registration/registrationsummary';

$route['accounting'] = 'accounting/accounting';
$route['payment'] = 'accounting/payment';
$route['addpayment'] = 'accounting/add_payment';
$route['registrationrestrained'] = 'accounting/registrationrestrained';

$route['teaching'] = 'teaching/teaching';
$route['season'] = 'teaching/season';
$route['course'] = 'teaching/course';
$route['schedule'] = 'teaching/schedule';

$route['evaluation'] = 'evaluation/evaluation';
$route['marktype'] = 'evaluation/marktype';
$route['markverify'] = 'evaluation/markverify';
$route['markvalidation'] = 'evaluation/markvalidation';
$route['deliberation'] = 'evaluation/deliberation';

$route['staff'] = 'StaffController/staff';
$route['personal'] = 'StaffController/personal';
$route['post'] = 'StaffController/post';
$route['addpersonal'] = 'StaffController/add_personal';
$route['grh'] = 'StaffController/grh';

$route['reporting'] = 'reporting/reporting';
$route['classlist'] = 'reporting/classlist';
$route['minutes'] = 'reporting/minutes';
$route['markreport'] = 'reporting/markreport';
$route['paymentorder'] = 'reporting/paymentorder';
$route['payslip'] = 'reporting/payslip';
$route['statistic'] = 'reporting/statistic';
$route['registrationcertificate'] = 'reporting/registrationcertificate';
$route['certificateofemployement'] = 'reporting/certificateofemployement';

$route['backup'] = 'backup/backup';
$route['dobackup'] = 'backup/dobackup';

$route['printpaymentlist'] = 'accounting/print_payment_list';
/* customs router*/

