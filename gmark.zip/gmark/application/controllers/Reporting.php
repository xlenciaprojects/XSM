<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once( 'BaseController.php' );

class Reporting extends BaseController {

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();
        
         ini_set('magic_quotes_gpc', 0);
         
         ReportingCurrentLinkAssign($this->smarty);
         $this->smarty->assign('statusbartitle', 'Etats / Rapports');
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function reporting() {
       // show the template
        $this->smarty->view('reporting/reportingpage.tpl');
    }
    public function classlist() {
       // show the template
        $this->smarty->view('reporting/classlistpage.tpl');
    }
    public function minutes() {
       // show the template
        $this->smarty->view('reporting/minutespage.tpl');
    }
    public function markreport() {
       // show the template
        $this->smarty->view('reporting/markreportpage.tpl');
    }
    public function paymentorder() {
       // show the template
        $this->smarty->view('reporting/paymentorderpage.tpl');
    }
    public function payslip() {
       // show the template
        $this->smarty->view('reporting/payslippage.tpl');
    }
    public function statistic() {
       // show the template
        $this->smarty->view('reporting/statisticpage.tpl');
    }
    public function registrationcertificate() {
       // show the template
        $this->smarty->view('reporting/registrationcertificatepage.tpl');
    }
    public function certificateofemployement() {
       // show the template
        $this->smarty->view('reporting/certificateofemployementpage.tpl');
    }
    

}
