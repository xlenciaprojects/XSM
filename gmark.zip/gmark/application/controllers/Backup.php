<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once( 'BaseController.php' );
require_once(APPPATH . 'libraries/Backup.php');

class Backup extends BaseController {

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();

        ini_set('magic_quotes_gpc', 0);

        BackupCurrentLinkAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Sauvegarde de données');
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function backup() {
        BackupAssign($this->smarty);
        // show the template
        $this->smarty->view('backup/backuppage.tpl');
    }

    public function dobackup() {
        new BackupMySQL(array(
            'username' => 'root',
            'passwd' => 'mysql',
            'dbname' => 'gmarkdb'
        ));
        
            
        // show the template
        $this->smarty->view('backup/backuppage.tpl');
    }

}
