<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once( 'BaseController.php' );

class Evaluation extends BaseController {

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();
        
         ini_set('magic_quotes_gpc', 0);
         
         EvaluationCurrentLinkAssign($this->smarty);
         $this->smarty->assign('statusbartitle', 'Evaluation');
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function evaluation() {
       // show the template
        $this->smarty->view('evaluation/evaluationpage.tpl');
    }
    public function marktype() {
       // show the template
        $this->smarty->view('evaluation/marktypepage.tpl');
    }
    public function markverify() {
       // show the template
        $this->smarty->view('evaluation/markverifypage.tpl');
    }
    public function markvalidation() {
       // show the template
        $this->smarty->view('evaluation/markvalidationpage.tpl');
    }
    public function deliberation() {
       // show the template
        $this->smarty->view('evaluation/deliberationpage.tpl');
    }

}
