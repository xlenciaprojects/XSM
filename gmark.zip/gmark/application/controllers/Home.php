<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
require_once( 'BaseController.php' );
/**
 * @property CI_Loader $load
 * @property CI_Form_validation $form_validation
 * @property CI_Input $input
 * @property CI_Email $email
 * @property Mysmarty $mysmarty
 */
class Home extends BaseController {

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function index() {
        // basic assignment for passing data to template file
        $this->smarty->assign('css_url', './assets/css/');
        $this->smarty->assign('js_url', './assets/js/');
        $this->smarty->assign('register', anchor('/login_validated', 'S\'enrégistrer', 'class="btn btn-primary"'));
        $this->smarty->assign('login', 'index.php/login_validated');
        $this->smarty->assign('loginTitle', "Admin");
        $this->session->sess_destroy();

        // show the template
        $this->smarty->view('login/loginpage.tpl');
    }

    public function home() {
        // basic assignment for passing data to template file
        $this->smarty->assign('register', anchor('/login_validated', 'S\'enrégistrer', 'class="btn btn-primary"'));
        $this->smarty->assign('login', 'login_validated');
        $this->smarty->assign('loginTitle', "Admin");
        $this->session->sess_destroy();
        // show the template
        $this->smarty->view('login/loginpage.tpl');
    }

}
