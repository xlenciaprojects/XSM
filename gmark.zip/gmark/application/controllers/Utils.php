<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once( 'BaseController.php' );

use serviceImpl\CountryService,
    serviceImpl\CityService,
    serviceImpl\GenderService,
    serviceImpl\ClassesService,
    serviceImpl\FeeTypeService,
    serviceImpl\EvaluationTypeService,
    serviceImpl\LevelService,
    serviceImpl\GradeService,
    entities\Country,
    entities\City,
    entities\Gender,
    entities\Classes,
    entities\FeeType,
    entities\EvaluationType,
    entities\Grade,
    entities\Level
;

require_once(APPPATH . 'models/serviceImpl/CountryService.php');
require_once(APPPATH . 'models/serviceImpl/CityService.php');
require_once(APPPATH . 'models/serviceImpl/GenderService.php');
require_once(APPPATH . 'models/serviceImpl/ClassesService.php');
require_once(APPPATH . 'models/serviceImpl/FeeTypeService.php');
require_once(APPPATH . 'models/serviceImpl/EvaluationTypeService.php');
require_once(APPPATH . 'models/serviceImpl/GradeService.php');
require_once(APPPATH . 'models/serviceImpl/LevelService.php');

class Utils extends BaseController {

    private $countryService;
    private $cityService;
    private $genderService;
    private $classService;
    private $feeTypeService;
    private $evaluationTypeService;
    private $gradeService;
    private $levelService;
    private $country;
    private $city;
    private $gender;
    private $class;
    private $feetype;
    private $evaluationtype;
    private $grade;
    private $level;
    private $country_datalist;
    private $city_datalist;
    private $gender_datalist;
    private $class_datalist;
    private $feetype_datalist;
    private $evaluationtype_datalist;
    private $grade_datalist;
    private $level_datalist;
    private $entity;

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();

        ini_set('magic_quotes_gpc', 0);
        
        CountryFormAssign($this->smarty);
        CityFormAssign($this->smarty);
        GenderFormAssign($this->smarty);
        ClassFormAssign($this->smarty);
        FeeTypeFormAssign($this->smarty);
        EvaluationTypeFormAssign($this->smarty);
        GradeFormAssign($this->smarty);
        LevelFormAssign($this->smarty);
        
        UtilsCurrentLinkAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Données de base');

        $this->countryService = new CountryService("Country");
        $this->cityService = new CityService("City");
        $this->classService = new ClassesService("Classes");
        $this->genderService = new GenderService("Gender");
        $this->feeTypeService = new FeeTypeService("FeeType");
        $this->evaluationTypeService = new EvaluationTypeService("EvaluationType");
        $this->gradeService = new GradeService("Grade");
        $this->levelService = new LevelService("Level");
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function utils() {
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("classdatalist", $this->list_class());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        $this->smarty->assign("evaluationtypedatalist", $this->list_evaluationtype());
        $this->smarty->assign("gradedatalist", $this->list_grade());
        $this->smarty->assign("leveldatalist", $this->list_level());
        
        UtilsTabCurrentLinkAssign($this->smarty, "localitychecked");
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //Country
    //add a new country to the database
    public function add_country() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(CountryFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $wording = htmlspecialchars($_POST["countrywording"]);
            $shortWording = htmlspecialchars($_POST["countryshortwording"]);
            $code = htmlspecialchars($_POST["countrycode"]);
            $nationality = htmlspecialchars($_POST["countrynationality"]);

            if ($this->session->userdata('id') > 0) {
                $this->entity = $this->crud->find($this->countryService, $this->session->userdata('id'));
                $this->entity->setWording($wording);
                $this->entity->setShortWording($shortWording);
                $this->entity->setCode($code);
                $this->entity->setNationality($nationality);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->countryService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("id", 0);
                CountryAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                CountryAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $this->country = new Country($wording, $shortWording, $code, $nationality, $this->getNormalStatus());
                //proccess to add a new contry to database
                $this->crud->create($this->countryService, $this->country);
                $this->smarty->assign("success", "Enrégistrement du pays " . $wording . " éffectué avec succès ");
                CountryAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_country($country_id = '') {
        $this->entity = $this->crud->find($this->countryService, $country_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("id", $this->entity->getId());
            $this->smarty->assign("countrywordingvalue", $this->entity->getWording());
            $this->smarty->assign("countryshortwordingvalue", $this->entity->getShortWording());
            $this->smarty->assign("countrycodevalue", $this->entity->getCode());
            $this->smarty->assign("countrynationalityvalue", $this->entity->getNationality());
        }
        CountryEditAssign($this->smarty);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_country($country_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->countryService, $country_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        CountryDeleteAssign($this->smarty);
        $this->session->set_userdata("id", 0);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //list the country data from the database
    public function list_country() {
        $this->country_datalist = $this->crud->build_entity_object_list_sort_asc($this->countryService,"wording");
        return $this->country_datalist;
    }

    //City
    //add a new city to the database
    public function add_city() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(CityFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $wording = htmlspecialchars($_POST["citywording"]);
            $description = htmlspecialchars($_POST["citydescription"]);
            $country_id = htmlspecialchars($_POST["citycountry"]);
            $country = $this->crud->find($this->countryService, $country_id);

            if ($this->session->userdata('city_id') > 0) {
                $this->entity = $this->crud->find($this->cityService, $this->session->userdata('city_id'));
                $this->entity->setWording($wording);
                $this->entity->setDescription($description);
                $this->entity->setCountry($country);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->cityService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("city_id", 0);
                $this->smarty->assign("selected", "");
                CityAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                CityAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $this->city = new City($wording, $description, $this->getNormalStatus(), $country);
                //proccess to add a new contry to database
                $this->crud->create($this->cityService, $this->city);
                $this->smarty->assign("success", "Enrégistrement du pays " . $wording . " éffectué avec succès ");
                CityAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_city($city_id = '') {
        $this->entity = $this->crud->find($this->cityService, $city_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("city_id", $this->entity->getId());
            $this->smarty->assign("citywordingvalue", $this->entity->getWording());
            $this->smarty->assign("citydescriptionvalue", $this->entity->getDescription());
            $this->smarty->assign("selected", $this->entity->getCountry()->getId());
        }
        CityEditAssign($this->smarty);
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_city($city_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->cityService, $city_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        $this->session->set_userdata("city_id", 0);
        CityDeleteAssign($this->smarty);
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //list the country data from the database
    public function list_city() {
        $this->city_datalist = $this->crud->build_entity_object_list_sort_asc($this->cityService,"wording");
        return $this->city_datalist;
    }

    //Gender
    //add a new gender to the database
    public function add_gender() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(GenderFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $long_wording = htmlspecialchars($_POST["genderlongwording"]);
            $medium_wording = htmlspecialchars($_POST["gendermediumwording"]);
            $short_wording = htmlspecialchars($_POST["gendershortwording"]);

            if ($this->session->userdata('gender_id') > 0) {
                $this->entity = $this->crud->find($this->genderService, $this->session->userdata('gender_id'));
                $this->entity->setLong_wording($long_wording);
                $this->entity->setMedium_wording($medium_wording);
                $this->entity->setShort_wording($short_wording);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->genderService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("gender_id", 0);
                GenderAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                GenderAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $this->gender = new Gender($long_wording, $medium_wording, $short_wording, $this->getNormalStatus());
                //proccess to add a new contry to database
                $this->crud->create($this->genderService, $this->gender);
                $this->smarty->assign("success", "Enrégistrement du pays " . $long_wording . " éffectué avec succès ");
                GenderAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_gender($gender_id = '') {
        $this->entity = $this->crud->find($this->genderService, $gender_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("gender_id", $this->entity->getId());
            $this->smarty->assign("genderlongwordingvalue", $this->entity->getLong_wording());
            $this->smarty->assign("gendermediumwordingvalue", $this->entity->getMedium_wording());
            $this->smarty->assign("gendershortwordingvalue", $this->entity->getShort_wording());
        }
        GenderEditAssign($this->smarty);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_gender($gender_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->genderService, $gender_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        GenderDeleteAssign($this->smarty);
        $this->session->set_userdata("gender_id", 0);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("leveldatalist", $this->list_level());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //list the country data from the database
    public function list_gender() {
        $this->gender_datalist = $this->crud->build_entity_object_list_sort_asc($this->genderService,"long_wording");
        return $this->gender_datalist;
    }
    
    //Classes
    //add a new class to the database
    public function add_class() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(ClassFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $long_wording = htmlspecialchars($_POST["classlongwording"]);
            $medium_wording = htmlspecialchars($_POST["classmediumwording"]);
            $short_wording = htmlspecialchars($_POST["classshortwording"]);
            $level_id = htmlspecialchars($_POST["classlevel"]);
            $level = $this->crud->find($this->levelService, $level_id);
            $description = htmlspecialchars($_POST["classdescription"]);

            if ($this->session->userdata('class_id') > 0) {
                $this->entity = $this->crud->find($this->classService, $this->session->userdata('class_id'));
                $this->entity->setLong_wording($long_wording);
                $this->entity->setMedium_wording($medium_wording);
                $this->entity->setShort_wording($short_wording);
                $this->entity->setLevel($level);
                $this->entity->setDescription($description);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->genderService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("class_id", 0);
                ClassAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                ClassAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $this->class = new Classes($long_wording, $medium_wording, $short_wording, $description, $level, $this->getNormalStatus());
                //proccess to add a new contry to database
                $this->crud->create($this->classService, $this->class);
                $this->smarty->assign("success", "Enrégistrement de la classe " . $long_wording . " éffectué avec succès ");
                ClassAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("classdatalist", $this->list_class());
        $this->smarty->assign("leveldatalist", $this->list_level());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_class($class_id = '') {
        $this->entity = $this->crud->find($this->classService, $class_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("class_id", $this->entity->getId());
            $this->smarty->assign("classlongwordingvalue", $this->entity->getLong_wording());
            $this->smarty->assign("classmediumwordingvalue", $this->entity->getMedium_wording());
            $this->smarty->assign("classshortwordingvalue", $this->entity->getShort_wording());
            $this->smarty->assign("classdescriptionvalue", $this->entity->getDescription());
            $this->smarty->assign("selected", $this->entity->getLevel()->getId());
        }
        ClassEditAssign($this->smarty);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("classdatalist", $this->list_class());
        $this->smarty->assign("leveldatalist", $this->list_level());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_class($class_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->classService, $class_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        ClassDeleteAssign($this->smarty);
        $this->session->set_userdata("class_id", 0);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("leveldatalist", $this->list_level());
        $this->smarty->assign("classdatalist", $this->list_class());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //list the country data from the database
    public function list_class() {
        $this->class_datalist = $this->crud->build_entity_object_list_sort_asc($this->classService,"long_wording");
        return $this->class_datalist;
    }

 //FeeType
    //add a new country to the database
    public function add_feetype() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(FeeTypeFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $wording = htmlspecialchars($_POST["feetypewording"]);
            $code = htmlspecialchars($_POST["feetypecode"]);
            $description = htmlspecialchars($_POST["feetypedescription"]);

            if ($this->session->userdata('feetype_id') > 0) {
                $this->entity = $this->crud->find($this->feeTypeService, $this->session->userdata('feetype_id'));
                $this->entity->setWording($wording);
                $this->entity->setCode($code);
                $this->entity->setDescription($description);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->feeTypeService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("feetype_id", 0);
                FeeTypeAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                FeeTypeAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $this->feetype = new FeeType($wording, $code, $description, $this->getNormalStatus());
                //proccess to add a new contry to database
                $this->crud->create($this->feeTypeService, $this->feetype);
                $this->smarty->assign("success", "Enrégistrement du type de frais " . $wording . " éffectué avec succès ");
                FeeTypeAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_feetype($feetype_id = '') {
        $this->entity = $this->crud->find($this->feeTypeService, $feetype_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("feetype_id", $this->entity->getId());
            $this->smarty->assign("feetypewordingvalue", $this->entity->getWording());
            $this->smarty->assign("feetypecodevalue", $this->entity->getCode());
            $this->smarty->assign("feetypedescriptionvalue", $this->entity->getDescription());
        }
        FeeTypeEditAssign($this->smarty);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_feetype($feetype_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->feeTypeService, $feetype_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        FeeTypeDeleteAssign($this->smarty);
        $this->session->set_userdata("feetype_id", 0);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //list the country data from the database
    public function list_feetype() {
        $this->feetype_datalist = $this->crud->build_entity_object_list_sort_asc($this->feeTypeService,"wording");
        return $this->feetype_datalist;
    }

 //EvaluationType
    //add a new country to the database
    public function add_evaluationtype() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(EvaluationTypeFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $wording = htmlspecialchars($_POST["evaluationtypewording"]);
            $code = htmlspecialchars($_POST["evaluationtypecode"]);
            $description = htmlspecialchars($_POST["evaluationtypedescription"]);

            if ($this->session->userdata('evaluationtype_id') > 0) {
                $this->entity = $this->crud->find($this->evaluationTypeService, $this->session->userdata('evaluationtype_id'));
                $this->entity->setWording($wording);
                $this->entity->setCode($code);
                $this->entity->setDescription($description);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->evaluationTypeService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("feetype_id", 0);
                EvaluationTypeAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                EvaluationTypeAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $this->evaluationtype = new EvaluationType($wording, $code, $description, $this->getNormalStatus());
                //proccess to add a new contry to database
                $this->crud->create($this->evaluationTypeService, $this->evaluationtype);
                $this->smarty->assign("success", "Enrégistrement du pays " . $wording . " éffectué avec succès ");
                EvaluationTypeAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        $this->smarty->assign("evaluationtypedatalist", $this->list_evaluationtype());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_evaluationtype($evaluationtype_id = '') {
        $this->entity = $this->crud->find($this->evaluationTypeService, $evaluationtype_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("evaluationtype_id", $this->entity->getId());
            $this->smarty->assign("evaluationtypewordingvalue", $this->entity->getWording());
            $this->smarty->assign("evaluationtypecodevalue", $this->entity->getCode());
            $this->smarty->assign("evaluationtypedescriptionvalue", $this->entity->getDescription());
        }
        EvaluationTypeEditAssign($this->smarty);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        $this->smarty->assign("evaluationtypedatalist", $this->list_evaluationtype());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_evaluationtype($evaluationtype_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->evaluationTypeService, $evaluationtype_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        CountryDeleteAssign($this->smarty);
        CityDeleteAssign($this->smarty);
        GenderDeleteAssign($this->smarty);
        FeeTypeDeleteAssign($this->smarty);
        EvaluationTypeDeleteAssign($this->smarty);
        $this->session->set_userdata("evaluationtype_id", 0);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        $this->smarty->assign("evaluationtypedatalist", $this->list_evaluationtype());
        $this->smarty->assign("gradedatalist", $this->list_grade());
        $this->smarty->assign("leveldatalist", $this->list_level());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //list the country data from the database
    public function list_evaluationtype() {
        $this->evaluationtype_datalist = $this->crud->build_entity_object_list_sort_asc($this->evaluationTypeService,"wording");
        return $this->evaluationtype_datalist;
    }
 //Grade
    //add a new country to the database
    public function add_grade() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(GradeFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $wording = htmlspecialchars($_POST["gradewording"]);
            $code = htmlspecialchars($_POST["gradecode"]);
            $description = htmlspecialchars($_POST["gradedescription"]);

            if ($this->session->userdata('grade_id') > 0) {
                $this->entity = $this->crud->find($this->gradeService, $this->session->userdata('grade_id'));
                $this->entity->setWording($wording);
                $this->entity->setCode($code);
                $this->entity->setDescription($description);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->gradeService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("grade_id", 0);
                GradeAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                GradeAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $this->grade = new Grade($wording, $code, $description, $this->getNormalStatus());
                //proccess to add a new contry to database
                $this->crud->create($this->gradeService, $this->grade);
                $this->smarty->assign("success", "Enrégistrement du pays " . $wording . " éffectué avec succès ");
                GradeAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        $this->smarty->assign("evaluationtypedatalist", $this->list_evaluationtype());
        $this->smarty->assign("gradedatalist", $this->list_grade());
        $this->smarty->assign("leveldatalist", $this->list_level());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_grade($grade_id = '') {
        $this->entity = $this->crud->find($this->gradeService, $grade_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("grade_id", $this->entity->getId());
            $this->smarty->assign("gradewordingvalue", $this->entity->getWording());
            $this->smarty->assign("gradecodevalue", $this->entity->getCode());
            $this->smarty->assign("gradedescriptionvalue", $this->entity->getDescription());
        }
        GradeEditAssign($this->smarty);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        $this->smarty->assign("evaluationtypedatalist", $this->list_evaluationtype());
        $this->smarty->assign("gradedatalist", $this->list_grade());
        $this->smarty->assign("leveldatalist", $this->list_level());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_grade($grade_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->gradeService, $grade_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        CountryDeleteAssign($this->smarty);
        CityDeleteAssign($this->smarty);
        GenderDeleteAssign($this->smarty);
        FeeTypeDeleteAssign($this->smarty);
        EvaluationTypeDeleteAssign($this->smarty);
        GradeDeleteAssign($this->smarty);
        LevelDeleteAssign($this->smarty);
        $this->session->set_userdata("grade_id", 0);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        $this->smarty->assign("evaluationtypedatalist", $this->list_evaluationtype());
        $this->smarty->assign("gradedatalist", $this->list_grade());
        $this->smarty->assign("leveldatalist", $this->list_level());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //list the country data from the database
    public function list_grade() {
        $this->grade_datalist = $this->crud->build_entity_object_list_sort_asc($this->gradeService,"wording");
        return $this->grade_datalist;
    }
 //Level
    //add a new country to the database
    public function add_level() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(LevelFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $wording = htmlspecialchars($_POST["levelwording"]);
            $code = htmlspecialchars($_POST["levelcode"]);
            $description = htmlspecialchars($_POST["leveldescription"]);

            if ($this->session->userdata('level_id') > 0) {
                $this->entity = $this->crud->find($this->levelService, $this->session->userdata('level_id'));
                $this->entity->setWording($wording);
                $this->entity->setCode($code);
                $this->entity->setDescription($description);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->levelService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("level_id", 0);
                LevelAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                LevelAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $this->level = new Level($wording, $code, $description, $this->getNormalStatus());
                //proccess to add a new contry to database
                $this->crud->create($this->levelService, $this->level);
                $this->smarty->assign("success", "Enrégistrement du pays " . $wording . " éffectué avec succès ");
                LevelAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        $this->smarty->assign("evaluationtypedatalist", $this->list_evaluationtype());
        $this->smarty->assign("gradedatalist", $this->list_grade());
        $this->smarty->assign("leveldatalist", $this->list_level());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_level($level_id = '') {
        $this->entity = $this->crud->find($this->levelService, $level_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("level_id", $this->entity->getId());
            $this->smarty->assign("levelwordingvalue", $this->entity->getWording());
            $this->smarty->assign("levelcodevalue", $this->entity->getCode());
            $this->smarty->assign("leveldescriptionvalue", $this->entity->getDescription());
        }
        LevelEditAssign($this->smarty);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        $this->smarty->assign("evaluationtypedatalist", $this->list_evaluationtype());
        $this->smarty->assign("gradedatalist", $this->list_grade());
        $this->smarty->assign("leveldatalist", $this->list_level());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_level($level_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->levelService, $level_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        CountryDeleteAssign($this->smarty);
        CityDeleteAssign($this->smarty);
        GenderDeleteAssign($this->smarty);
        FeeTypeDeleteAssign($this->smarty);
        EvaluationTypeDeleteAssign($this->smarty);
        GradeDeleteAssign($this->smarty);
        LevelDeleteAssign($this->smarty);
        $this->session->set_userdata("level_id", 0);
        $this->smarty->assign("datalist", $this->list_country());
        $this->smarty->assign("citydatalist", $this->list_city());
        $this->smarty->assign("genderdatalist", $this->list_gender());
        $this->smarty->assign("feetypedatalist", $this->list_feetype());
        $this->smarty->assign("evaluationtypedatalist", $this->list_evaluationtype());
        $this->smarty->assign("gradedatalist", $this->list_grade());
        $this->smarty->assign("leveldatalist", $this->list_level());
        // show the template
        $this->smarty->view('utils/utilspage.tpl');
    }

    //list the country data from the database
    public function list_level() {
        $this->level_datalist = $this->crud->build_entity_object_list_sort_asc($this->levelService,"wording");
        return $this->level_datalist;
    }

}