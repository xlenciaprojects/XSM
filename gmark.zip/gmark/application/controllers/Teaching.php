<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once( 'BaseController.php' );

class Teaching extends BaseController {

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();
        
         ini_set('magic_quotes_gpc', 0);
         
         TeachingCurrentLinkAssign($this->smarty);
         $this->smarty->assign('statusbartitle', 'Enseignement');
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function teaching() {
       // show the template
        $this->smarty->view('teaching/teachingpage.tpl');
    }
    public function season() {
       // show the template
        $this->smarty->view('teaching/seasonpage.tpl');
    }
    public function course() {
       // show the template
        $this->smarty->view('teaching/coursepage.tpl');
    }
    public function schedule() {
       // show the template
        $this->smarty->view('teaching/schedulepage.tpl');
    }

}
