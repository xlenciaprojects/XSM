<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once( 'BaseController.php' );

use serviceImpl\AcademicYearService,
    serviceImpl\StudentService,
    serviceImpl\FeeService,
    serviceImpl\ModalityPaymentService,
    serviceImpl\StepPaymentService,
    serviceImpl\PaymentService,
    entities\Student,
    entities\AcademicYear,
    entities\BlockPayment,
    entities\StepPayment,
    entities\Payment,
    entities\Fee

;

require_once(APPPATH . 'models/serviceImpl/AcademicYearService.php');
require_once(APPPATH . 'models/serviceImpl/StudentService.php');
require_once(APPPATH . 'models/serviceImpl/FeeService.php');
require_once(APPPATH . 'models/serviceImpl/ModalityPaymentService.php');
require_once(APPPATH . 'models/serviceImpl/StepPaymentService.php');
require_once(APPPATH . 'models/serviceImpl/PaymentService.php');

require_once(APPPATH . 'libraries/PhpToPDF.php');

class Accounting extends BaseController {

    private $studentService;
    private $academicYearService;
    private $feeService;
    private $paymentService;
    private $stepPaymentService;
    private $student;
    private $academic_year;
    private $fee;
    private $modalityPayment;
    private $stepPayment;
    private $payment;
    private $student_datalist;
    private $academic_year_datalist;
    private $fee_datalist;
    private $block_payment_datalist;
    private $step_payment_datalist;
    private $entity;
    private $phpToPDF;

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();

        ini_set('magic_quotes_gpc', 0);

        AccountingCurrentLinkAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Comptabilité : Paiement');
        $this->smarty->assign('addnewlabel', '');

        $this->studentService = new StudentService("Student");
        $this->academicYearService = new AcademicYearService("AcademicYear");
        $this->feeService = new FeeService("Fee");
        $this->modalityPaymentService = new ModalityPaymentService("ModalityPayment");
        $this->stepPaymentService = new StepPaymentService("StepPayment");
        $this->paymentService = new PaymentService("Payment");
        $this->phpToPDF = new phpToPDF();
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function accounting() {
        // show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }

//Payment
    public function payment() {
        PaymentAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Comptabilité: Liste des Paiements');
        $this->smarty->assign("studentdatalist", $this->studentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("paymentdatalist", $this->paymentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("modalitypaymentdatalist", $this->modalityPaymentService->getAllModality());

// show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }

    public function payment_form() {
        $this->smarty->assign('statusbartitle', 'Comptabilité: Paiement');
        $this->smarty->assign("studentdatalist", $this->studentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("paymentdatalist", $this->paymentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("modalitypaymentdatalist", $this->modalityPaymentService->getAllModality());
        PaymentFormAssign($this->smarty);
// show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }
    
    public function schoolfee_form() {
        SchoolFeeFormAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Comptabilité: Frais de scolarité');
        $this->smarty->assign('testlink', '../accounting/student_test/');
        $this->smarty->assign("studentdatalist", $this->studentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("paymentdatalist", $this->paymentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("modalitypaymentdatalist", $this->modalityPaymentService->getAllModality());
        
// show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }
    
    public function schoolfee_test_form() {
        SchoolFeeTestFormAssign($this->smarty);
        $this->smarty->assign('testlink', '../student_test/');
        $this->smarty->assign('statusbartitle', 'Comptabilité: Frais de scolarité');
        $this->smarty->assign("studentdatalist", $this->studentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("paymentdatalist", $this->paymentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("modalitypaymentdatalist", $this->modalityPaymentService->getAllModality());
        
// show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }
    
    public function registrationfee_form() {
        RegistrationFeeFormAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Comptabilité: Frais d\'inscription');
        $this->smarty->assign("studentdatalist", $this->studentService->getAllForRegistrationFeePayment($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("paymentdatalist", $this->paymentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("modalitypaymentdatalist", $this->modalityPaymentService->getAllModality());
        
// show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }

    public function add_payment() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(PaymentFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign('statusbartitle', 'Comptabilité: Liste des Paiements');
            $this->smarty->assign("paymentdatalist", $this->paymentService->getAllValidatedWithSortAndOrder("", ""));
            $this->smarty->assign("studentdatalist", $this->studentService->getAllValidatedWithSortAndOrder("", ""));
            $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
            $this->smarty->assign("modalitypaymentdatalist", $this->modalityPaymentService->getAllModality());
            PaymentFallFormAssign($this->smarty);
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $amount_paid = htmlspecialchars($_POST["amountpaid"]);
            $rest_to_paid = htmlspecialchars($_POST["resttopaid"]);
            $payment_date = date("d/m/Y H:i:s");
            $student_id = htmlspecialchars($_POST["paymentstudent"]);
            $fee_id = substr(htmlspecialchars($_POST["paymentfee"]), 0, 1);
            $modality_payment_id = htmlspecialchars($_POST["paymentmodalitypayment"]);
            //create an country object
            $this->payment = Array($student_id, $fee_id, $modality_payment_id, $this->getAcademic_year_activated()->getId(), $amount_paid, $rest_to_paid, $payment_date, $this->getNormalStatus());
            //proccess to add a new contry to database
            $this->paymentService->saveOne($this->payment);
            $this->smarty->assign("success", "Enrégistrement du frais éffectué avec succès ");
            PaymentAddAssign($this->smarty);
        }

        $this->smarty->assign("paymentdatalist", $this->paymentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("studentdatalist", $this->studentService->getAllValidatedWithSortAndOrder("", ""));
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("modalitypaymentdatalist", $this->modalityPaymentService->getAllModality());
        $this->smarty->assign('statusbartitle', 'Administration:Modalité de paiement');
        // show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function restore_payment($payment_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->paymentService->restoreOne($payment_id);
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        PaymentRestoreAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Comptabilité: Liste des Paiements');
        $this->smarty->assign("paymentdatalist", $this->paymentService->getAllValidatedWithSortAndOrder("", ""));

        // show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }

    //update the status of the current country data to the database
    public function abandon_payment($payment_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->paymentService->abandonOne($payment_id);
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        PaymentAbandonAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Comptabilité: Liste des Paiements');
        $this->smarty->assign("paymentdatalist", $this->paymentService->getAllValidatedWithSortAndOrder("", ""));

        // show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }

    //update the status of the current country data to the database
    public function print_receipt($payment_id = '') {
        $this->smarty->assign('statusbartitle', 'Comptabilité: Liste des Paiements');
        $payment = $this->paymentService->getOne($payment_id);
        $curentAcademicYear = $this->getAcademic_year_activated()->__toString();
        $number = $this->paymentService->getReceiptNumber();
        PaymentAbandonAssign($this->smarty);
        
        //************************ première partie*********************************   
        
        $this->phpToPDF->AddPage();
        
        $this->phpToPDF->Image("./assets/images/baniere.png", 0, 0, 210, 30);

        $this->phpToPDF->SetFont("Times", "B", 12);
        $this->phpToPDF->setXY(0, 28);
        $this->phpToPDF->Cell(40, 8, utf8_decode($curentAcademicYear), 0, 0, 'C');

        $this->phpToPDF->SetFont("Arial", "U", 16);
        $this->phpToPDF->setXY(40, 40);
        $this->phpToPDF->Cell(40, 8, utf8_decode($m = "Reçu de paiement :"), 0, 0, 'C');
        $this->phpToPDF->setXY(95, 40);
        $this->phpToPDF->Cell(40, 8, ' Numero ', 0, 0, 'C');
        $this->phpToPDF->setXY(140, 41);
        $this->phpToPDF->Cell(12, 6, $number , 0, 0, 'L');

        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(10, 50);
        $fullName = $payment->getStudent();
        $this->phpToPDF->Write(10, utf8_decode($m = "Nom et Prénoms :"));
        $this->phpToPDF->setXY(60, 50);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, utf8_decode($fullName));

        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(10, 60);
        $fee = $payment->getFee()->getFee_type()->getWording();
        $this->phpToPDF->Write(10, "Frais : ");
        $this->phpToPDF->setXY(60, 60);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, utf8_decode($fee));
        
        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(130, 60);
        $paid = $payment->getAmount_paid();
        $this->phpToPDF->Write(10, utf8_decode($m = "Montant payé :"));
        $this->phpToPDF->setXY(180, 60);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, utf8_decode($paid));

        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(10, 70);
        $mdp = $payment->getModality_payment()->__toString();
        $this->phpToPDF->Write(10, utf8_decode($m = "Modalité de paiement :"));
        $this->phpToPDF->setXY(60, 70);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, utf8_decode($mdp));

        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(130, 70);
        $resttopaid = $payment->getRest_to_paid();
        $this->phpToPDF->Write(10, utf8_decode($m = "Reste à payer :"));
        $this->phpToPDF->setXY(180, 70);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, utf8_decode($resttopaid));

        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(10, 80);
        $paymentDate = substr($payment->getPayment_date(), 0, 10);
        $this->phpToPDF->Write(10, "Date de paiement : ");
        $this->phpToPDF->setXY(60, 80);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, "$paymentDate");

        $this->phpToPDF->SetFont("Arial", "B", 14);
        $this->phpToPDF->setXY(10, 90);
        $this->phpToPDF->Write(12, utf8_decode($m = "Fait à N'Zérékoré "));
        $date = date("d/m/Y " . utf8_decode($m = " à ") . " H:i:s");
        $this->phpToPDF->setXY(12, 98);
        $this->phpToPDF->SetFont("Times", "", 10);
        $this->phpToPDF->Write(10, "Le $date");

        $this->phpToPDF->SetFont("Arial", "B", 14);
        $this->phpToPDF->setXY(155, 46);
        $this->phpToPDF->Write(100, utf8_decode($m = "La Comptabilité "));
        $this->phpToPDF->setXY(160, 52);
//        $this->phpToPDF->SetFont("Times", "", 8);
//        $this->phpToPDF->Write(100, "(signer ici)");
        $this->phpToPDF->underline;
        
        //************************ deuxième partie*********************************
        
        $this->phpToPDF->Image("./assets/images/baniere.png", 0, 130, 210, 30);

        $this->phpToPDF->SetFont("Times", "B", 12);
        $this->phpToPDF->setXY(0, 158);
        $this->phpToPDF->Cell(40, 8, utf8_decode($curentAcademicYear), 0, 0, 'C');

        $this->phpToPDF->SetFont("Arial", "U", 16);
        $this->phpToPDF->setXY(40, 170);
        $this->phpToPDF->Cell(40, 8, utf8_decode($m = "Reçu de paiement :"), 0, 0, 'C');
        $this->phpToPDF->setXY(95, 170);
        $this->phpToPDF->Cell(40, 8, ' Numero ', 0, 0, 'C');
        $this->phpToPDF->setXY(140, 171);
        $this->phpToPDF->Cell(12, 6, $number, 0, 0, 'L');

        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(10, 180);
        $fullName = $payment->getStudent();
        $this->phpToPDF->Write(10, utf8_decode($m = "Nom et Prénoms :"));
        $this->phpToPDF->setXY(60, 180);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, utf8_decode($fullName));

        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(10, 190);
        $fee = $payment->getFee()->getFee_type()->getWording();
        $this->phpToPDF->Write(10, "Frais : ");
        $this->phpToPDF->setXY(60, 190);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, utf8_decode($fee));
        
        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(130, 190);
        $paid = $payment->getAmount_paid();
        $this->phpToPDF->Write(10, utf8_decode($m = "Montant payé :"));
        $this->phpToPDF->setXY(180, 190);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, utf8_decode($paid));

        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(10, 200);
        $mdp = $payment->getModality_payment()->__toString();
        $this->phpToPDF->Write(10, utf8_decode($m = "Modalité de paiement :"));
        $this->phpToPDF->setXY(60, 200);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, utf8_decode($mdp));

        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(130, 200);
        $resttopaid = $payment->getRest_to_paid();
        $this->phpToPDF->Write(10, utf8_decode($m = "Reste à payer :"));
        $this->phpToPDF->setXY(180, 200);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, utf8_decode($resttopaid));

        $this->phpToPDF->SetFont("Arial", "B", 12);
        $this->phpToPDF->setXY(10, 210);
        $paymentDate = substr($payment->getPayment_date(), 0, 10);
        $this->phpToPDF->Write(10, "Date de paiement : ");
        $this->phpToPDF->setXY(60, 210);
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->Write(10, "$paymentDate");

        $this->phpToPDF->SetFont("Arial", "B", 14);
        $this->phpToPDF->setXY(10, 220);
        $this->phpToPDF->Write(12, utf8_decode($m = "Fait à N'Zérékoré "));
        $date = date("d/m/Y " . utf8_decode($m = " à ") . " H:i:s");
        $this->phpToPDF->setXY(12, 228);
        $this->phpToPDF->SetFont("Times", "", 10);
        $this->phpToPDF->Write(10, "Le $date");

        $this->phpToPDF->SetFont("Arial", "B", 14);
        $this->phpToPDF->setXY(155, 176);
        $this->phpToPDF->Write(100, utf8_decode($m = "La Comptabilité "));
        $this->phpToPDF->setXY(160, 176);
//        $this->phpToPDF->SetFont("Times", "", 8);
//        $this->phpToPDF->Write(100, "(signer ici)");

//        foreach ($paymentList as $payment) {
//            $p = $payment->getStudent();
//            $this->phpToPDF->Write(5, "$p\n");
//        }
//        $this->phpToPDF->Cell(20, 8, 'Titre', 1, 1, 'C');
//        $this->phpToPDF->MultiCell(0, 10, "Ceci est un texte multilignes centré avec un bord\nEt voici la deuxième ligne", 1, "C", 0);
//        $this->phpToPDF->Write(10, "Liste des paiements de $curentAcademicYear \n");
//        $this->phpToPDF->Text(40, 10, "Uniquement un texte");
        $this->phpToPDF->Output();

        // show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }

    //update the status of the current country data to the database
    public function print_payment_list($first_date = "", $snd_date = "") {
        $start_date = htmlspecialchars(str_replace("-", "/", $_POST["startdate"]));
        $end_date = htmlspecialchars(str_replace("-", "/", $_POST["enddate"]));
        $paymentList = $this->paymentService->getAllForPrint($start_date, $end_date);
        $curentAcademicYear = $this->getAcademic_year_activated()->__toString();
        $this->phpToPDF->AddPage();
        $this->phpToPDF->Image("./assets/images/baniere.png", 0, 0, 210, 30);
        $this->phpToPDF->SetFont("Arial", "B", 16);
        $this->phpToPDF->Write(10, "\n\n");
        $this->phpToPDF->Cell(50, 8, 'Liste des paiements de l\'' . utf8_decode($curentAcademicYear), 0, 0, 'C');
        $this->phpToPDF->Write(10, "\n");
        $this->phpToPDF->SetFont("Times", "B", 12);
        $this->phpToPDF->SetTextColor(0, 0, 200);

        // Définition des propriétés du tableau.
        $proprietesTableau = array(
            'TB_ALIGN' => 'L',
            'L_MARGIN' => -8,
            'BRD_COLOR' => array(0, 0, 0),
            'BRD_SIZE' => '0.3',
        );
// Définition des propriétés du header du tableau.
        $proprieteHeader = array(
            'T_COLOR' => array(150, 10, 10),
            'T_SIZE' => 12,
            'T_FONT' => 'Arial',
            'T_ALIGN' => 'C',
            'V_ALIGN' => 'T',
            'T_TYPE' => 'B',
            'LN_SIZE' => 7,
            'BG_COLOR_COL0' => array(245, 245, 150),
            'BG_COLOR' => array(255, 255, 255),
            'BRD_COLOR' => array(0, 92, 177),
            'BRD_SIZE' => 0.2,
            'BRD_TYPE' => '1',
            'BRD_TYPE_NEW_PAGE' => '',
        );
// Contenu du header du tableau.
        $contenuHeader = array(
            50, 18, 15, 33, 72, 18,
            utf8_decode($a = "Apprenant"), utf8_decode($m = "Montant"), utf8_decode($r = "Reste"), utf8_decode($f = "Frais"), utf8_decode($mod = "Modalité"), utf8_decode($a = "Date"),
        );
// Définition des propriétés du reste du contenu du tableau.
        $proprieteContenu = array(
            'T_COLOR' => array(0, 0, 0),
            'T_SIZE' => 10,
            'T_FONT' => 'Times',
            'T_ALIGN_COL0' => 'L',
            'T_ALIGN' => 'R',
            'V_ALIGN' => 'M',
            'T_TYPE' => '',
            'LN_SIZE' => 6,
            'BG_COLOR_COL0' => array(245, 245, 150),
            'BG_COLOR' => array(255, 255, 255),
            'BRD_COLOR' => array(0, 92, 177),
            'BRD_SIZE' => 0.1,
            'BRD_TYPE' => '1',
            'BRD_TYPE_NEW_PAGE' => '',
        );
// Contenu du tableau.
        $tableContent = array();
        foreach ($paymentList as $payment) {
            $tableContent[] = utf8_decode($payment->getStudent());
            $tableContent[] = $payment->getAmount_paid();
            $tableContent[] = $payment->getRest_to_paid();
            $tableContent[] = utf8_decode($payment->getFee()->getFee_type()->getWording());
            $tableContent[] = utf8_decode($payment->getModality_payment()->__toString());
            $tableContent[] = substr($payment->getPayment_date(), 0, 10);
        }
        $contenuTableau = $tableContent;
        $this->phpToPDF->SetFont("Times");
        $this->phpToPDF->drawTableau($this->phpToPDF, $proprietesTableau, $proprieteHeader, $contenuHeader, $proprieteContenu, $contenuTableau);


//        foreach ($paymentList as $payment) {
//            $p = $payment->getStudent();
//            $this->phpToPDF->Write(5, "$p\n");
//        }
//        $this->phpToPDF->Cell(20, 8, 'Titre', 1, 1, 'C');
//        $this->phpToPDF->MultiCell(0, 10, "Ceci est un texte multilignes centré avec un bord\nEt voici la deuxième ligne", 1, "C", 0);
//        $this->phpToPDF->Write(10, "Liste des paiements de $curentAcademicYear \n");
//        $this->phpToPDF->Text(40, 10, "Uniquement un texte");
        $this->phpToPDF->Output();
    }

    //list the country data from the database
    public function payment_list() {
        PaymentListAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Comptabilité: Liste des Paiements');
        $this->smarty->assign("paymentdatalist", $this->paymentService->getAllValidatedWithSortAndOrder("", ""));
        // show the template
        $this->smarty->view('accounting/payment/paymentpage.tpl');
    }

    public function registrationrestrained() {
        // show the template
        $this->smarty->view('accounting/registrationrestrainedpage.tpl');
    }
    
    public function student_test($student_id=" ") {
        $amount = 0;
        $student_scholfees = $this->paymentService->getAllSchoolFeesByStudent($student_id, $this->getAcademic_year_activated()->getId());
        if($student_scholfees->isEmpty() == TRUE){
            $this->smarty->assign("student_selected", $student_id);
            $this->schoolfee_test_form();
        }else{
            $this->smarty->assign("student_selected", $student_id);
            $this->smarty->assign("student_modality_selected", $student_scholfees->get(count($student_scholfees)-1)->getModality_payment()->getId());
            $this->smarty->assign("student_fee_selected", $student_scholfees->get(count($student_scholfees)-1)->getFee()->getId());
            foreach($student_scholfees as $ssf){
                $amount += $ssf->getAmount_paid();
            }
            $this->smarty->assign("amounttopaidvalue", $student_scholfees->get(count($student_scholfees)-1)->getFee()->getAmount() - $amount);
            $this->schoolfee_test_form();
        }
    }

    
}
