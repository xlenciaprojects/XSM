<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
use serviceImpl\AcademicYearService;

/**
 * @property CI_Loader $load
 * @property CI_Form_validation $form_validation
 * @property CI_Input $input
 * @property CI_Email $email
 * @property Mysmarty $mysmarty
 */

require_once(APPPATH . 'models/serviceImpl/AcademicYearService.php');

class BaseController extends CI_Controller {

    private $normalStatus = 0;
    private $deleteStatus = 1;
    private $updateStatus = 2;
    private $abandonStatus = -1;
    private $restoreStatus = -2;
    private $academicYearService;
    private $academic_year_activated;

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();

        $this->academicYearService = new AcademicYearService("AcademicYear");
        $this->academicyear_datalist = $this->crud->build_entity_object_list_sort_asc($this->academicYearService, "wording");
        $this->smarty->assign("academicyeardatalist", $this->academicyear_datalist);
        $this->academic_year_activated = $this->academicYearService->getActivated();
        $this->smarty->assign("activated", $this->academic_year_activated);
        $this->smarty->assign("duty", $this->session->userdata("duty"));
        
        $this->smarty->assign('css_url', '../assets/css/');
        $this->smarty->assign('js_url', '../assets/js/');

        $this->smarty->assign('home', 'home');

        $this->smarty->assign('dashboard', 'dashboard');

        $this->smarty->assign('utils', 'utils');

        $this->smarty->assign('admin', 'admin');
        $this->smarty->assign('school', 'school');
        $this->smarty->assign('academicyear', 'academicyear');
        $this->smarty->assign('fee', 'fee');
        $this->smarty->assign('modalitypayment', 'modalitypayment');
        $this->smarty->assign('permission', 'permission');
        $this->smarty->assign('role', 'role');
        $this->smarty->assign('users', 'users');

        $this->smarty->assign('registration', 'registration');
        $this->smarty->assign('student', 'student');
        $this->smarty->assign('academicregistration', 'academicregistration');
        $this->smarty->assign('courseregistration', 'courseregistration');
        $this->smarty->assign('registrationsummary', 'registrationsummary');

        $this->smarty->assign('accounting', 'accounting');
        $this->smarty->assign('payment', 'payment');
        $this->smarty->assign('registrationrestrained', 'registrationrestrained');

        $this->smarty->assign('teaching', 'teaching');
        $this->smarty->assign('season', 'season');
        $this->smarty->assign('course', 'course');
        $this->smarty->assign('schedule', 'schedule');

        $this->smarty->assign('evaluation', 'evaluation');
        $this->smarty->assign('marktype', 'marktype');
        $this->smarty->assign('markverify', 'markverify');
        $this->smarty->assign('markvalidation', 'markvalidation');
        $this->smarty->assign('deliberation', 'deliberation');

        $this->smarty->assign('staff', 'staff');
        $this->smarty->assign('personal', 'personal');
        $this->smarty->assign('post', 'post');
        $this->smarty->assign('grh', 'grh');

        $this->smarty->assign('report', 'report');
        $this->smarty->assign('classlist', 'classlist');
        $this->smarty->assign('minutes', 'minutes');
        $this->smarty->assign('markreport', 'markreport');
        $this->smarty->assign('paymentorder', 'paymentorder');
        $this->smarty->assign('payslip', 'payslip');
        $this->smarty->assign('statistic', 'statistic');
        $this->smarty->assign('registrationcertificate', 'registrationcertificate');
        $this->smarty->assign('certificateofemployement', 'certificateofemployement');

        $this->smarty->assign('backup', 'backup');
        
        $this->smarty->assign("viewlabel", "Details");
        $this->smarty->assign("addnewlabel", "Nouveau");
        $this->smarty->assign("listlabel", "Liste");
        $this->smarty->assign("editlabel", "Modifier");
        $this->smarty->assign("deletelabel", "Supprimer");
        $this->smarty->assign("savelabel", "Enrégistrer");
        $this->smarty->assign("cancellabel", "Annuler");
        $this->smarty->assign("restorelabel", "Restaurer");
        $this->smarty->assign("abandonlabel", "Abandonner");
        $this->smarty->assign("dobackuplabel", "Sauvegarder la base de données");
        $this->smarty->assign('schoolfeelabel', '');
        $this->smarty->assign('registrationfeelabel', '');
        
        $this->smarty->assign('statusbartitle', 'Tableau de bord');
        $this->smarty->assign('havastatusbar', 'no');
        $this->smarty->assign('addnew', '');
        $this->smarty->assign('list', '');
        $this->smarty->assign('schoolfee', '');
        $this->smarty->assign('registrationfee', '');
        
        $this->smarty->assign('info', '');
        $this->smarty->assign('success', '');
        $this->smarty->assign('warning', '');
        $this->smarty->assign('error', '');
    }

    function getNormalStatus() {
        return $this->normalStatus;
    }

    function getDeleteStatus() {
        return $this->deleteStatus;
    }

    function getUpdateStatus() {
        return $this->updateStatus;
    }

    function getAbandonStatus() {
        return $this->abandonStatus;
    }

    function getRestoreStatus() {
        return $this->restoreStatus;
    }

    function getAcademic_year_activated() {
        return $this->academic_year_activated;
    }

    function setNormalStatus($normalStatus) {
        $this->normalStatus = $normalStatus;
    }

    function setDeleteStatus($deleteStatus) {
        $this->deleteStatus = $deleteStatus;
    }

    function setUpdateStatus($updateStatus) {
        $this->updateStatus = $updateStatus;
    }

    function setAbandonStatus($abandonStatus) {
        $this->abandonStatus = $abandonStatus;
    }

    function setRestoreStatus($restoreStatus) {
        $this->restoreStatus = $restoreStatus;
    }

    function setAcademic_year_activated($academic_year_activated) {
        $this->academic_year_activated = $academic_year_activated;
    }




}
