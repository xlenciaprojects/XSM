<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once( 'BaseController.php' );

use serviceImpl\SchoolService,
    serviceImpl\AcademicYearService,
    serviceImpl\ClassesService,
    serviceImpl\FeeTypeService,
    serviceImpl\FeeService,
    serviceImpl\ModalityPaymentService,
    serviceImpl\PermissionService,
    serviceImpl\RoleService,
    serviceImpl\RolePermissionService,
    serviceImpl\UserRoleService,
    serviceImpl\UsersService,
    serviceImpl\StaffService,
    entities\School,
    entities\AcademicYear,
    entities\ModalityPayment,
    entities\Fee,
    entities\Classes,
    entities\Role,
    entities\RolePermission,
    entities\UsersRole,
    entities\Users,
    entities\Permission,
    entities\Staff

;
use Doctrine\Common\Collections\ArrayCollection;

require_once(APPPATH . 'models/serviceImpl/SchoolService.php');
require_once(APPPATH . 'models/serviceImpl/AcademicYearService.php');
require_once(APPPATH . 'models/serviceImpl/FeeTypeService.php');
require_once(APPPATH . 'models/serviceImpl/ClassesService.php');
require_once(APPPATH . 'models/serviceImpl/FeeService.php');
require_once(APPPATH . 'models/serviceImpl/PermissionService.php');
require_once(APPPATH . 'models/serviceImpl/RoleService.php');
require_once(APPPATH . 'models/serviceImpl/RolePermissionService.php');
require_once(APPPATH . 'models/serviceImpl/UserRoleService.php');
require_once(APPPATH . 'models/serviceImpl/UsersService.php');
require_once(APPPATH . 'models/serviceImpl/StaffService.php');
require_once(APPPATH . 'models/serviceImpl/ModalityPaymentService.php');

class Admin extends BaseController {

    private $schoolService;
    private $academicYearService;
    private $feeService;
    private $feetypeService;
    private $classService;
    private $modalityPaymentService;
    private $permissionService;
    private $rolePermissionService;
    private $roleService;
    private $userRoleService;
    private $usersService;
    private $staffService;
    private $school;
    private $academic_year;
    private $fee;
    private $modalityPayment;
    private $permission;
    private $role;
    private $userRole;
    private $users;
    private $staff;
    private $school_datalist;
    private $academic_year_datalist;
    private $fee_datalist;
    private $block_payment_datalist;
    private $step_payment_datalist;
    private $permission_datalist;
    private $to_role_datalist;
    private $to_user_datalist;
    private $role_datalist;
    private $user_datalist;
    private $staff_datalist;
    private $entity;

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();

        ini_set('magic_quotes_gpc', 0);

        SchoolFormAssign($this->smarty);

        AdminCurrentLinkAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Administration: Etablissement');

        $this->schoolService = new SchoolService("School");
        $this->academicYearService = new AcademicYearService("AcademicYear");
        $this->feeTypeService = new FeeTypeService("FeeType");
        $this->feeService = new FeeService();
        $this->classService = new ClassesService("Classes");
        $this->modalityPaymentService = new ModalityPaymentService("ModalityPayment");
        $this->permissionService = new PermissionService("Permission");
        $this->roleService = new RoleService("Role");
        $this->usersService = new UsersService("Users");
        $this->userRoleService = new RoleService("UserRole");
        $this->staffService = new StaffService("Staff");
        $this->rolePermissionService = new rolePermissionService("RolePermission");
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function admin() {
        $this->smarty->assign("schooldatalist", $this->list_school());
        // show the template
        $this->smarty->view('admin/permission/permissionpage.tpl');
    }

    //school
    public function school() {
        $this->smarty->assign("schooldatalist", $this->list_school());
        // show the template
        $this->smarty->view('admin/school/schoolpage.tpl');
    }

    //add a new country to the database
    public function add_school() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(SchoolFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $wording = htmlspecialchars($_POST["schoolwording"]);
            $code = htmlspecialchars($_POST["schoolcode"]);

            if ($this->session->userdata('school_id') > 0) {
                $this->entity = $this->crud->find($this->schoolService, $this->session->userdata('school_id'));
                $this->entity->setWording($wording);
                $this->entity->setCode($code);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->schoolService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("school_id", 0);
                SchoolAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                SchoolAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $this->school = new School($wording, $code, $this->getNormalStatus());
                //proccess to add a new contry to database
                $this->crud->create($this->schoolService, $this->school);
                $this->smarty->assign("success", "Enrégistrement de l'établissement " . $wording . " éffectué avec succès ");
                SchoolAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("schooldatalist", $this->list_school());
        // show the template
        $this->smarty->view('admin/school/schoolpage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_school($school_id = '') {
        $this->entity = $this->crud->find($this->schoolService, $school_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("school_id", $this->entity->getId());
            $this->smarty->assign("schoolwordingvalue", $this->entity->getWording());
            $this->smarty->assign("schoolcodevalue", $this->entity->getCode());
        }
        SchoolEditAssign($this->smarty);
        $this->smarty->assign("schooldatalist", $this->list_school());
        // show the template
        $this->smarty->view('admin/school/schoolpage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_school($school_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->schoolService, $school_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        SchoolDeleteAssign($this->smarty);
        $this->session->set_userdata("school_id", 0);
        $this->smarty->assign("schooldatalist", $this->list_school());
        // show the template
        $this->smarty->view('admin/school/schoolpage.tpl');
    }

    //list the country data from the database
    public function list_school() {
        $this->school_datalist = $this->crud->build_entity_object_list_sort_asc($this->schoolService, "wording");
        return $this->school_datalist;
    }

    //academicyear
    public function academicyear() {
        $this->smarty->assign("academicyeardatalist", $this->list_academicyear());
        // show the template
        $this->smarty->assign('statusbartitle', 'Administration: Année scolaire');
        AcademicYearFormAssign($this->smarty);
        $this->smarty->view('admin/academicyear/academicyearpage.tpl');
    }

    public function add_academicyear() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(AcademicYearFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign('statusbartitle', 'Administration: Année scolaire');
            AcademicYearFormAssign($this->smarty);
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $wording = htmlspecialchars($_POST["academicyearwording"]);
            $code = htmlspecialchars($_POST["academicyearcode"]);
            if (isset($_POST["academicyearcurrent"])) {
                $current = "Oui";
            } else {
                $current = "Non";
            }

            if ($this->session->userdata('academicyear_id') > 0) {
                $this->entity = $this->crud->find($this->academicYearService, $this->session->userdata('academicyear_id'));
                $this->entity->setWording($wording);
                $this->entity->setCode($code);
                $this->entity->setCurrent($current);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->academicYearService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("academicyear_id", 0);
                AcademicYearListAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                AcademicYearListAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                if ($current === "Oui") {
                    $currentAcademicYear = $this->academicYearService->getActivated();
                    if ($currentAcademicYear != NULL) {
                        $currentAcademicYear->setCurrent("Non");
                        $currentAcademicYear->setState($this->getUpdateStatus());
                        $this->crud->update($this->academicYearService, $currentAcademicYear);
                    }
                }
                $this->academic_year = new AcademicYear($wording, $code, $current, $this->getNormalStatus());
                //proccess to add a new contry to database
                $this->crud->create($this->academicYearService, $this->academic_year);
                $this->academicyear_datalist = $this->crud->build_entity_object_list_sort_asc($this->academicYearService, "wording");
                $this->smarty->assign("academicyeardatalist", $this->academicyear_datalist);
                $this->academic_year_activated = $this->academicYearService->getActivated();
                $this->smarty->assign("activated", $this->academic_year_activated);
                $this->smarty->assign("success", "Enrégistrement de l'établissement " . $wording . " éffectué avec succès ");
                AcademicYearAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("academicyeardatalist", $this->list_academicyear());
        $this->smarty->assign('statusbartitle', 'Administration: Année scolaire');
        // show the template
        $this->smarty->view('admin/academicyear/academicyearpage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_academicyear($academicyear_id = '') {
        $this->entity = $this->crud->find($this->academicYearService, $academicyear_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("academicyear_id", $this->entity->getId());
            $this->smarty->assign("academicyearwordingvalue", $this->entity->getWording());
            $this->smarty->assign("academicyearcodevalue", $this->entity->getCode());
            $this->smarty->assign("academicyearcurrentvalue", $this->entity->getCurrent());
        }
        AcademicYearEditAssign($this->smarty);
        $this->smarty->assign("academicyeardatalist", $this->list_academicyear());
        $this->smarty->assign('statusbartitle', 'Administration: Année scolaire');
        // show the template
        $this->smarty->view('admin/academicyear/academicyearpage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_academicyear($academicyear_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->academicYearService, $academicyear_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        AcademicYearDeleteAssign($this->smarty);
        $this->session->set_userdata("academicyear_id", 0);
        $this->smarty->assign("academicyeardatalist", $this->list_academicyear());
        $this->smarty->assign('statusbartitle', 'Administration: Année scolaire');
        // show the template
        $this->smarty->view('admin/academicyear/academicyearpage.tpl');
    }

    //list the country data from the database
    public function list_academicyear() {
        $this->academicyear_datalist = $this->crud->build_entity_object_list_sort_asc($this->academicYearService, "wording");
        return $this->academicyear_datalist;
    }

    //frais
    public function fee() {
        $this->smarty->assign("feedatalist", $this->list_fee());
        $this->smarty->assign("classdatalist", $this->crud->build_entity_object_list_sort_asc($this->classService, "long_wording"));
        $this->smarty->assign("feetypedatalist", $this->crud->build_entity_object_list_sort_asc($this->feeTypeService, "wording"));
        $this->smarty->assign('statusbartitle', 'Administration: Frais');
        FeeFormAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/fee/feepage.tpl');
    }

    public function add_fee() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(FeeFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign('statusbartitle', 'Administration: Frais');
            $this->smarty->assign("classdatalist", $this->crud->build_entity_object_list_sort_asc($this->classService, "long_wording"));
            $this->smarty->assign("feetypedatalist", $this->crud->build_entity_object_list_sort_asc($this->feeTypeService, "wording"));
            FeeFormAssign($this->smarty);
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $amount = htmlspecialchars($_POST["feeamount"]);
            $class_id = htmlspecialchars($_POST["feeclass"]);
            $fee_type_id = htmlspecialchars($_POST["feetype"]);
            $class = $this->crud->find($this->classService, $class_id);
            $fee_type = $this->crud->find($this->feeTypeService, $fee_type_id);

            if ($this->session->userdata('fee_id') > 0) {
                $object = Array($amount, $fee_type_id, $class_id);
                $this->feeService->updateOneFeeById($object, $this->session->userdata('fee_id'));
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("fee_id", 0);
                $this->smarty->assign("classselected", "");
                $this->smarty->assign("feetypeselected", "");
                FeeAddAssign($this->smarty);
//                FeeListAssign($this->smarty);
//                $this->smarty->assign("warning", "opération de modification annuler ");
//                FeeListAssign($this->smarty);
            } else {
                //create an country object
                $this->fee = new Fee($amount, $this->getNormalStatus(), $this->getAcademic_year_activated(), $fee_type, $class);
                //proccess to add a new contry to database
                $this->crud->create($this->feeService, $this->fee);
                $this->smarty->assign("success", "Enrégistrement du frais éffectué avec succès ");
                FeeAddAssign($this->smarty);
            }
        }
//
        $this->smarty->assign("feedatalist", $this->list_fee());
        $this->smarty->assign("classdatalist", $this->crud->build_entity_object_list_sort_asc($this->classService, "long_wording"));
        $this->smarty->assign("feetypedatalist", $this->crud->build_entity_object_list_sort_asc($this->feeTypeService, "wording"));
        $this->smarty->assign('statusbartitle', 'Administration: Frais');
        // show the template
        $this->smarty->view('admin/fee/feepage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_fee($fee_id = '') {
        $this->entity = $this->feeService->getOne($fee_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("fee_id", $this->entity->getId());
            $this->smarty->assign("feeamountvalue", $this->entity->getAmount());
            $this->smarty->assign("classselected", $this->entity->getClasses()->getId());
            $this->smarty->assign("feetypeselected", $this->entity->getFee_type()->getId());
        }
        $this->smarty->assign("feedatalist", $this->list_fee());
        $this->smarty->assign("classdatalist", $this->crud->build_entity_object_list_sort_asc($this->classService, "long_wording"));
        $this->smarty->assign("feetypedatalist", $this->crud->build_entity_object_list_sort_asc($this->feeTypeService, "wording"));
        $this->smarty->assign('statusbartitle', 'Administration: Frais');
        FeeEditAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/fee/feepage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_fee($fee_id = '') {
        $this->feeService->deleteStateOneById($fee_id);
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        $this->smarty->assign("warning", "opération de supression annuler ");
        $this->session->set_userdata("fee_id", 0);
        $this->smarty->assign("feedatalist", $this->list_fee());
        $this->smarty->assign("classdatalist", $this->crud->build_entity_object_list_sort_asc($this->classService, "long_wording"));
        $this->smarty->assign("feetypedatalist", $this->crud->build_entity_object_list_sort_asc($this->feeTypeService, "wording"));
        $this->smarty->assign('statusbartitle', 'Administration: Frais');
        FeeDeleteAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/fee/feepage.tpl');
    }

    //list the fee data from the database
    public function list_fee() {
        $this->fee_datalist = $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId());
        return $this->fee_datalist;
    }

    //Modality 
    public function modalitypayment() {
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("blockpaymentdatalist", $this->list_block_payment());
        $this->smarty->assign("steppaymentdatalist", $this->list_step_payment());
        BlockPaymentFormAssign($this->smarty);
        StepPaymentFormAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/modality/modalitypaymentpage.tpl');
    }

    //Block payment
    public function block_payment() {
        $this->smarty->assign("blockpaymentdatalist", $this->list_block_payment());
        $this->smarty->assign("steppaymentdatalist", $this->list_step_payment());
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign('statusbartitle', 'Administration: Modalité de paiement');
        StepPaymentFormAssign($this->smarty);
        BlockPaymentFormAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/modality/modalitypaymentpage.tpl');
    }

    public function add_block_payment() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(BlockPaymentFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign('statusbartitle', 'Administration: Modalité de paiement');
            $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
            StepPaymentFormAssign($this->smarty);
            BlockPaymentFormAssign($this->smarty);
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $delay = htmlspecialchars(str_replace("-", "/", $_POST["blockdelay"]));
            $fee_id = htmlspecialchars($_POST["blockfee"]);
//            $fee = $this->crud->find($this->feeService, $fee_id);

            if ($this->session->userdata('block_payment_id') > 0) {
                if ($delay === "") {
                    $delay = $this->session->userdata('blockdelay');
                }
                $object = Array($delay, $fee_id);
                $this->modalityPaymentService->updateOneBlocModalityById($object, $this->session->userdata('block_payment_id'));
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("block_payment_id", 0);
                $this->session->set_userdata("blockdelay", "");
                $this->smarty->assign("blockselected", "");
                BlockPaymentAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                StepPaymentFormAssign($this->smarty);
                BlockPaymentAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $object = Array($fee_id, $this->getAcademic_year_activated()->getId(), "B", $delay, 1, $this->getNormalStatus());
//                $this->modalityPayment = new ModalityPayment("B", $delay, 1, $this->getNormalStatus(), $fee, $this->getAcademic_year_activated());
                //proccess to add a new contry to database
                $this->modalityPaymentService->saveOne($object);
                $this->smarty->assign("success", "Enrégistrement du block de paiement éffectué avec succès ");
                StepPaymentFormAssign($this->smarty);
                BlockPaymentAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("blockpaymentdatalist", $this->list_block_payment());
        $this->smarty->assign("steppaymentdatalist", $this->list_step_payment());
        $this->smarty->assign('statusbartitle', 'Administration:Modalité de paiement');
        // show the template
        $this->smarty->view('admin/modality/modalitypaymentpage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_block_payment($block_payment_id = '') {
        $this->entity = $this->modalityPaymentService->getOne($block_payment_id);

        if ($this->entity != NULL) {
            $this->session->set_userdata("block_payment_id", $this->entity->getId());
            $this->session->set_userdata("blockdelay", $this->entity->getDelay());
            $this->smarty->assign("blockselected", $this->entity->getFee()->getId());
        }
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("blockpaymentdatalist", $this->list_block_payment());
        $this->smarty->assign("steppaymentdatalist", $this->list_step_payment());
        $this->smarty->assign('statusbartitle', 'Administration: Modalité de paiement');
        StepPaymentFormAssign($this->smarty);
        BlockPaymentEditAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/modality/modalitypaymentpage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_block_payment($block_payment_id = '') {
        $this->modalityPaymentService->deleteStateOneById($block_payment_id);
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        $this->session->set_userdata("block_payment_id", 0);
        $this->smarty->assign("blockpaymentdatalist", $this->list_block_payment());
        $this->smarty->assign("steppaymentdatalist", $this->list_step_payment());
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign('statusbartitle', 'Administration: Modalité de paiement');
        StepPaymentFormAssign($this->smarty);
        BlockPaymentDeleteAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/modality/modalitypaymentpage.tpl');
    }

    //list the country data from the database
    public function list_block_payment() {
        $this->block_payment_datalist = $this->modalityPaymentService->getAllBlockPayment();
        return $this->block_payment_datalist;
    }

    //Step payment
    public function step_payment() {
        $this->smarty->assign("blockpaymentdatalist", $this->list_block_payment());
        $this->smarty->assign("steppaymentdatalist", $this->list_step_payment());
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign('statusbartitle', 'Administration: Modalité de paiement');
        BlockPaymentFormAssign($this->smarty);
        StepPaymentFormAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/modality/modalitypaymentpage.tpl');
    }

    public function add_step_payment() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(StepPaymentFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign('statusbartitle', 'Administration: Modalité de paiement');
            $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
            BlockPaymentFormAssign($this->smarty);
            StepPaymentFormAssign($this->smarty);
            $this->smarty->assign("error", validation_errors());
        } else {
            // getting the differents values of fields
            $delay = htmlspecialchars(str_replace("-", "/", $_POST["stepdelay"]));
            $fee_id = htmlspecialchars($_POST["stepfee"]);
            $stepNumber = htmlspecialchars($_POST["stepnumber"]);
            $fee = $this->crud->find($this->feeService, $fee_id);

            if ($this->session->userdata('step_payment_id') > 0) {
                if ($delay === "") {
                    $delay = $this->session->userdata('stepdelay');
                }
                $object = Array($delay, $stepNumber, $fee_id);
                $this->modalityPaymentService->updateOneStepModalityById($object, $this->session->userdata('step_payment_id'));
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("step_payment_id", 0);
                $this->session->set_userdata("stepdelay", "");
                $this->smarty->assign("stepselected", "");
                StepPaymentAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                BlockPaymentFormAssign($this->smarty);
                StepPaymentAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $object = Array($fee_id, $this->getAcademic_year_activated()->getId(), "S", $delay, $stepNumber, $this->getNormalStatus());
//                $this->modalityPayment = new ModalityPayment("B", $delay, 1, $this->getNormalStatus(), $fee, $this->getAcademic_year_activated());
                //proccess to add a new contry to database
                $this->modalityPaymentService->saveOne($object);
                $this->smarty->assign("success", "Enrégistrement du block de paiement éffectué avec succès ");
                BlockPaymentFormAssign($this->smarty);
                StepPaymentAddAssign($this->smarty);
            }
        }

        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("blockpaymentdatalist", $this->list_block_payment());
        $this->smarty->assign("steppaymentdatalist", $this->list_step_payment());
        $this->smarty->assign('statusbartitle', 'Administration:Modalité de paiement');
        // show the template
        $this->smarty->view('admin/modality/modalitypaymentpage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_step_payment($step_payment_id = '') {
        $this->entity = $this->modalityPaymentService->getOne($step_payment_id);

        if ($this->entity != NULL) {
            $this->session->set_userdata("step_payment_id", $this->entity->getId());
            $this->session->set_userdata("stepdelay", $this->entity->getDelay());
            $this->smarty->assign("stepselected", $this->entity->getFee()->getId());
            
            $this->smarty->assign("stepnumbervalue", $this->entity->getStepNumber());
        }
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign("blockpaymentdatalist", $this->list_block_payment());
        $this->smarty->assign("steppaymentdatalist", $this->list_step_payment());
        $this->smarty->assign('statusbartitle', 'Administration: Modalité de paiement');
        BlockPaymentFormAssign($this->smarty);
        StepPaymentEditAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/modality/modalitypaymentpage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_step_payment($step_payment_id = '') {
        $this->modalityPaymentService->deleteStateOneById($step_payment_id);
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        $this->session->set_userdata("step_payment_id", 0);
        $this->smarty->assign("blockpaymentdatalist", $this->list_block_payment());
        $this->smarty->assign("steppaymentdatalist", $this->list_step_payment());
        $this->smarty->assign("feedatalist", $this->feeService->getAllByAcademicYear($this->getAcademic_year_activated()->getId()));
        $this->smarty->assign('statusbartitle', 'Administration: Modalité de paiement');
        BlockPaymentFormAssign($this->smarty);
        StepPaymentDeleteAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/modality/modalitypaymentpage.tpl');
    }

    //list the country data from the database
    public function list_step_payment() {
        $this->step_payment_datalist = $this->modalityPaymentService->getAllStepPayment();
        return $this->step_payment_datalist;
    }

    //permission
    public function permission() {
        PermissionBarAssign($this->smarty);
        PermissionAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Administration: Liste des permissions');
        $this->permission_datalist = $this->crud->build_entity_object_list_sort_asc($this->permissionService, "wording");
        $this->smarty->assign("permissiondatalist", $this->permission_datalist);
        // show the template
        $this->smarty->view('admin/permission/permissionpage.tpl');
    }

    //permission
    public function permission_form() {
        PermissionBarAssign($this->smarty);
        PermissionFormAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Administration: Définition des permissions');
        $this->permission_datalist = $this->crud->build_entity_object_list_sort_asc($this->permissionService, "wording");
        $this->smarty->assign("permissiondatalist", $this->permission_datalist);
        // show the template
        $this->smarty->view('admin/permission/permissionpage.tpl');
    }

    //add a new country to the database
    public function add_permission() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(PermissionFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
            PermissionBarAssign($this->smarty);
            PermissionFormAssign($this->smarty);
            $this->smarty->assign('statusbartitle', 'Administration: Définition des permissions');
        } else {
            // getting the differents values of fields
            $wording = htmlspecialchars($_POST["permissionwording"]);
            $description = htmlspecialchars($_POST["permissiondescription"]);

            if ($this->session->userdata('permission_id') > 0) {
                $this->entity = $this->crud->find($this->permissionService, $this->session->userdata('permission_id'));
                $this->entity->setWording($wording);
                $this->entity->setDescription($description);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->permissionService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("permission_id", 0);
                PermissionBarAssign($this->smarty);
                PermissionAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                PermissionBarAssign($this->smarty);
                PermissionAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                $this->permission = new Permission($wording, $description, $this->getNormalStatus());
                //proccess to add a new contry to database
                $this->crud->create($this->permissionService, $this->permission);
                $this->smarty->assign("success", "Enrégistrement de permission " . $wording . " éffectué avec succès ");
                PermissionBarAssign($this->smarty);
                PermissionListAssign($this->smarty);
            }
        }

        $this->smarty->assign('statusbartitle', 'Administration: Liste des permissions');
        $this->permission_datalist = $this->crud->build_entity_object_list_sort_asc($this->permissionService, "wording");
        $this->smarty->assign("permissiondatalist", $this->permission_datalist);
        // show the template
        $this->smarty->view('admin/permission/permissionpage.tpl');
    }

    //edit and update the status of the current country data to the database
    public function edit_permission($permission_id = '') {
        $this->entity = $this->crud->find($this->permissionService, $permission_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("permission_id", $this->entity->getId());
            $this->smarty->assign("permissionwordingvalue", $this->entity->getWording());
            $this->smarty->assign("permissiondescriptionvalue", $this->entity->getDescription());
        }
        PermissionBarAssign($this->smarty);
        PermissionEditAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Administration: Liste des permissions');
        $this->permission_datalist = $this->crud->build_entity_object_list_sort_asc($this->permissionService, "wording");
        $this->smarty->assign("permissiondatalist", $this->permission_datalist);
        // show the template
        $this->smarty->view('admin/permission/permissionpage.tpl');
    }

    //update the status of the current country data to the database
    public function delete_permission($permission_id = '') {
        ?>
        <script type="text/javascript" >
            if (confirm("Vous êtes sur le point de supprimer l'élément sélectionné;\n\
        êtes vous sur de vouloir continuer cette opération???") === true) {<?php
        $this->crud->delete($this->permissionService, $permission_id, $this->getDeleteStatus());
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        ?>
            } else {<?php
        $this->smarty->assign("warning", "opération de supression annuler ");
        ?>
            }
        </script>
        <?php
        PermissionBarAssign($this->smarty);
        PermissionDeleteAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Administration: Liste des permissions');
        $this->session->set_userdata("permission_id", 0);
        $this->permission_datalist = $this->crud->build_entity_object_list_sort_asc($this->permissionService, "wording");
        $this->smarty->assign("permissiondatalist", $this->permission_datalist);
        // show the template
        $this->smarty->view('admin/permission/permissionpage.tpl');
    }

    //list the country data from the database
    public function permission_list() {
        PermissionBarAssign($this->smarty);
        PermissionListAssign($this->smarty);
        $this->permission_datalist = $this->crud->build_entity_object_list_sort_asc($this->permissionService, "wording");
        $this->smarty->assign("permissiondatalist", $this->permission_datalist);
        $this->smarty->assign('statusbartitle', 'Administration: Liste des permissions');
        // show the template
        $this->smarty->view('admin/permission/permissionpage.tpl');
    }

    //Role
    public function role() {
        $this->to_role_datalist = $this->crud->build_entity_object_list_sort_asc($this->permissionService, "wording");
        $this->smarty->assign("toroledatalist", $this->to_role_datalist);
        $this->smarty->assign('statusbartitle', 'Administration: Définition des rôles');
//        $this->smarty->assign("roledatalist", $this->list_role());
        // show the template
        RoleBarAssign($this->smarty);
        RoleAssign($this->smarty);
        $this->smarty->view('admin/role/rolepage.tpl');
    }

    public function role_form() {
        $this->to_role_datalist = $this->crud->build_entity_object_list_sort_asc($this->permissionService, "wording");
        $this->smarty->assign("toroledatalist", $this->to_role_datalist);
        $this->smarty->assign('statusbartitle', 'Administration: Définition des rôles');
//        $this->smarty->assign("roledatalist", $this->list_role());
        // show the template
        RoleBarAssign($this->smarty);
        RoleFormAssign($this->smarty);
        $this->smarty->view('admin/role/rolepage.tpl');
    }

    public function add_role() {
        $this->fv->set_rules(RoleFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
            RoleFormAssign($this->smarty);
            $this->smarty->view('admin/role/rolepage.tpl');
        } else {
            // getting the differents values of fields
            $wording = htmlspecialchars($_POST["rolewording"]);
            $description = htmlspecialchars($_POST["roledescription"]);
            $permissionIds = $_POST["permission"];
            print_r($permissionIds);
            $permissions = $this->permissionService->getMany($permissionIds);
            $role = new Role($wording, $description, $this->getNormalStatus());
            $this->crud->create($this->roleService, $role);
            $currentRole = $this->roleService->getLast();
            $rolePermissions = new ArrayCollection();
            foreach ($permissions as $permission) {
                $rolePermissions->add(new RolePermission($permission, $currentRole, $this->getNormalStatus()));
            }
            $this->rolePermissionService->saveAll($rolePermissions);
            $this->to_role_datalist = $this->crud->build_entity_object_list_sort_asc($this->permissionService, "wording");
            $this->smarty->assign("toroledatalist", $this->to_role_datalist);
            $this->smarty->assign('statusbartitle', 'Administration: Définition de Rôle');
            // show the template
            RoleBarAssign($this->smarty);
            RoleListAssign($this->smarty);
            $this->smarty->view('admin/role/rolepage.tpl');
        }
    }

    public function role_list() {
        RoleBarAssign($this->smarty);
        RoleListAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/role/rolepage.tpl');
    }

    //Users
    public function users() {
        $this->to_user_datalist = $this->crud->build_entity_object_list_sort_asc($this->roleService, "wording");
        $this->smarty->assign("touserdatalist", $this->to_user_datalist);
        $this->staff_datalist = $this->staffService->getAllValidatedWithSortAndOrder("", "");
        $this->smarty->assign("staffdatalist", $this->staff_datalist);
        $this->smarty->assign('statusbartitle', 'Administration: Définition des utilisateurs');
        // show the template
        UserBarAssign($this->smarty);
//        UserAssign($this->smarty);
        $this->smarty->view('admin/user/userpage.tpl');
    }

    public function user_form() {
        $this->to_user_datalist = $this->crud->build_entity_object_list_sort_asc($this->roleService, "wording");
        $this->smarty->assign("touserdatalist", $this->to_user_datalist);
        $this->staff_datalist = $this->staffService->getAllValidatedWithSortAndOrder("", "");
        $this->smarty->assign("staffdatalist", $this->staff_datalist);
        $this->smarty->assign('statusbartitle', 'Administration: Définition des utilisateurs');
        // show the template
        UserBarAssign($this->smarty);
        UserFormAssign($this->smarty);
        $this->smarty->view('admin/user/userpage.tpl');
    }

    public function add_user() {
        $this->fv->set_rules(UserFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
            UserBarAssign($this->smarty);
            UserFormAssign($this->smarty);
            $this->smarty->view('admin/user/userpage.tpl');
        } else {
            // getting the differents values of fields
            $login = htmlspecialchars($_POST["login"]);
            $password = htmlspecialchars($_POST["password"]);
            $staff_id = htmlspecialchars($_POST["staff"]);
            if (isset($_POST["uservalidated"])) {
                $validated = "Oui";
            } else {
                $validated = "Non";
            }
            $roleIds = $_POST["role"];
            $this->users = Array($staff_id, $login, $password, $this->getNormalStatus(), $validated);
            $this->usersService->saveOne($this->users);
            $currentUser = $this->usersService->getOne($this->usersService->getLastId());
            $userRoles = new ArrayCollection();
            foreach ($roleIds as $roleId) {
                $userRoles->addArray(Array($currentUser->getId(), $roleId, $this->getNormalStatus()));
            }
            $this->userRoleService->saveAll($userRoles);
            $this->to_user_datalist = $this->crud->build_entity_object_list_sort_asc($this->roleService, "wording");
            $this->smarty->assign("touserdatalist", $this->to_user_datalist);
            $this->staff_datalist = $this->staffService->getAllValidatedWithSortAndOrder("", "");
            $this->smarty->assign("staffdatalist", $this->staff_datalist);
            $this->smarty->assign('statusbartitle', 'Administration: Définition des utilisateurs');
            // show the template
            UserBarAssign($this->smarty);
            UserListAssign($this->smarty);
            $this->smarty->view('admin/user/userpage.tpl');
        }
    }

    public function user_list() {
        UserBarAssign($this->smarty);
        UserListAssign($this->smarty);
        // show the template
        $this->smarty->view('admin/user/userpage.tpl');
    }

}
