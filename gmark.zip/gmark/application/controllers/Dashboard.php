<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once( 'BaseController.php' );

class Dashboard extends BaseController {

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();

        ini_set('magic_quotes_gpc', 0);

        DashboardCurrentLinkAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Tableau de bord');
        $this->smarty->assign("duty", $this->session->userdata("duty"));
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function login() {
        $login = htmlspecialchars($_POST["login"]);
        $password = htmlspecialchars($_POST["password"]);
        if ($login == "secret2016" && $password == "Secret$1343az") {
            $this->session->set_userdata("duty", 'Secretaire');
            $this->smarty->assign("duty", $this->session->userdata("duty"));
            $this->smarty->view('dashboard/dashboard.tpl');
        } else if ($login == "compta2016" && $password == "Compta$1343az") {
            $this->session->set_userdata("duty", 'Comptabilité');
            $this->smarty->assign("duty", $this->session->userdata("duty"));
            $this->smarty->view('dashboard/dashboard.tpl');
        } else if ($login == "academic2016" && $password == "Academic$1343az") {
            $this->session->set_userdata("duty", 'Academique');
            $this->smarty->assign("duty", $this->session->userdata("duty"));
            $this->smarty->view('dashboard/dashboard.tpl');
        } else if ($login == "admin" && $password == "Admin$1343az") {
            $this->session->set_userdata("duty", 'Admin');
            $this->smarty->assign("duty", $this->session->userdata("duty"));
            $this->smarty->view('dashboard/dashboard.tpl');
        } else {
            $this->smarty->assign("error", 'Authentification échouée');
            $this->smarty->assign('loginTitle', "Admin");
            $this->smarty->view('login/loginpage.tpl');
        }
    }

    public function dashboard() {
        // show the template
        $this->smarty->view('dashboard/dashboard.tpl');
    }

}
