<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once( 'BaseController.php' );

use serviceImpl\CountryService,
    serviceImpl\CityService,
    serviceImpl\GenderService,
    serviceImpl\SchoolService,
    serviceImpl\StaffService,
    serviceImpl\PersonInfoService,
    serviceImpl\UsersService,
    entities\Country,
    entities\City,
    entities\Gender,
    entities\School,
    entities\Staff,
    entities\PersonInfo
;

require_once(APPPATH . 'models/serviceImpl/CountryService.php');
require_once(APPPATH . 'models/serviceImpl/CityService.php');
require_once(APPPATH . 'models/serviceImpl/GenderService.php');
require_once(APPPATH . 'models/serviceImpl/SchoolService.php');
require_once(APPPATH . 'models/serviceImpl/StaffService.php');
require_once(APPPATH . 'models/serviceImpl/PersonInfoService.php');
require_once(APPPATH . 'models/serviceImpl/UsersService.php');

class StaffController extends BaseController {

    private $countryService;
    private $cityService;
    private $genderService;
    private $schoolService;
    private $personInfoService;
    private $staffService;
    private $usersService;
    private $country;
    private $city;
    private $gender;
    private $school;
    private $person_info;
    private $personal;
    private $users;
    private $country_datalist;
    private $city_datalist;
    private $gender_datalist;
    private $school_datalist;
    private $personal_datalist;
    private $to_users_datalist;
    private $entity;

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();

        ini_set('magic_quotes_gpc', 0);

        StaffCurrentLinkAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Personnel:Liste des personnels');

        $this->datalist = new \ArrayIterator();

        $this->countryService = new CountryService("Country");
        $this->cityService = new CityService("City");
        $this->genderService = new GenderService("Gender");
        $this->schoolService = new SchoolService("School");
        $this->staffService = new StaffService("Staff");
        $this->personInfoService = new PersonInfoService("PersonInfo");
        $this->usersService = new UsersService("Users");
        $this->smarty->assign("genderdatalist", $this->crud->build_entity_object_list_sort_asc($this->genderService, "long_wording"));
        $this->smarty->assign("countrydatalist", $this->crud->build_entity_object_list_sort_asc($this->countryService, "wording"));
        $this->smarty->assign("citydatalist", $this->crud->build_entity_object_list_sort_asc($this->cityService, "wording"));
        $this->smarty->assign("schooldatalist", $this->crud->build_entity_object_list_sort_asc($this->schoolService, "wording"));
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function staff() {
        // show the template
        $this->smarty->view('staff/staffpage.tpl');
    }

    public function post() {
        // show the template
        $this->smarty->view('staff/postpage.tpl');
    }

    public function personal() {
        PersonalBarAssign($this->smarty);
        $this->personal_datalist = $this->staffService->getAllValidatedWithSortAndOrder("","");
        $this->smarty->assign("personaldatalist", $this->personal_datalist);
        $this->smarty->assign('statusbartitle', 'Personnel : Liste des apprenants');
        // show the template
        $this->smarty->view('staff/personal/personalpage.tpl');
    }

    public function personal_form() {
        $this->smarty->assign('statusbartitle', 'Personnel:Nouveau');
        PersonalFormAssign($this->smarty);
        // show the template
        $this->smarty->view('staff/personal/personalpage.tpl');
    }

    public function add_personal() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(PersonFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
            PersonalFormAssign($this->smarty);
        } else {
            // getting the differents values of fields
            $last_name = htmlspecialchars($_POST["lastname"]);
            $first_name = htmlspecialchars($_POST["firstname"]);
            $guardian_name = htmlspecialchars($_POST["guardianname"]);
            $guardian_phone = htmlspecialchars($_POST["guardianphone"]);
            $guardian_mail = htmlspecialchars($_POST["guardianmail"]);
            $adress = htmlspecialchars($_POST["adress"]);
            $birth_date = htmlspecialchars(str_replace("-", "/", $_POST["birthdate"]));
            $blood_group = htmlspecialchars($_POST["bloodgroup"]);
            $picture = "";
            $gender_id = htmlspecialchars($_POST["gender"]);
            $city_id = htmlspecialchars($_POST["birthcity"]);
            $country_id = htmlspecialchars($_POST["nationality"]);
            $school_id = htmlspecialchars($_POST["school"]);
            $gender = $this->crud->find($this->genderService, $gender_id);
            $birth_city = $this->crud->find($this->cityService, $city_id);
            $nationality = $this->crud->find($this->countryService, $country_id);
            $old_school = $this->crud->find($this->schoolService, $school_id);
            $matricule = $gender->getShort_wording() . '' . substr($birth_date, 0, 4) . '' . mb_strtoupper(substr($last_name, 0, 3), 'UTF-8') . '' . ($this->staffService->size() + 1);
            $create_date = date("Y/m/d H:i:s");

            if ($this->session->userdata('city_id') > 0) {
                $this->entity = $this->crud->find($this->cityService, $this->session->userdata('city_id'));
                $this->entity->setWording($wording);
                $this->entity->setDescription($description);
                $this->entity->setCountry($country);
                $this->entity->setState($this->getUpdateStatus());
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->crud->update($this->staffService, $this->entity);
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("city_id", 0);
                $this->smarty->assign("selected", "");
                PersonalAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                PersonalAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                //proccess to add a new contry to database
                $this->person_info = new PersonInfo($last_name, $first_name, $guardian_name, $guardian_mail, $guardian_phone, $adress, $birth_date, $matricule, $blood_group, $picture, $create_date, $gender, $birth_city, $nationality, $old_school);
                $this->personal = new Staff(0, $this->getNormalStatus(), $this->person_info);
                $this->crud->create($this->staffService, $this->personal);
                $this->smarty->assign("success", "Enrégistrement du personnel " . $last_name . " " . $first_name . " éffectué avec succès ");
                $this->smarty->assign('statusbartitle', 'Personnel : Liste des personnels');
                $this->personal_list();
                PersonalAddAssign($this->smarty);
            }
        }
        // show the template
        $this->smarty->view('staff/personal/personalpage.tpl');
    }

    public function edit_personal() {
        PersonalFormAssign($this->smarty);
        // show the template
        $this->smarty->view('staff/personal/personalpage.tpl');
    }

    public function delete_personal() {
        PersonalFormAssign($this->smarty);
        // show the template
        $this->smarty->view('staff/personal/personalpage.tpl');
    }

    public function personal_list() {
        $this->smarty->assign('statusbartitle', 'Inscription : Liste des personnels');
        $this->personal_datalist = $this->staffService->getAllValidatedWithSortAndOrder("", "");
        $this->smarty->assign("personaldatalist", $this->personal_datalist);
        PersonalListAssign($this->smarty);
        // show the template
        $this->smarty->view('staff/personal/personalpage.tpl');
    }

    public function grh() {
        // show the template
        $this->smarty->view('staff/grhpage.tpl');
    }

}
