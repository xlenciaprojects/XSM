<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once( 'BaseController.php' );

use serviceImpl\CountryService,
    serviceImpl\CityService,
    serviceImpl\GenderService,
    serviceImpl\SchoolService,
    serviceImpl\StudentService,
    serviceImpl\PersonInfoService,
    serviceImpl\RegistrationService,
    entities\Country,
    entities\City,
    entities\Gender,
    entities\School,
    entities\Student,
    entities\PersonInfo,
    entities\Person

;
use Doctrine\Common\Collections\ArrayCollection;

require_once(APPPATH . 'models/serviceImpl/CountryService.php');
require_once(APPPATH . 'models/serviceImpl/CityService.php');
require_once(APPPATH . 'models/serviceImpl/GenderService.php');
require_once(APPPATH . 'models/serviceImpl/SchoolService.php');
require_once(APPPATH . 'models/serviceImpl/StudentService.php');
require_once(APPPATH . 'models/serviceImpl/PersonInfoService.php');
require_once(APPPATH . 'models/serviceImpl/RegistrationService.php');

class Registration extends BaseController {

    private $countryService;
    private $cityService;
    private $genderService;
    private $schoolService;
    private $personInfoService;
    private $studentService;
    private $registrationService;
    private $country;
    private $city;
    private $gender;
    private $school;
    private $person_info;
    private $student;
    private $registration;
    private $country_datalist;
    private $city_datalist;
    private $gender_datalist;
    private $school_datalist;
    private $student_datalist;
    private $to_registration_datalist;
    private $entity;

    /**
     * constructor
     */
    public function __construct() {
        parent::__construct();

        ini_set('magic_quotes_gpc', 0);

        $this->datalist = new \ArrayIterator();

        RegistrationCurrentLinkAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Inscription');

        $this->countryService = new CountryService("Country");
        $this->cityService = new CityService("City");
        $this->genderService = new GenderService("Gender");
        $this->schoolService = new SchoolService("School");
        $this->studentService = new StudentService("Student");
        $this->personInfoService = new PersonInfoService("PersonInfo");
        $this->registrationService = new RegistrationService("Registration");

        $this->smarty->assign("genderdatalist", $this->crud->build_entity_object_list_sort_asc($this->genderService, "long_wording"));
        $this->smarty->assign("countrydatalist", $this->crud->build_entity_object_list_sort_asc($this->countryService, "wording"));
        $this->smarty->assign("citydatalist", $this->crud->build_entity_object_list_sort_asc($this->cityService, "wording"));
        $this->smarty->assign("schooldatalist", $this->crud->build_entity_object_list_sort_asc($this->schoolService, "wording"));
    }

    /**
     * Default function that will be executed unless another method specified
     */
    public function registration() {
        // show the template
        $this->smarty->view('registration/student/studentpage.tpl');
    }

    //student
    public function student() {
        StudentBarAssign($this->smarty);
        StudentAssign($this->smarty);
        $this->student_datalist = $this->studentService->getAllValidatedWithSortAndOrder("", "");
        $this->smarty->assign("studentdatalist", $this->student_datalist);
        $this->smarty->assign('statusbartitle', 'Inscription : Liste des apprenants');
        // show the template
        $this->smarty->view('registration/student/studentpage.tpl');
    }

    public function student_form() {
        $this->smarty->assign('statusbartitle', 'Inscription : Ajout d\'un nouvel apprenant');
        StudentFormAssign($this->smarty);
        // show the template
        $this->smarty->view('registration/student/studentpage.tpl');
    }

    public function add_student() {
        //set the defines rules to the fields of formreturn 
        $this->fv->set_rules(PersonFormValidationConfig());
        //test if all of fields are typed; if something wrong the error message is sent
        if ($this->fv->run() == FALSE) {
            $this->smarty->assign("error", validation_errors());
            StudentFormAssign($this->smarty);
        } else {
            // getting the differents values of fields
            $last_name = htmlspecialchars($_POST["lastname"]);
            $first_name = htmlspecialchars($_POST["firstname"]);
            $guardian_name = htmlspecialchars($_POST["guardianname"]);
            $guardian_phone = htmlspecialchars($_POST["guardianphone"]);
            $guardian_mail = htmlspecialchars($_POST["guardianmail"]);
            $adress = htmlspecialchars($_POST["adress"]);
//            $birth_date = date('Y-m-d',strtotime(htmlspecialchars($_POST["birthdate"])));
            $birth_date = htmlspecialchars(str_replace("-", "/", $_POST["birthdate"]));
            $blood_group = htmlspecialchars($_POST["bloodgroup"]);
//            $chemin_destination = APPPATH.'/pictures/'.basename($_FILES["picture"]['name']);     
//            $picture = move_uploaded_file($_FILES["picture"]['tmp_name'], $chemin_destination); 
//            $picture = htmlspecialchars($_FILES["picture"]['name']);
            $picture = "";
            $gender_id = htmlspecialchars($_POST["gender"]);
            $city_id = htmlspecialchars($_POST["birthcity"]);
            $country_id = htmlspecialchars($_POST["nationality"]);
            $school_id = htmlspecialchars($_POST["oldschool"]);
            $gender = $this->crud->find($this->genderService, $gender_id);
            $birth_city = $this->crud->find($this->cityService, $city_id);
            $nationality = $this->crud->find($this->countryService, $country_id);
            $old_school = $this->crud->find($this->schoolService, $school_id);
            $matricule = $gender->getShort_wording() . '' . substr($birth_date, 0, 4) . '' . mb_strtoupper(substr($last_name, 0, 3), 'UTF-8') . '' . ($this->studentService->size() + 1);
            $create_date = date("Y/m/d H:i:s");

            if ($this->session->userdata('student_id') > 0) {
                if ($birth_date === "") {
                    $birth_date = $this->session->userdata('birth_date');
                }
                $object = Array($last_name, $first_name, $guardian_name, $guardian_mail, $guardian_phone, $adress, $birth_date, $blood_group, $gender_id, $city_id, $country_id, $school_id);
                $this->studentService->updateOneStudentById($object, $this->session->userdata('person_info_id'), $this->session->userdata('student_id'));
                ?>
                <script type="text/javascript">
                    if (confirm("Vous êtes sur le point de modifier l'élément sélectionné;\n\
                êtes vous sur de vouloir continuer cette opération???")) {<?php
                $this->smarty->assign("success", "modification éffectuée avec succès ");
                $this->session->set_userdata("student_id", 0);
                $this->session->set_userdata("person_info_id", 0);
                $this->smarty->assign("genderselected", "");
                $this->smarty->assign("birthcityselected", "");
                $this->smarty->assign("nationalityselected", "");
                $this->smarty->assign("schoolselected", "");
                StudentAddAssign($this->smarty);
                ?>
                    } else {<?php
                $this->smarty->assign("warning", "opération de modification annuler ");
                StudentAddAssign($this->smarty);
                ?>
                    }
                </script>
                <?php
            } else {
                //create an country object
                //proccess to add a new contry to database
                $this->person_info = new PersonInfo($last_name, $first_name, $guardian_name, $guardian_mail, $guardian_phone, $adress, $birth_date, $matricule, $blood_group, $picture, $create_date, $gender, $birth_city, $nationality, $old_school);
                $this->student = new Student($this->getNormalStatus(), 0, $this->person_info);
                $this->crud->create($this->studentService, $this->student);
                $this->smarty->assign("success", "Enrégistrement de l'apprennant " . $last_name . " " . $first_name . " éffectué avec succès ");
            }
        }
        $this->smarty->assign('statusbartitle', 'Inscription : Liste des apprenants');
        $this->student_datalist = $this->studentService->getAllValidatedWithSortAndOrder("", "");
        $this->smarty->assign("studentdatalist", $this->student_datalist);
        StudentAddAssign($this->smarty);
        // show the template
        $this->smarty->view('registration/student/studentpage.tpl');
    }

    public function edit_student($student_id = '') {
        $this->entity = $this->studentService->getOne($student_id);
        if ($this->entity != NULL) {
            $this->session->set_userdata("student_id", $this->entity->getId());
            $this->session->set_userdata("person_info_id", $this->entity->getPerson_info()->getId());
            $this->smarty->assign("lastnamevalue", $this->entity->getPerson_info()->getLast_name());
            $this->smarty->assign("firstnamevalue", $this->entity->getPerson_info()->getFirst_name());
            $this->smarty->assign("guardiannamevalue", $this->entity->getPerson_info()->getGuardian_name());
            $this->smarty->assign("guardianmailvalue", $this->entity->getPerson_info()->getGuardian_mail());
            $this->smarty->assign("guardianphonevalue", $this->entity->getPerson_info()->getGuardian_phone());
            $this->smarty->assign("adressvalue", $this->entity->getPerson_info()->getAdress());
            $this->smarty->assign("birthdatevalue", $this->entity->getPerson_info()->getBirth_date());
            $this->session->set_userdata("birth_date", $this->entity->getPerson_info()->getBirth_date());
            $this->smarty->assign("bloodgroupvalue", $this->entity->getPerson_info()->getBlood_group());

            $this->smarty->assign("genderselected", $this->entity->getPerson_info()->getGender()->getId());
            $this->smarty->assign("birthcityselected", $this->entity->getPerson_info()->getBirth_city()->getId());
            $this->smarty->assign("nationalityselected", $this->entity->getPerson_info()->getNationality()->getId());
            $this->smarty->assign("schoolselected", $this->entity->getPerson_info()->getOld_school()->getId());
        }
        StudentEditAssign($this->smarty);
        // show the template
        $this->smarty->view('registration/student/studentpage.tpl');
    }

    public function delete_student($student_id = '') {
        ?>
        <script>
            bootbox.confirm({
                title: "Destroy planet?",
                message: "Do you want to activate the Deathstar now? This cannot be undone.",
                buttons: {
                    cancel: {
                        label: '<i class="fa fa-times"></i> Cancel'
                    },
                    confirm: {
                        label: '<i class="fa fa-check"></i> Confirm'
                    }
                },
                callback: function (result) {
                    console.log('This was logged in the callback: ' + result);
                }
            });
        </script>
        <?php
        $this->studentService->deleteStateOneById($student_id);
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        $this->smarty->assign('statusbartitle', 'Inscription : Liste des apprenants');
        $this->student_datalist = $this->studentService->getAllValidatedWithSortAndOrder("", "");
        $this->smarty->assign("studentdatalist", $this->student_datalist);
        StudentDeleteAssign($this->smarty);
        // show the template
        $this->smarty->view('registration/student/studentpage.tpl');
    }

    public function student_list() {
        $this->smarty->assign('statusbartitle', 'Inscription : Liste des apprenants');
        $this->student_datalist = $this->studentService->getAllValidatedWithSortAndOrder("", "");
        $this->smarty->assign("studentdatalist", $this->student_datalist);
        StudentListAssign($this->smarty);
        // show the template
        $this->smarty->view('registration/student/studentpage.tpl');
    }

//AccademicRegistration
    public function academicregistration() {
        $this->smarty->assign('statusbartitle', 'Inscription : Liste des inscrits');
        $this->smarty->assign("registrationdatalist", $this->registrationService->getAllByYear($this->getAcademic_year_activated()->getId()));
//        AcademicRegistrationBarAssign($this->smarty);
// show the template      
        AcademicRegistrationAssign($this->smarty);
        $this->smarty->view('registration/validation/academicregistrationpage.tpl');
    }

    //academic registration
    public function academicregistration_form() {
        $this->to_registration_datalist = $this->studentService->getAllForRegistration($this->getAcademic_year_activated()->getId());
        $this->smarty->assign("toregistrationdatalist", $this->to_registration_datalist);
        $this->smarty->assign('statusbartitle', 'Inscription : Validation des apprenants');
        // show the template
        AcademicRegistrationBarAssign($this->smarty);
        AcademicRegistrationFormAssign($this->smarty);
        $this->smarty->view('registration/validation/academicregistrationpage.tpl');
    }

    public function add_academicregistration() {
        $studentIds = explode(",", $_POST["selectedstudents"]);
//        print_r(count($studentIds));
        $registrations = new ArrayCollection();
        foreach ($studentIds as $studentId) {
            $registrations->add(Array($studentId, $this->getAcademic_year_activated()->getId(), date("Y/m/d H:i:s"), $this->getNormalStatus()));
        }
//        print_r("registrations" . count($registrations));
        $this->registrationService->saveAll($registrations);
        $this->smarty->assign('statusbartitle', 'Inscription: Liste des inscrits');
        $this->smarty->assign("registrationdatalist", $this->registrationService->getAllByYear($this->getAcademic_year_activated()->getId()));   
        // show the template
        AcademicRegistrationAddAssign($this->smarty);
        $this->smarty->view('registration/validation/academicregistrationpage.tpl');
    }

    public function unregistration($registration_id = '') {
        $this->registrationService->unregistration($registration_id);
        $this->smarty->assign("success", "supression éffectuée avec succès ");
        UnregistrationAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Inscription: Liste des inscrits');
        $this->smarty->assign("registrationdatalist", $this->registrationService->getAllByYear($this->getAcademic_year_activated()->getId()));   
        // show the template
        $this->smarty->view('registration/validation/academicregistrationpage.tpl');
    }
    
    public function academicregistration_list() {
        AcademicRegistrationListAssign($this->smarty);
        $this->smarty->assign('statusbartitle', 'Inscription : Liste des inscrits');
        $this->smarty->assign("registrationdatalist", $this->registrationService->getAllByYear($this->getAcademic_year_activated()->getId()));
        // show the template
        $this->smarty->view('registration/validation/academicregistrationpage.tpl');
    }

    public function courseregistration() {
        // show the template
        $this->smarty->view('registration/courseregistrationpage.tpl');
    }

    public function registrationsummary() {
        // show the template
        $this->smarty->view('registration/registrationsummarypage.tpl');
    }

}
