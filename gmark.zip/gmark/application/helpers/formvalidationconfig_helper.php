<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!function_exists('CountryFormValidationConfig')) {

    function CountryFormValidationConfig() {

        return array(
            array(
                'field' => 'countrywording',
                'label' => 'Nom',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'countryshortwording',
                'label' => 'Diminutif',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'countrycode',
                'label' => 'Code d\'identification',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'countrynationality',
                'label' => 'Nationalité',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}
if (!function_exists('FeeTypeFormValidationConfig')) {

    function FeeTypeFormValidationConfig() {

        return array(
            array(
                'field' => 'feetypewording',
                'label' => 'Libellé',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'feetypecode',
                'label' => 'Code d\'identification',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            
            array(
                'field' => 'feetypedescription',
                'label' => 'Information supplémentaire',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}

if (!function_exists('GradeFormValidationConfig')) {

    function GradeFormValidationConfig() {

        return array(
            array(
                'field' => 'gradewording',
                'label' => 'Libellé',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'gradecode',
                'label' => 'Code d\'identification',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            
            array(
                'field' => 'gradedescription',
                'label' => 'Information supplémentaire',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}
if (!function_exists('LevelFormValidationConfig')) {

    function LevelFormValidationConfig() {

        return array(
            array(
                'field' => 'levelwording',
                'label' => 'Libellé',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'levelcode',
                'label' => 'Code d\'identification',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            
            array(
                'field' => 'leveldescription',
                'label' => 'Information supplémentaire',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}

if (!function_exists('EvaluationTypeFormValidationConfig')) {

    function EvaluationTypeFormValidationConfig() {

        return array(
            array(
                'field' => 'evaluationtypewording',
                'label' => 'Libellé',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'evaluationtypecode',
                'label' => 'Code d\'identification',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            
            array(
                'field' => 'evaluationtypedescription',
                'label' => 'Information supplémentaire',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}

if (!function_exists('GenderFormValidationConfig')) {

    function GenderFormValidationConfig() {

        return array(
            array(
                'field' => 'genderlongwording',
                'label' => 'Libellé long',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'gendermediumwording',
                'label' => 'Libellé moyen',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'gendershortwording',
                'label' => 'Libellé court',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ) 
        );
    }

}

if (!function_exists('ClassFormValidationConfig')) {

    function ClassFormValidationConfig() {

        return array(
            array(
                'field' => 'classlongwording',
                'label' => 'Libellé long',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'classmediumwording',
                'label' => 'Libellé moyen',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'classshortwording',
                'label' => 'Libellé court',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ), 
            array(
                'field' => 'classlevel',
                'label' => 'Niveau',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ), 
            array(
                'field' => 'classdescription',
                'label' => 'Description',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ) 
        );
    }

}

if (!function_exists('CityFormValidationConfig')) {

    function CityFormValidationConfig() {

        return array(
            array(
                'field' => 'citywording',
                'label' => 'Nom',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'citydescription',
                'label' => 'Information supplémentaire',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'citycountry',
                'label' => 'Pays',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}

if (!function_exists('FeeFormValidationConfig')) {

    function FeeFormValidationConfig() {

        return array(
            array(
                'field' => 'feeamount',
                'label' => 'Montant',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'feeclass',
                'label' => 'Classe',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'feetype',
                'label' => 'Type de frais',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}

if (!function_exists('BlockPaymentFormValidationConfig')) {

    function BlockPaymentFormValidationConfig() {

        return array(
            array(
                'field' => 'blockfee',
                'label' => 'Frais',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
            
        );
    }

}

if (!function_exists('StepPaymentFormValidationConfig')) {

    function StepPaymentFormValidationConfig() {

        return array(
            array(
                'field' => 'stepfee',
                'label' => 'Frais',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'stepnumber',
                'label' => 'Nombre d\'échéance',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}

if (!function_exists('PaymentFormValidationConfig')) {

    function PaymentFormValidationConfig() {
        return array(
            array(
                'field' => 'amountpaid',
                'label' => 'Montant payé',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'amounttopaid',
                'label' => 'Montant à payer',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'resttopaid',
                'label' => 'Reste à payer',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'paymentstudent',
                'label' => 'Apprenant',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'paymentfee',
                'label' => 'Frais',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'paymentmodalitypayment',
                'label' => 'Modalité de paiement',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
            
        );
    }

}


if (!function_exists('ClassesFormValidationConfig')) {

    function ClassesFormValidationConfig() {

        return array(
            array(
                'field' => 'genderlongwording',
                'label' => 'Libellé long',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'gendermediumwording',
                'label' => 'Libellé moyen',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'gendershortwording',
                'label' => 'Libellé court',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ) 
        );
    }

}

if (!function_exists('SchoolFormValidationConfig')) {

    function SchoolFormValidationConfig() {

        return array(
            array(
                'field' => 'schoolwording',
                'label' => 'Libellé',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'schoolcode',
                'label' => 'Code d\'identification',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}
if (!function_exists('AcademicYearFormValidationConfig')) {

    function AcademicYearFormValidationConfig() {

        return array(
            array(
                'field' => 'academicyearwording',
                'label' => 'Libellé',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'academicyearcode',
                'label' => 'Code d\'identification',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}

if (!function_exists('PermisionFormValidationConfig')) {

    function PermissionFormValidationConfig() {

        return array(
            array(
                'field' => 'permissionwording',
                'label' => 'Libellé',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'permissiondescription',
                'label' => 'Description',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}

if (!function_exists('RoleFormValidationConfig')) {

    function RoleFormValidationConfig() {

        return array(
            array(
                'field' => 'rolewording',
                'label' => 'Libellé',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'roledescription',
                'label' => 'Description',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}

if (!function_exists('UserFormValidationConfig')) {

    function UserFormValidationConfig() {

        return array(
            array(
                'field' => 'login',
                'label' => 'Nom d\'utilisateur',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'password',
                'label' => 'Mot de passe',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            )
        );
    }

}

if (!function_exists('PersonFormValidationConfig')) {

    function PersonFormValidationConfig() {

        return array(
            array(
                'field' => 'lastname',
                'label' => 'Nom',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'firstname',
                'label' => 'Prenom',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'guardianname',
                'label' => 'Nom du tuteur',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'guardianphone',
                'label' => 'Téléphone du tuteur',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'guardianmail',
                'label' => 'Adresse mail du tuteur',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                    'valid_email' => 'Email invalide',
                    'is_unique[users.email]'=>'Email existant'
                ),
            ),
            array(
                'field' => 'adress',
                'label' => 'Adresse',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
//            array(
//                'field' => 'birthdate',
//                'label' => 'Date de naissance',
//                'rules' => 'required',
//                'errors' => array(
//                    'required' => 'le champ %s est obligatoire.',
//                ),
//            ),
            array(
                'field' => 'bloodgroup',
                'label' => 'Group sanguin',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'gender',
                'label' => 'Sexe',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'birthcity',
                'label' => 'Ville de naissance',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            array(
                'field' => 'nationality',
                'label' => 'Nationalité',
                'rules' => 'required',
                'errors' => array(
                    'required' => 'le champ %s est obligatoire.',
                ),
            ),
            
        );
    }

}