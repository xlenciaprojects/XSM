<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Country
if (!function_exists('CountryFormAssign')) {

    function CountryFormAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "localitychecked");

        $smarty->assign("countryformname", "countryform");
        $smarty->assign("countryformtitle", "Pays");
        $smarty->assign("addcountry", "addcountry");
        $smarty->assign("countrywording", "countrywording");
        $smarty->assign("countryshortwording", "countryshortwording");
        $smarty->assign("countrycode", "countrycode");
        $smarty->assign("countrynationality", "countrynationality");

        $smarty->assign("num", "N°");
        $smarty->assign("countrywordinglabel", "Libellé");
        $smarty->assign("countryshortwordinglabel", "Diminutif");
        $smarty->assign("countrycodelabel", "Code");
        $smarty->assign("countrynationalitylabel", "Nationalité");

        $smarty->assign("countrywordingdesc", "le nom du pays");
        $smarty->assign("countryshortwordingdesc", "le nom abrévié ");
        $smarty->assign("countrycodedesc", "le Code d'identification");
        $smarty->assign("countrynationalitydesc", "la nationalité");

        $smarty->assign("countryeditedlink", "utils/edit_country");
        $smarty->assign("countrydeletedlink", "utils/delete_country");
    }

}
if (!function_exists('CountryListAssign')) {

    function CountryListAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "lacolitychecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addcountry", "../../addcountry");
    }

}

if (!function_exists('CountryEditAssign')) {

    function CountryEditAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "lacolitychecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilEditLinkAssign($smarty);
    }

}

if (!function_exists('CountryDeleteAssign')) {

    function CountryDeleteAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "lacolitychecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        UtilDeleteLinkAssign($smarty) ;
    }

}

if (!function_exists('CountryAddAssign')) {

    function CountryAddAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "lacolitychecked");

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addcountry", "addcountry");
    }

}

// City
if (!function_exists('CityFormAssign')) {

    function CityFormAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "lacolitychecked");

        $smarty->assign("cityformname", "cityform");
        $smarty->assign("cityformtitle", "Ville");
        $smarty->assign("addcity", "addcity");
        $smarty->assign("citywording", "citywording");
        $smarty->assign("citydescription", "citydescription");
        $smarty->assign("citycountry", "citycountry");

        $smarty->assign("num", "N°");
        $smarty->assign("citywordinglabel", "Libellé");
        $smarty->assign("citydescriptionlabel", "Description");
        $smarty->assign("citycountrylabel", "Pays");

        $smarty->assign("citywordingdesc", "le nom de la ville");
        $smarty->assign("citydescriptiondesc", "information supplémentaire ");
        $smarty->assign("citycountrydesc", "faites votre choix");

        $smarty->assign("cityeditedlink", "utils/edit_city");
        $smarty->assign("citydeletedlink", "utils/delete_city");
    }

}
if (!function_exists('CityListAssign')) {

    function CityListAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "lacolitychecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addcity", "../../addcity");
    }

}

if (!function_exists('CityEditAssign')) {

    function CityEditAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "lacolitychecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilEditLinkAssign($smarty);
    }

}

if (!function_exists('CityDeleteAssign')) {

    function CityDeleteAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "lacolitychecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        UtilDeleteLinkAssign($smarty);
    }

}

if (!function_exists('CityAddAssign')) {

    function CityAddAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "lacolitychecked");

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addcity", "addcity");
    }

}

// Gender
if (!function_exists('GenderFormAssign')) {

    function GenderFormAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "genderchecked");

        $smarty->assign("genderformname", "genderform");
        $smarty->assign("genderformtitle", "Sexe");
        $smarty->assign("addgender", "addgender");
        $smarty->assign("genderlongwording", "genderlongwording");
        $smarty->assign("gendermediumwording", "gendermediumwording");
        $smarty->assign("gendershortwording", "gendershortwording");

        $smarty->assign("num", "N°");
        $smarty->assign("genderlongwordinglabel", "Libellé long");
        $smarty->assign("gendermediumwordinglabel", "Libellé moyen");
        $smarty->assign("gendershortwordinglabel", "Libellé court");

        $smarty->assign("genderlongwordingdesc", "libellé long du genre");
        $smarty->assign("gendermediumwordingdesc", "libellé moyen du genre");
        $smarty->assign("gendershortwordingdesc", "libellé court du genre");

        $smarty->assign("gendereditedlink", "utils/edit_gender");
        $smarty->assign("genderdeletedlink", "utils/delete_gender");
    }

}
if (!function_exists('GenderListAssign')) {

    function GenderListAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "genderchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addgender", "../../addgender");
    }

}

if (!function_exists('GenderEditAssign')) {

    function GenderEditAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "genderchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilEditLinkAssign($smarty);
    }

}

if (!function_exists('GenderDeleteAssign')) {

    function GenderDeleteAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "genderchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilDeleteLinkAssign($smarty);
    }

}

if (!function_exists('GenderAddAssign')) {

    function GenderAddAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "genderchecked");

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addgender", "addgender");
    }

}


// Class
if (!function_exists('ClassFormAssign')) {

    function ClassFormAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "hallchecked");

        $smarty->assign("classformname", "classform");
        $smarty->assign("classformtitle", "Classe");
        $smarty->assign("addclass", "addclass");
        $smarty->assign("classlongwording", "classlongwording");
        $smarty->assign("classmediumwording", "classmediumwording");
        $smarty->assign("classshortwording", "classshortwording");
        $smarty->assign("classlevel", "classlevel");
        $smarty->assign("classdescription", "classdescription");

        $smarty->assign("num", "N°");
        $smarty->assign("classlongwordinglabel", "Libellé long");
        $smarty->assign("classmediumwordinglabel", "Libellé moyen");
        $smarty->assign("classshortwordinglabel", "Libellé court");
        $smarty->assign("classlevellabel", "Niveau");
        $smarty->assign("classdescriptionlabel", "Description");

        $smarty->assign("classlongwordingdesc", "libellé long de la classe");
        $smarty->assign("classmediumwordingdesc", "libellé moyen de la classe");
        $smarty->assign("classshortwordingdesc", "libellé court de la classe");
        $smarty->assign("classleveldesc", "le niveau de la classe");
        $smarty->assign("classdescriptiondesc", "description de la classe");

        $smarty->assign("classeditedlink", "utils/edit_class");
        $smarty->assign("classdeletedlink", "utils/delete_class");
    }

}
if (!function_exists('ClassListAssign')) {

    function ClassListAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "hallchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addclass", "../../addclass");
    }

}

if (!function_exists('ClassEditAssign')) {

    function ClassEditAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "hallchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addclass", "../../addclass");
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("classeditedlink", "../../utils/edit_class");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("classdeletedlink", "../../utils/delete_class");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilEditLinkAssign($smarty);
    }

}

if (!function_exists('ClassDeleteAssign')) {

    function ClassDeleteAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "hallchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addclass", "../../addclass");
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("classeditedlink", "../../utils/edit_class");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("classdeletedlink", "../../utils/delete_class");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilDeleteLinkAssign($smarty);
    }

}

if (!function_exists('ClassAddAssign')) {

    function ClassAddAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "hallchecked");

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addclass", "addclass");
    }

}

// FeeType
if (!function_exists('FeeTypeFormAssign')) {

    function FeeTypeFormAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "feetypechecked");

        $smarty->assign("feetypeformname", "feetypeform");
        $smarty->assign("feetypeformtitle", "Type de frais");
        $smarty->assign("addfeetype", "addfeetype");
        $smarty->assign("feetypewording", "feetypewording");
        $smarty->assign("feetypecode", "feetypecode");
        $smarty->assign("feetypedescription", "feetypedescription");

        $smarty->assign("num", "N°");
        $smarty->assign("feetypewordinglabel", "Libellé");
        $smarty->assign("feetypecodelabel", "Code");
        $smarty->assign("feetypedescriptionlabel", "Description");

        $smarty->assign("feetypewordingdesc", "le libellé");
        $smarty->assign("feetypecodedesc", "le code");
        $smarty->assign("feetypedescriptiondesc", "information supplémentaire ");

        $smarty->assign("feetypeeditedlink", "utils/edit_feetype");
        $smarty->assign("feetypedeletedlink", "utils/delete_feetype");
    }

}

if (!function_exists('FeeTypeListAssign')) {

    function FeeTypeListAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "feetypechecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addfeetype", "../../addfeetype");
    }

}

if (!function_exists('FeeTypeEditAssign')) {

    function FeeTypeEditAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "feetypechecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilEditLinkAssign($smarty);
    }

}

if (!function_exists('FeeTypeDeleteAssign')) {

    function FeeTypeDeleteAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "feetypechecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilDeleteLinkAssign($smarty);
    }

}

if (!function_exists('FeeTypeAddAssign')) {

    function FeeTypeAddAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "feetypechecked");

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addfeetype", "addfeetype");
    }

}

// EvaluationType
if (!function_exists('EvaluationTypeFormAssign')) {

    function EvaluationTypeFormAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "evaluationtypechecked");

        $smarty->assign("evaluationtypeformname", "evaluationtypeform");
        $smarty->assign("evaluationtypeformtitle", "Type d'évaluation");
        $smarty->assign("addevaluationtype", "addevaluationtype");
        $smarty->assign("evaluationtypewording", "evaluationtypewording");
        $smarty->assign("evaluationtypecode", "evaluationtypecode");
        $smarty->assign("evaluationtypedescription", "evaluationtypedescription");

        $smarty->assign("num", "N°");
        $smarty->assign("evaluationtypewordinglabel", "Libellé");
        $smarty->assign("evaluationtypecodelabel", "Code");
        $smarty->assign("evaluationtypedescriptionlabel", "Description");

        $smarty->assign("evaluationtypewordingdesc", "le libellé");
        $smarty->assign("evaluationtypecodedesc", "le code");
        $smarty->assign("evaluationtypedescriptiondesc", "information supplémentaire ");

        $smarty->assign("evaluationtypeeditedlink", "utils/edit_evaluationtype");
        $smarty->assign("evaluationtypedeletedlink", "utils/delete_evaluationtype");
    }

}

if (!function_exists('EvaluationTypeListAssign')) {

    function EvaluationTypeListAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "evaluationtypechecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
    }

}

if (!function_exists('EvaluationTypeEditAssign')) {

    function EvaluationTypeEditAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "evaluationtypechecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilEditLinkAssign($smarty);
    }

}

if (!function_exists('EvaluationTypeDeleteAssign')) {

    function EvaluationTypeDeleteAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "evaluationtypechecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");;
    }

}

if (!function_exists('EvaluationTypeAddAssign')) {

    function EvaluationTypeAddAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "evaluationtypechecked");

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addevaluationtype", "addevaluationtype");
        
        UtilDeleteLinkAssign($smarty);
    }

}
// Grade
if (!function_exists('GradeFormAssign')) {

    function GradeFormAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "levelchecked");

        $smarty->assign("gradeformname", "gradeform");
        $smarty->assign("gradeformtitle", "Grade");
        $smarty->assign("addgrade", "addgrade");
        $smarty->assign("gradewording", "gradewording");
        $smarty->assign("gradecode", "gradecode");
        $smarty->assign("gradedescription", "gradedescription");

        $smarty->assign("num", "N°");
        $smarty->assign("gradewordinglabel", "Libellé");
        $smarty->assign("gradecodelabel", "Code");
        $smarty->assign("gradedescriptionlabel", "Description");

        $smarty->assign("gradewordingdesc", "le libellé");
        $smarty->assign("gradecodedesc", "le code");
        $smarty->assign("gradedescriptiondesc", "information supplémentaire ");

        $smarty->assign("gradeeditedlink", "utils/edit_grade");
        $smarty->assign("gradedeletedlink", "utils/delete_grade");
    }

}

if (!function_exists('GradeListAssign')) {

    function GradeListAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "levelchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addgrade", "../../addgrade");
    }

}

if (!function_exists('GradeEditAssign')) {

    function GradeEditAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "levelchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addgrade", "../../addgrade");
        $smarty->assign("gradeeditedlink", "../../utils/edit_grade");
        $smarty->assign("gradedeletedlink", "../../utils/delete_grade");
        
        UtilEditLinkAssign($smarty);
    }

}

if (!function_exists('GradeDeleteAssign')) {

    function GradeDeleteAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "levelchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addgrade", "../../addgrade");
        $smarty->assign("gradeeditedlink", "../../utils/edit_grade");
        $smarty->assign("gradedeletedlink", "../../utils/delete_grade");
        
        UtilDeleteLinkAssign($smarty);
    }

}

if (!function_exists('GradeAddAssign')) {

    function GradeAddAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "levelchecked");

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addgrade", "addgrade");
    }

}
// Level
if (!function_exists('LevelFormAssign')) {

    function LevelFormAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "levelchecked");

        $smarty->assign("levelformname", "levelform");
        $smarty->assign("levelformtitle", "Niveau");
        $smarty->assign("addlevel", "addlevel");
        $smarty->assign("levelwording", "levelwording");
        $smarty->assign("levelcode", "levelcode");
        $smarty->assign("leveldescription", "leveldescription");

        $smarty->assign("num", "N°");
        $smarty->assign("levelwordinglabel", "Libellé");
        $smarty->assign("levelcodelabel", "Code");
        $smarty->assign("leveldescriptionlabel", "Description");

        $smarty->assign("levelwordingdesc", "le libellé");
        $smarty->assign("levelcodedesc", "le code");
        $smarty->assign("leveldescriptiondesc", "information supplémentaire ");

        $smarty->assign("leveleditedlink", "utils/edit_level");
        $smarty->assign("leveldeletedlink", "utils/delete_level");
    }

}

if (!function_exists('LevelListAssign')) {

    function LevelListAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "levelchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addlevel", "../../addlevel");
    }

}

if (!function_exists('LevelEditAssign')) {

    function LevelEditAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "levelchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilEditLinkAssign($smarty);
    }

}

if (!function_exists('LevelDeleteAssign')) {

    function LevelDeleteAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "levelchecked");

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addgender", "../../addgender");
        $smarty->assign("addfeetype", "../../addfeetype");
        $smarty->assign("addcity", "../../addcity");
        $smarty->assign("addcountry", "../../addcountry");
        $smarty->assign("addlevel", "../../addlevel");
        $smarty->assign("addevaluationtype", "../../addevaluationtype");
        $smarty->assign("gendereditedlink", "../../utils/edit_gender");
        $smarty->assign("feetypeeditedlink", "../../utils/edit_feetype");
        $smarty->assign("cityeditedlink", "../../utils/edit_city");
        $smarty->assign("countryeditedlink", "../../utils/edit_country");
        $smarty->assign("leveleditedlink", "../../utils/edit_level");
        $smarty->assign("evaluationtypeeditedlink", "../../utils/edit_evaluationtype");
        $smarty->assign("genderdeletedlink", "../../utils/delete_gender");
        $smarty->assign("countrydeletedlink", "../../utils/delete_country");
        $smarty->assign("citydeletedlink", "../../utils/delete_city");
        $smarty->assign("feetypedeletedlink", "../../utils/delete_feetype");
        $smarty->assign("leveldeletedlink", "../../utils/delete_level");
        $smarty->assign("evaluationtypedeletedlink", "../../utils/delete_evaluationtype");
        
        UtilDeleteLinkAssign($smarty);
    }

}

if (!function_exists('LevelAddAssign')) {

    function LevelAddAssign($smarty) {
        UtilsTabCurrentLinkAssign($smarty, "levelchecked");

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addelevel", "addlevel");
    }

}

if (!function_exists('UtilsCurrentLinkAssign')) {

    function UtilsCurrentLinkAssign($smarty) {
        $smarty->assign('dashboardcurrent', '');
        $smarty->assign('utilscurrent', 'current');
        $smarty->assign('admincurrent', '');
        $smarty->assign('registrationcurrent', '');
        $smarty->assign('accountingcurrent', '');
        $smarty->assign('teachingcurrent', '');
        $smarty->assign('evaluationcurrent', '');
        $smarty->assign('staffcurrent', '');
        $smarty->assign('reportingcurrent', '');
        $smarty->assign('backupcurrent', '');
    }

}

if (!function_exists('UtilsTabCurrentLinkAssign')) {

    function UtilsTabCurrentLinkAssign($smarty, $checked) {
        switch ($checked) {
            case 'localitychecked':$smarty->assign('localitychecked', 'checked');
                $smarty->assign('mentionchecked', '');
                $smarty->assign('lessonunitchecked', '');
                $smarty->assign('genderchecked', '');
                $smarty->assign('sessionchecked', '');
                $smarty->assign('levelchecked', '');
                $smarty->assign('evaluationtypechecked', '');
                $smarty->assign('hallchecked', '');
                $smarty->assign('fetypechecked', '');
                break;
            case 'mentionchecked':$smarty->assign('mentionchecked', 'checked');
                $smarty->assign('lacalitychecked', '');
                $smarty->assign('lessonunitchecked', '');
                $smarty->assign('genderchecked', '');
                $smarty->assign('sessionchecked', '');
                $smarty->assign('levelchecked', '');
                $smarty->assign('evaluationtypechecked', '');
                $smarty->assign('hallchecked', '');
                $smarty->assign('fetypechecked', '');
                break;
            case 'lessonunitchecked':$smarty->assign('lessonunitchecked', 'checked');
                $smarty->assign('mentionchecked', '');
                $smarty->assign('localitychecked', '');
                $smarty->assign('genderchecked', '');
                $smarty->assign('sessionchecked', '');
                $smarty->assign('levelchecked', '');
                $smarty->assign('evaluationtypechecked', '');
                $smarty->assign('hallchecked', '');
                $smarty->assign('fetypechecked', '');
                break;
            case 'genderchecked':$smarty->assign('genderchecked', 'checked');
                $smarty->assign('mentionchecked', '');
                $smarty->assign('lessonunitchecked', '');
                $smarty->assign('localitychecked', '');
                $smarty->assign('sessionchecked', '');
                $smarty->assign('levelchecked', '');
                $smarty->assign('evaluationtypechecked', '');
                $smarty->assign('hallchecked', '');
                $smarty->assign('fetypechecked', '');
                break;
            case 'sessionchecked':$smarty->assign('sessionchecked', 'checked');
                $smarty->assign('mentionchecked', '');
                $smarty->assign('lessonunitchecked', '');
                $smarty->assign('genderchecked', '');
                $smarty->assign('localitychecked', '');
                $smarty->assign('levelchecked', '');
                $smarty->assign('evaluationtypechecked', '');
                $smarty->assign('hallchecked', '');
                $smarty->assign('fetypechecked', '');
                break;
            case 'levelchecked':$smarty->assign('levelchecked', 'checked');
                $smarty->assign('mentionchecked', '');
                $smarty->assign('lessonunitchecked', '');
                $smarty->assign('genderchecked', '');
                $smarty->assign('sessionchecked', '');
                $smarty->assign('localitychecked', '');
                $smarty->assign('evaluationtypechecked', '');
                $smarty->assign('hallchecked', '');
                $smarty->assign('fetypechecked', '');
                break;
            case 'evaluationtypechecked':$smarty->assign('evaluationtypechecked', 'checked');
                $smarty->assign('mentionchecked', '');
                $smarty->assign('lessonunitchecked', '');
                $smarty->assign('genderchecked', '');
                $smarty->assign('sessionchecked', '');
                $smarty->assign('levelchecked', '');
                $smarty->assign('localitychecked', '');
                $smarty->assign('hallchecked', '');
                $smarty->assign('fetypechecked', '');
                break;
            case 'hallchecked':$smarty->assign('hallchecked', 'checked');
                $smarty->assign('mentionchecked', '');
                $smarty->assign('lessonunitchecked', '');
                $smarty->assign('genderchecked', '');
                $smarty->assign('sessionchecked', '');
                $smarty->assign('levelchecked', '');
                $smarty->assign('evaluationtypechecked', '');
                $smarty->assign('localitychecked', '');
                $smarty->assign('fetypechecked', '');
                break;
            case 'feetype':$smarty->assign('feetypechecked', 'checked');
                $smarty->assign('mentionchecked', '');
                $smarty->assign('lessonunitchecked', '');
                $smarty->assign('genderchecked', '');
                $smarty->assign('sessionchecked', '');
                $smarty->assign('levelchecked', '');
                $smarty->assign('evaluationtypechecked', '');
                $smarty->assign('hallchecked', '');
                $smarty->assign('localitychecked', '');
                break;

            default:$smarty->assign('localitychecked', 'checked');
                $smarty->assign('mentionchecked', '');
                $smarty->assign('lessonunitchecked', '');
                $smarty->assign('genderchecked', '');
                $smarty->assign('sessionchecked', '');
                $smarty->assign('levelchecked', '');
                $smarty->assign('evaluationtypechecked', '');
                $smarty->assign('hallchecked', '');
                $smarty->assign('fetypechecked', '');
                break;
        }
    }

}