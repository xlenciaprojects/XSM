<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require_once 'dashboardassign_helper.php';
require_once 'utilsassign_helper.php';
require_once 'adminassign_helper.php';
require_once 'registrationassign_helper.php';
require_once 'accountingassign_helper.php';
require_once 'teachingassign_helper.php';
require_once 'evaluationassign_helper.php';
require_once 'staffassign_helper.php';
require_once 'reportingassign_helper.php';
require_once 'backupassign_helper.php';