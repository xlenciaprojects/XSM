<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//personal

if (!function_exists('PersonalBarAssign')) {

    function PersonalBarAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', 'StaffController/personal_form');
        $smarty->assign('list', '');
    }

}
if (!function_exists('PersonalFormField')) {

    function PersonalFormField($smarty) {
        $smarty->assign("personalformtitle", "Personnel Administratif");
        $smarty->assign("personalformname", "Ajour d'un personnel");
        $smarty->assign("addpersonal", "add_personal");
        $smarty->assign("lastname", "lastname");
        $smarty->assign("firstname", "firstname");
        $smarty->assign("guardianname", "guardianname");
        $smarty->assign("guardianphone", "guardianphone");
        $smarty->assign("guardianmail", "guardianmail");
        $smarty->assign("adress", "adress");
        $smarty->assign("birthdate", "birthdate");
        $smarty->assign("bloodgroup", "bloodgroup");
        $smarty->assign("birthcity", "birthcity");
        $smarty->assign("gender", "gender");
        $smarty->assign("nationality", "nationality");
        $smarty->assign("school", "school");
        $smarty->assign("picture", "picture");
    }

}
if (!function_exists('PersonalFormFieldLabel')) {

    function PersonalFormFieldLabel($smarty) {
        $smarty->assign("num", "N°");
        $smarty->assign("lastnamelabel", "Nom");
        $smarty->assign("firstnamelabel", "Prénoms");
        $smarty->assign("matriculelabel", "Numero matricule");
        $smarty->assign("guardiannamelabel", "Personne à prévenir");
        $smarty->assign("guardianphonelabel", "Numero de personne à prévenir");
        $smarty->assign("guardianmaillabel", "Mail de personne à prévenir");
        $smarty->assign("adresslabel", "Adresse");
        $smarty->assign("birthdatelabel", "Date de Naissance");
        $smarty->assign("bloodgrouplabel", "Group Sanguin");
        $smarty->assign("birthcitylabel", "Ville de naissance");
        $smarty->assign("genderlabel", "Sexe");
        $smarty->assign("nationalitylabel", "Nationalité");
        $smarty->assign("schoollabel", "Etablissement de provenance");
        $smarty->assign("picturelabel", "Photo");
    }

}
if (!function_exists('PersonalFormFieldDesc')) {

    function PersonalFormFieldDesc($smarty) {
        $smarty->assign("lastnamedesc", "le noms de l'aprenant");
        $smarty->assign("firstnamedesc", "le prénoms de l'aprenant");
        $smarty->assign("guardiannamedesc", "le nom du personne à prévenir");
        $smarty->assign("guardianphonedesc", "le numero de personne à prévenir");
        $smarty->assign("guardianmaildesc", "le mail de personne à prévenir");
        $smarty->assign("adressdesc", "l'adresse");
        $smarty->assign("birthdatedesc", "Date de Naissance");
        $smarty->assign("bloodgroupdesc", "Group Sanguin");
        $smarty->assign("birthcitydesc", "la ville de naissance");
        $smarty->assign("genderdesc", "le sexe");
        $smarty->assign("nationalitydesc", " choisir la nationalité");
        $smarty->assign("schooldesc", "Choisir l'établissement de provenance");
        $smarty->assign("picturedesc", "Choisir la photo");
    }

}
if (!function_exists('PersonalAssign')) {

    function PersonalAssign($smarty) {
        $smarty->assign('addnew', '');

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');

        $smarty->assign('list', 'StaffController/personal_list');
        $smarty->assign('utils', '../utils');
        PersonalFormField($smarty);
        PersonalFormFieldLabel($smarty);
        PersonalFormFieldDEsc($smarty);
        $smarty->assign("personaleditedlink", "StaffController/edit_personal");
        $smarty->assign("personaldeletedlink", "StaffController/delete_personal");
    }

}
if (!function_exists('PersonalAddAssign')) {

    function PersonalAddAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addpersonal", "add_personal");
        $smarty->assign('addnew', '../StaffController/personal_form');
        $smarty->assign('list', '');
        PersonalFormFieldLabel($smarty);
    }

}
if (!function_exists('PersonalFormAssign')) {

    function PersonalFormAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', '');
        $smarty->assign('list', 'staff/personal_list');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign('list', '../StaffController/personal_list');
        $smarty->assign('utils', '../utils');
        PersonalFormField($smarty);
        PersonalFormFieldLabel($smarty);
        PersonalFormFieldDEsc($smarty);

        $smarty->assign("personaleditedlink", "StaffController/edit_peersonal");
        $smarty->assign("personaldeletedlink", "StaffController/delete_personal");
    }

}

if (!function_exists('PersonalListAssign')) {

    function PersonalListAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addpersonal", "add_personal");
        $smarty->assign('addnew', '../StaffController/personal_form');
        $smarty->assign('list', '');
        PersonalFormFieldLabel($smarty);
    }

}
if (!function_exists('PersonalAddCancelAssign')) {

    function PersonalAddCancelAssign($smarty) {

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addpersonal", "add_personal");
        $smarty->assign('addnew', '../StaffController/personal_form');
        $smarty->assign('list', '');
    }

}

if (!function_exists('StaffCurrentLinkAssign')) {

    function StaffCurrentLinkAssign($smarty) {
        $smarty->assign('dashboardcurrent', '');
        $smarty->assign('utilscurrent', '');
        $smarty->assign('admincurrent', '');
        $smarty->assign('registrationcurrent', '');
        $smarty->assign('accountingcurrent', '');
        $smarty->assign('teachingcurrent', '');
        $smarty->assign('evaluationcurrent', '');
        $smarty->assign('staffcurrent', 'current');
        $smarty->assign('reportingcurrent', '');
        $smarty->assign('backupcurrent', '');
    }

}