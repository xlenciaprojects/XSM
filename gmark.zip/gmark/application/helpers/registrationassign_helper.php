<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!function_exists('RegistrationBarAssign')) {

    function RegistrationBarAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', 'registration/student_form');
        $smarty->assign('list', 'registration/student_list');
    }

}
if (!function_exists('RegistrationFormAssign')) {

    function RegistrationFormAssign($smarty) {
        $smarty->assign('addnew', '');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign('list', '../registration/student_list');
        $smarty->assign('utils', '../utils');
//        $smarty->assign("countryformname", "countryform");
//        $smarty->assign("formtitle", "Pays");
//        $smarty->assign("addcountry", "addcountry");
//        $smarty->assign("wording", "wording");
//        $smarty->assign("shortwording", "shortwording");
//        $smarty->assign("code", "code");
//        $smarty->assign("nationality", "nationality");
//
//        $smarty->assign("num", "N°");
//        $smarty->assign("wordinglabel", "Libellé");
//        $smarty->assign("shortwordinglabel", "Diminutif");
//        $smarty->assign("codelabel", "Code");
//        $smarty->assign("nationalitylabel", "Nationalité");
//
//        $smarty->assign("wordingdesc", "le nom du pays");
//        $smarty->assign("shortwordingdesc", "le nom abrévié ");
//        $smarty->assign("codedesc", "le Code d'identification");
//        $smarty->assign("nationalitydesc", "la nationalité");
//
//        $smarty->assign("countryeditedlink", "utils/edit_country");
//        $smarty->assign("countrydeletedlink", "utils/delete_country");
    }

}
if (!function_exists('RegistrationListAssign')) {

    function RegistrationListAssign($smarty) {
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign('addnew', '../registration/student_form');
        $smarty->assign('utils', '../utils');
    }

}

//student

if (!function_exists('StudentBarAssign')) {

    function StudentBarAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', 'registration/student_form');
        $smarty->assign('list', '');
    }

}
if (!function_exists('StudentFormField')) {

    function StudentFormField($smarty) {
        $smarty->assign("studentformtitle", "Apprenant");
        $smarty->assign("studentformname", "Ajour d'un apprenant");
        $smarty->assign("addstudent", "add_student");
        $smarty->assign("lastname", "lastname");
        $smarty->assign("firstname", "firstname");
        $smarty->assign("guardianname", "guardianname");
        $smarty->assign("guardianphone", "guardianphone");
        $smarty->assign("guardianmail", "guardianmail");
        $smarty->assign("adress", "adress");
        $smarty->assign("birthdate", "birthdate");
        $smarty->assign("bloodgroup", "bloodgroup");
        $smarty->assign("birthcity", "birthcity");
        $smarty->assign("gender", "gender");
        $smarty->assign("nationality", "nationality");
        $smarty->assign("oldschool", "oldschool");
        $smarty->assign("picture", "picture");
    }

}
if (!function_exists('StudentFormFieldLabel')) {

    function StudentFormFieldLabel($smarty) {
        $smarty->assign("num", "N°");
        $smarty->assign("lastnamelabel", "Nom");
        $smarty->assign("firstnamelabel", "Prénoms");
        $smarty->assign("matriculelabel", "Numero matricule");
        $smarty->assign("guardiannamelabel", "Nom du tuteur");
        $smarty->assign("guardianphonelabel", "Numero du tuteur");
        $smarty->assign("guardianmaillabel", "Mail du tuteur");
        $smarty->assign("adresslabel", "Adresse");
        $smarty->assign("birthdatelabel", "Date de Naissance");
        $smarty->assign("bloodgrouplabel", "Group Sanguin");
        $smarty->assign("birthcitylabel", "Ville de naissance");
        $smarty->assign("genderlabel", "Sexe");
        $smarty->assign("nationalitylabel", "Nationalité");
        $smarty->assign("schoollabel", "Etablissement de provenance");
        $smarty->assign("picturelabel", "Photo");
    }

}
if (!function_exists('StudentFormFieldDesc')) {

    function StudentFormFieldDesc($smarty) {
        $smarty->assign("lastnamedesc", "le noms de l'aprenant");
        $smarty->assign("firstnamedesc", "le prénoms de l'aprenant");
        $smarty->assign("guardiannamedesc", "le nom du tuteur");
        $smarty->assign("guardianphonedesc", "le numero du tuteur");
        $smarty->assign("guardianmaildesc", "le mail du tuteur");
        $smarty->assign("adressdesc", "l'adresse");
        $smarty->assign("birthdatedesc", "Date de Naissance");
        $smarty->assign("bloodgroupdesc", "Group Sanguin");
        $smarty->assign("birthcitydesc", "la ville de naissance");
        $smarty->assign("genderdesc", "le sexe");
        $smarty->assign("nationalitydesc", " choisir la nationalité");
        $smarty->assign("schooldesc", "Choisir l'établissement de provenance");
        $smarty->assign("picturedesc", "Choisir la photo");
    }

}
if (!function_exists('StudentAssign')) {

    function StudentAssign($smarty) {
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');

        $smarty->assign('list', 'registration/student_list');
        StudentFormField($smarty);
        StudentFormFieldLabel($smarty);
        StudentFormFieldDEsc($smarty);
        $smarty->assign("studenteditedlink", "registration/edit_student");
        $smarty->assign("studentdeletedlink", "registration/delete_student");
        StudentLinkAssign($smarty);  
    }

}
if (!function_exists('StudentAddAssign')) {

    function StudentAddAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign("addstudent", "add_student");
        $smarty->assign('addnew', '../registration/student_form');
        $smarty->assign('list', '');
        $smarty->assign("studenteditedlink", "../registration/edit_student");
        $smarty->assign("studentdeletedlink", "../registration/delete_student");
        StudentFormFieldLabel($smarty);
        StudentAddLinkAssign($smarty); 
    }

}
if (!function_exists('StudentFormAssign')) {

    function StudentFormAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', '');
        $smarty->assign('list', 'registration/student_list');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign('list', '../registration/student_list');
        StudentFormField($smarty);
        StudentFormFieldLabel($smarty);
        StudentFormFieldDEsc($smarty);

        $smarty->assign("studenteditedlink", "registration/edit_student");
        $smarty->assign("studentdeletedlink", "registration/delete_student");
        
        StudentFormLinkAssign($smarty);
    }

}
if (!function_exists('StudentEditAssign')) {

    function StudentEditAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', '');
        $smarty->assign('list', 'registration/student_list');

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('list', '../../registration/student_list');
        StudentFormField($smarty);
        StudentFormFieldLabel($smarty);
        StudentFormFieldDEsc($smarty);
        
        $smarty->assign("addstudent", "../add_student");
        $smarty->assign("studenteditedlink", "registration/edit_student");
        $smarty->assign("studentdeletedlink", "registration/delete_student");
        
        StudentEditLinkAssign($smarty);
    }

}

if (!function_exists('StudentListAssign')) {

    function StudentListAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addstudent", "add_student");
        $smarty->assign('addnew', '../registration/student_form');
        $smarty->assign('list', '');
        $smarty->assign("studenteditedlink", "../registration/edit_student");
        $smarty->assign("studentdeletedlink", "../registration/delete_student");
        StudentFormFieldLabel($smarty);
        StudentListLinkAssign($smarty); 
    }

}

if (!function_exists('StudentDeleteAssign')) {

    function StudentDeleteAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addstudent", "add_student");
        $smarty->assign('addnew', '../../registration/student_form');
        $smarty->assign('list', '');
        $smarty->assign("studenteditedlink", "../../registration/edit_student");
        $smarty->assign("studentdeletedlink", "../../registration/delete_student");
        StudentFormFieldLabel($smarty);
        StudentDeleteLinkAssign($smarty); 
    }

}
if (!function_exists('StudentAddCancelAssign')) {

    function StudentAddCancelAssign($smarty) {

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addstudent", "add_student");
        $smarty->assign('addnew', '../registration/student_form');
        $smarty->assign('list', '');
    }

}
//academicregistration
if (!function_exists('AcademicRegistrationBarAssign')) {

    function AcademicRegistrationBarAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', 'registration/academicregistration_form');
        $smarty->assign('list', 'registration/academicregistration_list');
    }

}

if (!function_exists('AcademicRegistrationAssign')) {

    function AcademicRegistrationAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', 'registration/academicregistration_form');
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        
        $smarty->assign('num', 'N°');
        $smarty->assign('lastnamelabel','Nom');
        $smarty->assign('firstnamelabel','Prenom(s)');
        $smarty->assign('registrationdatelabel','Date d\'inscription');
        $smarty->assign('unregistrationlabel','Désincrire');
        
        $smarty->assign("unregistrationlink", "registration/unregistration");
        
        AcademicRegistrationLinkAssign($smarty);
    }

}
if (!function_exists('AcademicRegistrationFormAssign')) {

    function AcademicRegistrationFormAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', '');
        $smarty->assign('list', '../registration/academicregistration_list');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        
        $smarty->assign("academicregistrationformname", "academicregistrationform");
        $smarty->assign("addacademicregistration", "../addacademicregistration");
        
        AcademicRegistrationFormLinkAssign($smarty);
    }

}

if (!function_exists('AcademicRegistrationAddAssign')) {

    function AcademicRegistrationAddAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', 'registration/academicregistration_form');
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        
         $smarty->assign('num', 'N°');
        $smarty->assign('lastnamelabel','Nom');
        $smarty->assign('firstnamelabel','Prenom(s)');
        $smarty->assign('registrationdatelabel','Date d\'inscription');
        $smarty->assign('unregistrationlabel','Désincrire');
        
        $smarty->assign("unregistrationlink", "registration/unregistration");
        
        AcademicRegistrationAddLinkAssign($smarty);
    }

}

if (!function_exists('AcademicRegistrationListAssign')) {

    function AcademicRegistrationListAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', '../registration/academicregistration_form');
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        
        $smarty->assign('num', 'N°');
        $smarty->assign('lastnamelabel','Nom');
        $smarty->assign('firstnamelabel','Prenom(s)');
        $smarty->assign('registrationdatelabel','Date d\'inscription');
        $smarty->assign('unregistrationlabel','Désincrire');
        
        $smarty->assign("unregistrationlink", "../registration/unregistration");
        
        AcademicRegistrationListLinkAssign($smarty);
    }

}
if (!function_exists('UnregistrationAssign')) {

    function UnregistrationAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', '../../registration/academicregistration_form');
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        
        $smarty->assign('num', 'N°');
        $smarty->assign('lastnamelabel','Nom');
        $smarty->assign('firstnamelabel','Prenom(s)');
        $smarty->assign('registrationdatelabel','Date d\'inscription');
        $smarty->assign('unregistrationlabel','Désincrire');
        
        $smarty->assign("unregistrationlink", "../../registration/unregistration");
        
        UnregistrationLinkAssign($smarty);
    }

}

if (!function_exists('RegistrationCurrentLinkAssign')) {

    function RegistrationCurrentLinkAssign($smarty) {
        $smarty->assign('dashboardcurrent', '');
        $smarty->assign('utilscurrent', '');
        $smarty->assign('admincurrent', '');
        $smarty->assign('registrationcurrent', 'current');
        $smarty->assign('accountingcurrent', '');
        $smarty->assign('teachingcurrent', '');
        $smarty->assign('evaluationcurrent', '');
        $smarty->assign('staffcurrent', '');
        $smarty->assign('reportingcurrent', '');
        $smarty->assign('backupcurrent', '');
    }

}