<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//permission
if (!function_exists('PermissionLinkAssign')) {

    function PermissionLinkAssign($smarty) {
        $smarty->assign('utils', 'utils');
    }

}

if (!function_exists('PermissionFormLinkAssign')) {

    function PermissionFormLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('users', '../users');
        $smarty->assign('role', '../role');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('PermissionAddLinkAssign')) {

    function PermissionAddLinkAssign($smarty) {
        $smarty->assign('home', '../../../home');
        $smarty->assign('utils', '../../../utils');
        $smarty->assign('users', '../../../users');
        $smarty->assign('role', '../../../role');
        $smarty->assign('academicyear', '../../../academicyear');
        $smarty->assign('school', '../../../school');
        $smarty->assign('fee', '../../../fee');
        $smarty->assign('modalitypayment', '../../../modalitypayment');
        $smarty->assign('payment', '../../../payment');
    }

}

if (!function_exists('PermissionListLinkAssign')) {

    function PermissionListLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('users', '../users');
        $smarty->assign('role', '../role');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('PermissionEditLinkAssign')) {

    function PermissionEditLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('users', '../../users');
        $smarty->assign('role', '../../role');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('PermissionDeleteLinkAssign')) {

    function PermissionDeleteLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('users', '../../users');
        $smarty->assign('role', '../../role');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}
//Role
if (!function_exists('RoleLinkAssign')) {

    function RoleLinkAssign($smarty) {
        $smarty->assign('utils', 'utils');
    }

}

if (!function_exists('RoleFormLinkAssign')) {

    function RoleFormLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('users', '../users');
        $smarty->assign('role', '../role');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('RoleAddLinkAssign')) {

    function RoleAddLinkAssign($smarty) {
        $smarty->assign('home', '../../../home');
        $smarty->assign('utils', '../../../utils');
        $smarty->assign('users', '../../../users');
        $smarty->assign('role', '../../../role');
        $smarty->assign('permission', '../../../permission');
        $smarty->assign('academicyear', '../../../academicyear');
        $smarty->assign('school', '../../../school');
        $smarty->assign('fee', '../../../fee');
        $smarty->assign('modalitypayment', '../../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('RoleListLinkAssign')) {

    function RoleListLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('users', '../users');
        $smarty->assign('role', '../role');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('RoleEditLinkAssign')) {

    function RoleEditLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('users', '../../users');
        $smarty->assign('role', '../../role');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('RoleDeleteLinkAssign')) {

    function RoleDeleteLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('users', '../../users');
        $smarty->assign('role', '../../role');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

//Users
if (!function_exists('UserLinkAssign')) {

    function UserLinkAssign($smarty) {
        $smarty->assign('utils', 'utils');
    }

}

if (!function_exists('UserFormLinkAssign')) {

    function UserFormLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('role', '../role');
        $smarty->assign('users', '../users');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('UserAddLinkAssign')) {

    function UserAddLinkAssign($smarty) {
        $smarty->assign('home', '../../../home');
        $smarty->assign('utils', '../../../utils');
        $smarty->assign('role', '../../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../../permission');
        $smarty->assign('academicyear', '../../../academicyear');
        $smarty->assign('school', '../../../school');
        $smarty->assign('fee', '../../../fee');
        $smarty->assign('modalitypayment', '../../../modalitypayment');
        $smarty->assign('payment', '../../../payment');
    }

}

if (!function_exists('UserListLinkAssign')) {

    function UserListLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('role', '../role');
        $smarty->assign('users', '../users');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('UserEditLinkAssign')) {

    function UserEditLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

//AcademicYear
if (!function_exists('AcademicYearLinkAssign')) {

    function AcademicYearLinkAssign($smarty) {
        $smarty->assign('utils', 'utils');
    }

}

if (!function_exists('AcademicYearFormLinkAssign')) {

    function AcademicYearFormLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('AcademicYearAddLinkAssign')) {

    function AcademicYearAddLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('AcademicYearListLinkAssign')) {

    function AcademicYearListLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('role', '../role');
        $smarty->assign('users', '../users');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('student', '../student');
        $smarty->assign('academicregistration', '../academicregistration');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('AcademicYearEditLinkAssign')) {

    function AcademicYearEditLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('AcademicYearDeleteLinkAssign')) {

    function AcademicYearDeleteLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

//School
if (!function_exists('SchoolLinkAssign')) {

    function SchoolLinkAssign($smarty) {
        $smarty->assign('utils', 'utils');
    }

}

if (!function_exists('SchoolFormLinkAssign')) {

    function SchoolFormLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('SchoolAddLinkAssign')) {

    function SchoolAddLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('SchoolListLinkAssign')) {

    function SchoolListLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('role', '../role');
        $smarty->assign('users', '../users');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('SchoolEditLinkAssign')) {

    function SchoolEditLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('SchoolDeleteLinkAssign')) {

    function SchoolDeleteLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}
//Payment
if (!function_exists('PaymentLinkAssign')) {

    function PaymentLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
    }

}

if (!function_exists('PaymentFormLinkAssign')) {

    function PaymentFormLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('role', '../role');
        $smarty->assign('users', '../users');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
        $smarty->assign('student', '../student');
        $smarty->assign('academicregistration', '../academicregistration');
    }

}

if (!function_exists('PaymentTestFormLinkAssign')) {

    function PaymentTestFormLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
    }

}

if (!function_exists('PaymentAddLinkAssign')) {

    function PaymentAddLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
        $smarty->assign('academicregistration', '../academicregistration');
    }

}

if (!function_exists('PaymentListLinkAssign')) {

    function PaymentListLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('role', '../role');
        $smarty->assign('users', '../users');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
        $smarty->assign('student', '../student');
        $smarty->assign('academicregistration', '../academicregistration');
    }

}

if (!function_exists('PaymentRestoreLinkAssign')) {

    function PaymentRestoreLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('PaymentAbandonLinkAssign')) {

    function PaymentAbandonLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('payment', '../../payment');
    }

}

//Fee
if (!function_exists('FeeLinkAssign')) {

    function FeeLinkAssign($smarty) {
        $smarty->assign('utils', 'utils');
    }

}

if (!function_exists('FeeFormLinkAssign')) {

    function FeeFormLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('FeeAddLinkAssign')) {

    function FeeAddLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('FeeListLinkAssign')) {

    function FeeListLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('role', '../role');
        $smarty->assign('users', '../users');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('student', '../student');
        $smarty->assign('academicregistration', '../academicregistration');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('FeeEditLinkAssign')) {

    function FeeEditLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('FeeDeleteLinkAssign')) {

    function FeeDeleteLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}
//Fee
if (!function_exists('ModalityLinkAssign')) {

    function ModalityLinkAssign($smarty) {
        $smarty->assign('utils', 'utils');
    }

}

if (!function_exists('ModalityFormLinkAssign')) {

    function ModalityFormLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('ModalityAddLinkAssign')) {

    function ModalityAddLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('ModalityListLinkAssign')) {

    function ModalityListLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('role', '../role');
        $smarty->assign('users', '../users');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('student', '../student');
        $smarty->assign('academicregistration', '../academicregistration');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('ModalityEditLinkAssign')) {

    function ModalityEditLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('ModalityDeleteLinkAssign')) {

    function ModalityDeleteLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('role', '../../role');
        $smarty->assign('users', '../../users');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('payment', '../../payment');
    }

}

//Student
if (!function_exists('StudentLinkAssign')) {

    function StudentLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('StudentFormLinkAssign')) {

    function StudentFormLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('users', '../users');
        $smarty->assign('role', '../role');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('student', '../student');
        $smarty->assign('academicregistration', '../academicregistration');
        $smarty->assign('courseregistration', '../courseregistration');
        $smarty->assign('registrationsummary', '../registrationsummary');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('StudentAddLinkAssign')) {

    function StudentAddLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('users', '../users');
        $smarty->assign('role', '../role');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('student', '../student');
        $smarty->assign('academicregistration', '../academicregistration');
        $smarty->assign('courseregistration', '../courseregistration');
        $smarty->assign('registrationsummary', '../registrationsummary');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('StudentListLinkAssign')) {

    function StudentListLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('users', '../users');
        $smarty->assign('role', '../role');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('student', '../student');
        $smarty->assign('academicregistration', '../academicregistration');
        $smarty->assign('courseregistration', '../courseregistration');
        $smarty->assign('registrationsummary', '../registrationsummary');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('StudentEditLinkAssign')) {

    function StudentEditLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('users', '../../users');
        $smarty->assign('role', '../../role');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('courseregistration', '../../courseregistration');
        $smarty->assign('registrationsummary', '../../registrationsummary');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('StudentDeleteLinkAssign')) {

    function StudentDeleteLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('users', '../../users');
        $smarty->assign('role', '../../role');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('courseregistration', '../../courseregistration');
        $smarty->assign('registrationsummary', '../../registrationsummary');
        $smarty->assign('payment', '../../payment');
    }

}

//Registration
if (!function_exists('AcademicRegistrationLinkAssign')) {

    function AcademicRegistrationLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('role', 'role');
        $smarty->assign('users', 'users');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', 'fee');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('AcademicRegistrationFormLinkAssign')) {

    function AcademicRegistrationFormLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('users', '../users');
        $smarty->assign('role', '../role');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('student', '../student');
        $smarty->assign('academicregistration', '../academicregistration');
        $smarty->assign('courseregistration', '../courseregistration');
        $smarty->assign('registrationsummary', '../registrationsummary');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('AcademicRegistrationAddLinkAssign')) {

    function AcademicRegistrationAddLinkAssign($smarty) {
        $smarty->assign('home', 'home');
        $smarty->assign('utils', 'utils');
        $smarty->assign('dashboard', 'dashboard');
        $smarty->assign('backup', 'backup');
        $smarty->assign('users', 'users');
        $smarty->assign('role', 'role');
        $smarty->assign('permission', 'permission');
        $smarty->assign('academicyear', 'academicyear');
        $smarty->assign('school', 'school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', 'modalitypayment');
        $smarty->assign('student', 'student');
        $smarty->assign('academicregistration', 'academicregistration');
        $smarty->assign('courseregistration', 'courseregistration');
        $smarty->assign('registrationsummary', 'registrationsummary');
        $smarty->assign('payment', 'payment');
    }

}

if (!function_exists('UnregistrationLinkAssign')) {

    function UnregistrationLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('users', '../../users');
        $smarty->assign('role', '../../role');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('courseregistration', '../../courseregistration');
        $smarty->assign('registrationsummary', '../../registrationsummary');
        $smarty->assign('payment', '../../payment');
    }

}

if (!function_exists('AcademicRegistrationListLinkAssign')) {

    function AcademicRegistrationListLinkAssign($smarty) {
        $smarty->assign('home', '../home');
        $smarty->assign('utils', '../utils');
        $smarty->assign('dashboard', '../dashboard');
        $smarty->assign('backup', '../backup');
        $smarty->assign('users', '../users');
        $smarty->assign('role', '../role');
        $smarty->assign('permission', '../permission');
        $smarty->assign('academicyear', '../academicyear');
        $smarty->assign('school', '../school');
        $smarty->assign('fee', '../fee');
        $smarty->assign('modalitypayment', '../modalitypayment');
        $smarty->assign('student', '../student');
        $smarty->assign('academicregistration', '../academicregistration');
        $smarty->assign('courseregistration', '../courseregistration');
        $smarty->assign('registrationsummary', '../registrationsummary');
        $smarty->assign('payment', '../payment');
    }

}

if (!function_exists('UtilDeleteLinkAssign')) {

    function UtilDeleteLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('users', '../../users');
        $smarty->assign('role', '../../role');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('courseregistration', '../../courseregistration');
        $smarty->assign('registrationsummary', '../../registrationsummary');
    }

}

if (!function_exists('UtilEditLinkAssign')) {

    function UtilEditLinkAssign($smarty) {
        $smarty->assign('home', '../../home');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('dashboard', '../../dashboard');
        $smarty->assign('backup', '../../backup');
        $smarty->assign('users', '../../users');
        $smarty->assign('role', '../../role');
        $smarty->assign('permission', '../../permission');
        $smarty->assign('academicyear', '../../academicyear');
        $smarty->assign('school', '../../school');
        $smarty->assign('fee', '../../fee');
        $smarty->assign('modalitypayment', '../../modalitypayment');
        $smarty->assign('student', '../../student');
        $smarty->assign('academicregistration', '../../academicregistration');
        $smarty->assign('courseregistration', '../../courseregistration');
        $smarty->assign('registrationsummary', '../../registrationsummary');
        $smarty->assign('payment', '../../payment');
    }

}