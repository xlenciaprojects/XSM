<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



if (!function_exists('AccountingCurrentLinkAssign')) {

    function AccountingCurrentLinkAssign($smarty) {
        $smarty->assign('dashboardcurrent', '');
        $smarty->assign('utilscurrent', '');
        $smarty->assign('admincurrent', '');
        $smarty->assign('registrationcurrent', '');
        $smarty->assign('accountingcurrent', 'current');
        $smarty->assign('teachingcurrent', '');
        $smarty->assign('evaluationcurrent', '');
        $smarty->assign('staffcurrent', '');
        $smarty->assign('reportingcurrent', '');
        $smarty->assign('backupcurrent', '');
    }

}

//Payment

if (!function_exists('PaymentFieldAssign')) {

    function PaymentFieldAssign($smarty) {

        $smarty->assign("amountpaid", "amountpaid");
        $smarty->assign("amounttopaid", "amounttopaid");
        $smarty->assign("resttopaid", "resttopaid");
        $smarty->assign("paymentdate", "paymentdate");
        $smarty->assign("paymentstudent", "paymentstudent");
        $smarty->assign("paymentfee", "paymentfee");
        $smarty->assign("paymentmodalitypayment", "paymentmodalitypayment");
        $smarty->assign("steppayment", "steppayement");
        $smarty->assign("paymentacademicyear", "paymentacademicyear");

        $smarty->assign("num", "N°");
        $smarty->assign("amountpaidlabel", "Montant payé");
        $smarty->assign("amounttopaidlabel", "Montant à payer");
        $smarty->assign("resttopaidlabel", "Reste à payer");
        $smarty->assign("paymentdatelabel", "Date de paiement");
        $smarty->assign("paymentstudentlabel", "Apprenant");
        $smarty->assign("paymentfeelabel", "Frais");
        $smarty->assign("paymentmodalitypaymentlabel", "Modalité de paiement");
        $smarty->assign("steppaymentlabel", "Modalité de paiement par étape");
        $smarty->assign("paymentacademicyearlabel", "Année scolaire");

        $smarty->assign("amountpaiddesc", "Montant payé");
        $smarty->assign("amounttopaiddesc", "Montant à payer");
        $smarty->assign("resttopaiddesc", "Reste à payer");
        $smarty->assign("paymentdatedesc", "Date de paiement");
        $smarty->assign("paymentstudentdesc", "Apprenant");
        $smarty->assign("paymentfeedesc", "Frais");
        $smarty->assign("paymentmodalitypaymentdesc", "Modalité de paiement");
        $smarty->assign("steppaymentdesc", "Modalité de paiement par étape");
        $smarty->assign("paymentacademicyeardesc", "Année scolaire");
    }

}

if (!function_exists('PaymentRegistrationFieldAssign')) {

    function PaymentRegistrationFieldAssign($smarty) {

        $smarty->assign("amountpaid", "amountpaid");
        $smarty->assign("amounttopaid", "amounttopaid");
        $smarty->assign("resttopaid", "resttopaid");
        $smarty->assign("paymentdate", "paymentdate");
        $smarty->assign("paymentstudent", "paymentstudent");
        $smarty->assign("paymentfee", "paymentfee");
        $smarty->assign("paymentmodalitypayment", "paymentmodalitypayment");
        $smarty->assign("steppayment", "steppayement");
        $smarty->assign("paymentacademicyear", "paymentacademicyear");

        $smarty->assign("num", "N°");
        $smarty->assign("amountpaidlabel", "Montant payé");
        $smarty->assign("amounttopaidlabel", "Montant à payer");
        $smarty->assign("resttopaidlabel", "Reste à payer");
        $smarty->assign("paymentdatelabel", "Date de paiement");
        $smarty->assign("paymentstudentlabel", "Apprenant");
        $smarty->assign("paymentfeelabel", "Frais");
        $smarty->assign("paymentmodalitypaymentlabel", "Modalité de paiement");
        $smarty->assign("steppaymentlabel", "Modalité de paiement par étape");
        $smarty->assign("paymentacademicyearlabel", "Année scolaire");

        $smarty->assign("amountpaiddesc", "Montant payé");
        $smarty->assign("amounttopaiddesc", "Montant à payer");
        $smarty->assign("resttopaiddesc", "Reste à payer");
        $smarty->assign("paymentdatedesc", "Date de paiement");
        $smarty->assign("paymentstudentdesc", "Apprenant");
        $smarty->assign("paymentfeedesc", "Frais");
        $smarty->assign("paymentmodalitypaymentdesc", "Modalité de paiement");
        $smarty->assign("steppaymentdesc", "Modalité de paiement par étape");
        $smarty->assign("paymentacademicyeardesc", "Année scolaire");
    }

}

if (!function_exists('PrintPaymentListFieldAssign')) {

    function PrintPaymentListFieldAssign($smarty) {

        
        $smarty->assign("printpaymentlistformname", "printpaymentlistform");
        $smarty->assign("printpaymentlistformtitle", "Impression de la liste de paiement");
        $smarty->assign("printpaymentlist", "../printpaymentlist");
        $smarty->assign("startdate", "startdate");
        $smarty->assign("enddate", "enddate");
        $smarty->assign("startdatelabel", "Date de début");
        $smarty->assign("enddatelabel", "Date de fin");
        $smarty->assign("startdatedesc", "Date de début");
        $smarty->assign("enddatedesc", "Date de fin");
        $smarty->assign("printpaymentlistlabel", "Imprimer la liste");
    }

}

if (!function_exists('PaymentFormAssign')) {

    function PaymentFormAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('schoolfee', '');
        $smarty->assign('registrationfee', '');
        $smarty->assign('list', '../accounting/payment_list');
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign("paymentformname", "paymentform");
        $smarty->assign("paymentformtitle", "Paiement");
        $smarty->assign("addpayment", "../addpayment");
        PaymentFieldAssign($smarty);

        PaymentFormLinkAssign($smarty);
    }

}
if (!function_exists('SchoolFeeFormAssign')) {

    function SchoolFeeFormAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('schoolfee', '');
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfee', '../accounting/registrationfee_form');
        $smarty->assign('list', '../accounting/payment_list');
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign("paymentformname", "paymentform");
        $smarty->assign("paymentformtitle", "Paiement");
        $smarty->assign("addpayment", "../addpayment");
        PaymentFieldAssign($smarty);

        PaymentFormLinkAssign($smarty);
    }

}

if (!function_exists('SchoolFeeTestFormAssign')) {

    function SchoolFeeTestFormAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('schoolfee', '');
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfee', '../../accounting/registrationfee_form');
        $smarty->assign('list', '../../accounting/payment_list');
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');

        $smarty->assign("paymentformname", "paymentform");
        $smarty->assign("paymentformtitle", "Paiement");
        $smarty->assign("addpayment", "../../addpayment");
        PaymentFieldAssign($smarty);

        PaymentTestFormLinkAssign($smarty);
    }

}

if (!function_exists('RegistrationFeeFormAssign')) {

    function RegistrationFeeFormAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('schoolfee', '../accounting/schoolfee_form');
        $smarty->assign('registrationfee', '');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');
        $smarty->assign('list', '../accounting/payment_list');
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign("paymentformname", "paymentform");
        $smarty->assign("paymentformtitle", "Paiement");
        $smarty->assign("addpayment", "../addpayment");
        PaymentFieldAssign($smarty);

        PaymentFormLinkAssign($smarty);
    }

}

if (!function_exists('PaymentFallFormAssign')) {

    function PaymentFallFormAssign($smarty) {
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('schoolfee', 'accounting/schoolfee_form');
        $smarty->assign('registrationfee', 'accounting/registrationfee_form');
        $smarty->assign('list', 'accounting/payment_list');
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');

        $smarty->assign("paymentformname", "paymentform");
        $smarty->assign("paymentformtitle", "Paiement");
        $smarty->assign("addpayment", "addpayment");
        PaymentFieldAssign($smarty);

        PaymentFormLinkAssign($smarty);
    }

}

if (!function_exists('PaymentListAssign')) {

    function PaymentListAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('schoolfee', '../accounting/schoolfee_form');
        $smarty->assign('registrationfee', '../accounting/registrationfee_form');
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign("addpayment", "addpayment");

        $smarty->assign("abandonlabel", "Abandonner");
        $smarty->assign("restorelabel", "Restaurer");

        $smarty->assign("num", "N°");
        $smarty->assign("amountpaidlabel", "Montant payé");
        $smarty->assign("paymentdatelabel", "Date de paiement");
        $smarty->assign("paymentstudentlabel", "Apprenant");
        $smarty->assign("paymentfeelabel", "Frais");
        $smarty->assign("paymentmodalitypaymentlabel", "Modalité de paiement");
        $smarty->assign("steppaymentlabel", "Modalité de paiement par étape");
        $smarty->assign("paymentacademicyearlabel", "Année scolaire");
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');

        $smarty->assign("paymentrestorelink", "../accounting/restore_payment");
        $smarty->assign("paymentabandonlink", "../accounting/abandon_payment");
        $smarty->assign("printreceiptlink", "../accounting/print_receipt");
        PrintPaymentListFieldAssign($smarty);
        PaymentListLinkAssign($smarty);
    }

}
if (!function_exists('PaymentAssign')) {

    function PaymentAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('schoolfee', 'accounting/schoolfee_form');
        $smarty->assign('registrationfee', 'accounting/registrationfee_form');
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign("addpayment", "addpayment");

        $smarty->assign("abandonlabel", "Abandonner");
        $smarty->assign("restorelabel", "Restaurer");

        $smarty->assign("num", "N°");
        $smarty->assign("amountpaidlabel", "Montant payé");
        $smarty->assign("paymentdatelabel", "Date de paiement");
        $smarty->assign("studentlabel", "Apprenant");
        $smarty->assign("feelabel", "Frais");
        $smarty->assign("modalitypaymentlabel", "Modalité de paiement");
        $smarty->assign("steppaymentlabel", "Modalité de paiement par étape");
        $smarty->assign("academicyearlabel", "Année scolaire");
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');

        $smarty->assign("paymentrestorelink", "../accounting/restore_payment");
        $smarty->assign("paymentabandonlink", "../accounting/abandon_payment");
        $smarty->assign("printreceiptlink", "accounting/print_receipt");
        PrintPaymentListFieldAssign($smarty);
        
        $smarty->assign("printpaymentlist", "printpaymentlist");
        PaymentLinkAssign($smarty);
    }

}

if (!function_exists('PaymentRestoreAssign')) {

    function PaymentRestoreAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('schoolfee', '../../accounting/schoolfee_form');
        $smarty->assign('registrationfee', '../../accounting/registrationfee_form');
        $smarty->assign('list', '');
        
        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addpayment", "../../addpayment");

        $smarty->assign("addpayment", "addpayment");

        $smarty->assign("abandonlabel", "Abandonner");
        $smarty->assign("restorelabel", "Restaurer");

        $smarty->assign("num", "N°");
        $smarty->assign("amountpaidlabel", "Montant payé");
        $smarty->assign("paymentdatelabel", "Date de paiement");
        $smarty->assign("studentlabel", "Apprenant");
        $smarty->assign("feelabel", "Frais");
        $smarty->assign("modalitypaymentlabel", "Modalité de paiement");
        $smarty->assign("steppaymentlabel", "Modalité de paiement par étape");
        $smarty->assign("academicyearlabel", "Année scolaire");
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');

        $smarty->assign("paymentrestorelink", "../../accounting/restore_payment");
        $smarty->assign("paymentabandonlink", "../../accounting/abandon_payment");
        $smarty->assign("printreceiptlink", "../../accounting/print_receipt");
        PrintPaymentListFieldAssign($smarty);
        PaymentRestoreLinkAssign($smarty);
    }

}

if (!function_exists('PaymentAbandonAssign')) {

    function PaymentAbandonAssign($smarty) {
        
        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('schoolfee', '../../accounting/schoolfee_form');
        $smarty->assign('registrationfee', '../../accounting/registrationfee_form');
        $smarty->assign('list', '');
        
        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addpayment", "../../addpayment");

        $smarty->assign("addpayment", "addpayment");

        $smarty->assign("abandonlabel", "Abandonner");
        $smarty->assign("restorelabel", "Restaurer");

        $smarty->assign("num", "N°");
        $smarty->assign("amountpaidlabel", "Montant payé");
        $smarty->assign("paymentdatelabel", "Date de paiement");
        $smarty->assign("studentlabel", "Apprenant");
        $smarty->assign("feelabel", "Frais");
        $smarty->assign("modalitypaymentlabel", "Modalité de paiement");
        $smarty->assign("steppaymentlabel", "Modalité de paiement par étape");
        $smarty->assign("academicyearlabel", "Année scolaire");
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');

        $smarty->assign("paymentrestorelink", "../../accounting/restore_payment");
        $smarty->assign("paymentabandonlink", "../../accounting/abandon_payment");
        $smarty->assign("printreceiptlink", "../../accounting/print_receipt");
        PrintPaymentListFieldAssign($smarty);
        PaymentAbandonLinkAssign($smarty);
    }

}

if (!function_exists('PaymentAddAssign')) {

    function PaymentAddAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('schoolfee', 'accounting/schoolfee_form');
        $smarty->assign('registrationfee', 'accounting/registrationfee_form');
        $smarty->assign('list', '');
        $smarty->assign('schoolfeelabel', 'Frais Scolarité');
        $smarty->assign('registrationfeelabel', 'Frais Inscription');
        
        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        
        PaymentFieldAssign($smarty);

        $smarty->assign("paymentrestorelink", "accounting/restore_payment");
        $smarty->assign("paymentabandonlink", "accounting/abandon_payment");
        $smarty->assign("printreceiptlink", "accounting/print_receipt");
        PrintPaymentListFieldAssign($smarty);
        $smarty->assign("printpaymentlist", "printpaymentlist");
        PaymentAddLinkAssign($smarty);
    }

}
