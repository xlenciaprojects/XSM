<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// Admin
if (!function_exists('AdminAssign')) {

    function AdminAssign($smarty) {

        $smarty->assign("schoolformname", "schoolform");
        $smarty->assign("schoolformtitle", "Etablissement");
        $smarty->assign("addschool", "addschool");
        $smarty->assign("schoolwording", "schoolwording");
        $smarty->assign("schoolcode", "schoolcode");

        $smarty->assign("num", "N°");
        $smarty->assign("schoolwordinglabel", "Libellé");
        $smarty->assign("schoolcodelabel", "Code");

        $smarty->assign("schoolwordingdesc", "le libellé");
        $smarty->assign("schoolcodedesc", "le code");

        $smarty->assign("schooleditedlink", "admin/edit_school");
        $smarty->assign("schooldeletedlink", "admin/delete_school");
    }

}

// School
if (!function_exists('SchoolFormAssign')) {

    function SchoolFormAssign($smarty) {

        $smarty->assign("schoolformname", "schoolform");
        $smarty->assign("schoolformtitle", "Etablissement");
        $smarty->assign("addschool", "addschool");
        $smarty->assign("schoolwording", "schoolwording");
        $smarty->assign("schoolcode", "schoolcode");

        $smarty->assign("num", "N°");
        $smarty->assign("schoolwordinglabel", "Libellé");
        $smarty->assign("schoolcodelabel", "Code");

        $smarty->assign("schoolwordingdesc", "le libellé");
        $smarty->assign("schoolcodedesc", "le code");

        $smarty->assign("schooleditedlink", "admin/edit_school");
        $smarty->assign("schooldeletedlink", "admin/delete_school");
        
        SchoolFormLinkAssign($smarty);
    }

}

if (!function_exists('SchoolListAssign')) {

    function SchoolListAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addschool", "../../addschool");
        
        SchoolListLinkAssign($smarty);
    }

}

if (!function_exists('SchoolEditAssign')) {

    function SchoolEditAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addschool", "../../addschool");
        $smarty->assign("schooleditedlink", "../../admin/edit_school");
        $smarty->assign("schooldeletedlink", "../../admin/delete_school");
        
        SchoolEditLinkAssign($smarty);
    }

}

if (!function_exists('SchoolDeleteAssign')) {

    function SchoolDeleteAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('school', '../../school');
        $smarty->assign("addschool", "../../addschool");
        $smarty->assign("schooleditedlink", "../../admin/edit_school");
        $smarty->assign("schooldeletedlink", "../../admin/delete_school");
        
        SchoolDeleteLinkAssign($smarty);
    }

}

if (!function_exists('SchoolAddAssign')) {

    function SchoolAddAssign($smarty) {

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addschool", "addschool");
        
        SchoolAddLinkAssign($smarty);
    }

}

// Step Modality 
if (!function_exists('StepModalityFormAssign')) {

    function StepModalityFormAssign($smarty) {

        $smarty->assign("schoolformname", "schoolform");
        $smarty->assign("schoolformtitle", "Etablissement");
        $smarty->assign("addschool", "addschool");
        $smarty->assign("schoolwording", "schoolwording");
        $smarty->assign("schoolcode", "schoolcode");

        $smarty->assign("num", "N°");
        $smarty->assign("schoolwordinglabel", "Libellé");
        $smarty->assign("schoolcodelabel", "Code");

        $smarty->assign("schoolwordingdesc", "le libellé");
        $smarty->assign("schoolcodedesc", "le code");

        $smarty->assign("schooleditedlink", "admin/edit_school");
        $smarty->assign("schooldeletedlink", "admin/delete_school");
    }

}

if (!function_exists('ModalityListAssign')) {

    function ModalityListAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addschool", "../../addschool");
    }

}

if (!function_exists('ModalityEditAssign')) {

    function ModalityEditAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addschool", "../../addschool");
        $smarty->assign("schooleditedlink", "../../admin/edit_school");
        $smarty->assign("schooldeletedlink", "../../admin/delete_school");
    }

}

if (!function_exists('ModalityDeleteAssign')) {

    function ModalityDeleteAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('school', '../../school');
        $smarty->assign("addschool", "../../addschool");
        $smarty->assign("schooleditedlink", "../../admin/edit_school");
        $smarty->assign("schooldeletedlink", "../../admin/delete_school");
    }

}

if (!function_exists('ModalityAddAssign')) {

    function ModalityAddAssign($smarty) {

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');
        $smarty->assign("addschool", "addschool");
    }

}

// Block Modality
if (!function_exists('BlockModalityFormAssign')) {

    function BlockModalityFormAssign($smarty) {

        $smarty->assign("schoolformname", "schoolform");
        $smarty->assign("schoolformtitle", "Etablissement");
        $smarty->assign("addschool", "addschool");
        $smarty->assign("schoolwording", "schoolwording");
        $smarty->assign("schoolcode", "schoolcode");

        $smarty->assign("num", "N°");
        $smarty->assign("schoolwordinglabel", "Libellé");
        $smarty->assign("schoolcodelabel", "Code");

        $smarty->assign("schoolwordingdesc", "le libellé");
        $smarty->assign("schoolcodedesc", "le code");

        $smarty->assign("schooleditedlink", "admin/edit_school");
        $smarty->assign("schooldeletedlink", "admin/delete_school");
    }

}

// Academic year
if (!function_exists('AcademicYearFormAssign')) {

    function AcademicYearFormAssign($smarty) {

        $smarty->assign("academicyearformname", "academicyearform");
        $smarty->assign("academicyearformtitle", "Année Scolaire");
        $smarty->assign("addacademicyear", "addacademicyear");
        $smarty->assign("academicyearwording", "academicyearwording");
        $smarty->assign("academicyearcode", "academicyearcode");
        $smarty->assign("academicyearcurrent", "academicyearcurrent");

        $smarty->assign("num", "N°");
        $smarty->assign("academicyearwordinglabel", "Libellé");
        $smarty->assign("academicyearcodelabel", "Code");
        $smarty->assign("academicyearcurrentlabel", "Activer");

        $smarty->assign("academicyearwordingdesc", "le libellé (expl:Année scolaire 2016-2017)");
        $smarty->assign("academicyearcodedesc", "le code (expl:2016-2017)");
        $smarty->assign("academicyearcurrentdesc", "rendre active l'année scolaire");

        $smarty->assign("academicyeareditedlink", "admin/edit_academicyear");
        $smarty->assign("academicyeardeletedlink", "admin/delete_academicyear");
        
        AcademicYearFormLinkAssign($smarty);
    }

}

if (!function_exists('AcademicYearListAssign')) {

    function AcademicYearListAssign($smarty) {

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addacademicyear", "add_academicyear");

        $smarty->assign("academicyearformname", "academicyearform");
        $smarty->assign("academicyearformtitle", "Année Scolaire");
        $smarty->assign("academicyearwording", "academicyearwording");
        $smarty->assign("academicyearcode", "academicyearcode");
        $smarty->assign("academicyearcurrent", "academicyearcurrent");

        $smarty->assign("num", "N°");
        $smarty->assign("academicyearwordinglabel", "Libellé");
        $smarty->assign("academicyearcodelabel", "Code");
        $smarty->assign("academicyearcurrentlabel", "Activer");

        $smarty->assign("academicyearwordingdesc", "le libellé (expl:Année scolaire 2016-2017)");
        $smarty->assign("academicyearcodedesc", "le code (expl:2016-2017)");
        $smarty->assign("academicyearcurrentdesc", "rendre active l'année scolaire");

        $smarty->assign("academicyeareditedlink", "../admin/edit_academicyear");
        $smarty->assign("academicyeardeletedlink", "../admin/delete_academicyear");
        
        AcademicYearListLinkAssign($smarty);
    }

}

if (!function_exists('AcademicYearEditAssign')) {

    function AcademicYearEditAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("academicyearformname", "academicyearform");
        $smarty->assign("academicyearformtitle", "Année Scolaire");
        $smarty->assign("addacademicyear", "addacademicyear");
        $smarty->assign("academicyearwording", "academicyearwording");
        $smarty->assign("academicyearcode", "academicyearcode");
        $smarty->assign("academicyearcurrent", "academicyearcurrent");
        $smarty->assign("academicyearwordinglabel", "Libellé");
        $smarty->assign("academicyearcodelabel", "Code");
        $smarty->assign("academicyearcurrentlabel", "Activer");
        $smarty->assign("addacademicyear", "../add_academicyear");
        $smarty->assign("academicyeareditedlink", "../../admin/edit_academicyear");
        $smarty->assign("academicyeardeletedlink", "../../admin/delete_academicyear");
        
        AcademicYearEditLinkAssign($smarty);
    }

}

if (!function_exists('AcademicYearDeleteAssign')) {

    function AcademicYearDeleteAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign('school', '../../school');
        $smarty->assign("academicyearformname", "academicyearform");
        $smarty->assign("academicyearformtitle", "Année Scolaire");
        $smarty->assign("addacademicyear", "../../add_academicyear");
        $smarty->assign("academicyearwording", "academicyearwording");
        $smarty->assign("academicyearcode", "academicyearcode");
        $smarty->assign("academicyearcurrent", "academicyearcurrent");

        $smarty->assign("num", "N°");
        $smarty->assign("academicyearwordinglabel", "Libellé");
        $smarty->assign("academicyearcodelabel", "Code");
        $smarty->assign("academicyearcurrentlabel", "Activer");

        $smarty->assign("academicyearwordingdesc", "le libellé (expl:Année scolaire 2016-2017)");
        $smarty->assign("academicyearcodedesc", "le code (expl:2016-2017)");
        $smarty->assign("academicyearcurrentdesc", "rendre active l'année scolaire");
        $smarty->assign("academicyeareditedlink", "../../admin/edit_academicyear");
        $smarty->assign("academicyeardeletedlink", "../../admin/delete_academicyear");
        
        AcademicYearDeleteLinkAssign($smarty);
    }

}

if (!function_exists('AcademicYearAddAssign')) {

    function AcademicYearAddAssign($smarty) {

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign("addacademicyear", "addacademicyear");
        $smarty->assign("academicyearformname", "academicyearform");
        $smarty->assign("academicyearformtitle", "Année Scolaire");
        $smarty->assign("academicyearwording", "academicyearwording");
        $smarty->assign("academicyearcode", "academicyearcode");
        $smarty->assign("academicyearcurrent", "academicyearcurrent");

        $smarty->assign("num", "N°");
        $smarty->assign("academicyearwordinglabel", "Libellé");
        $smarty->assign("academicyearcodelabel", "Code");
        $smarty->assign("academicyearcurrentlabel", "Activer");

        $smarty->assign("academicyearwordingdesc", "le libellé (expl:Année scolaire 2016-2017)");
        $smarty->assign("academicyearcodedesc", "le code (expl:2016-2017)");
        $smarty->assign("academicyearcurrentdesc", "rendre active l'année scolaire");

        $smarty->assign("academicyeareditedlink", "admin/edit_academicyear");
        $smarty->assign("academicyeardeletedlink", "admin/delete_academicyear");
        
        AcademicYearAddLinkAssign($smarty);
    }

}

// Fee
if (!function_exists('FeeFormAssign')) {

    function FeeFormAssign($smarty) {

        $smarty->assign("feeformname", "feeform");
        $smarty->assign("feeformtitle", "Frais scolaire");
        $smarty->assign("addfee", "addfee");
        $smarty->assign("feeamount", "feeamount");
        $smarty->assign("feeclass", "feeclass");
        $smarty->assign("feetype", "feetype");

        $smarty->assign("num", "N°");
        $smarty->assign("feelabel", "Libellé");
        $smarty->assign("feeamountlabel", "Montant (cfa)");
        $smarty->assign("feeclasslabel", "Classe");
        $smarty->assign("feetypelabel", "Type de frais");

        $smarty->assign("feeamountdesc", "le montant du frais");

        $smarty->assign("feeeditedlink", "admin/edit_fee");
        $smarty->assign("feedeletedlink", "admin/delete_fee");
        
        FeeFormLinkAssign($smarty);
    }

}

if (!function_exists('FeeListAssign')) {

    function FeeListAssign($smarty) {

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign("addfee", "add_fee");

        $smarty->assign("feeamount", "feeamount");
        $smarty->assign("feeclass", "feeclass");
        $smarty->assign("feetype", "feetype");

        $smarty->assign("num", "N°");
        $smarty->assign("feelabel", "Libellé");
        $smarty->assign("feeamountlabel", "Montant (cfa)");
        $smarty->assign("feeclasslabel", "Classe");
        $smarty->assign("feetypelabel", "Type de frais");

        $smarty->assign("feeeditedlink", "../admin/edit_fee");
        $smarty->assign("feedeletedlink", "../admin/delete_fee");
        
        FeeListLinkAssign($smarty);
    }

}

if (!function_exists('FeeEditAssign')) {

    function FeeEditAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addfee", "../../addfee");
        $smarty->assign("feeamount", "feeamount");
        $smarty->assign("feeclass", "feeclass");
        $smarty->assign("feetype", "feetype");

        $smarty->assign("num", "N°");
        $smarty->assign("feelabel", "Libellé");
        $smarty->assign("feeamountlabel", "Montant (cfa)");
        $smarty->assign("feeclasslabel", "Classe");
        $smarty->assign("feetypelabel", "Type de frais");

        $smarty->assign("feeeditedlink", "../../admin/edit_fee");
        $smarty->assign("feedeletedlink", "../../admin/delete_fee");
        
        FeeEditLinkAssign($smarty);
    }

}

if (!function_exists('FeeDeleteAssign')) {

    function FeeDeleteAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addfee", "../../addfee");
        $smarty->assign("feeamount", "feeamount");
        $smarty->assign("feeclass", "feeclass");
        $smarty->assign("feetype", "feetype");

        $smarty->assign("num", "N°");
        $smarty->assign("feelabel", "Libellé");
        $smarty->assign("feeamountlabel", "Montant");
        $smarty->assign("feeclasslabel", "Classe");
        $smarty->assign("feetypelabel", "Type de frais");

        $smarty->assign("feeeditedlink", "../../admin/edit_fee");
        $smarty->assign("feedeletedlink", "../../admin/delete_fee");
        
        FeeDeleteLinkAssign($smarty);
    }

}

if (!function_exists('FeeAddAssign')) {

    function FeeAddAssign($smarty) {

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        $smarty->assign('utils', 'utils');

        $smarty->assign("addfee", "addfee");
        $smarty->assign("feeamount", "feeamount");
        $smarty->assign("feeclass", "feeclass");
        $smarty->assign("feetype", "feetype");

        $smarty->assign("num", "N°");
        $smarty->assign("feelabel", "Libellé");
        $smarty->assign("feeamountlabel", "Montant");
        $smarty->assign("feeclasslabel", "Classe");
        $smarty->assign("feetypelabel", "Type de frais");

        $smarty->assign("feeeditedlink", "admin/edit_fee");
        $smarty->assign("feedeletedlink", "admin/delete_fee");
        
        FeeAddLinkAssign($smarty);
    }

}

//Block payment
if (!function_exists('BlockPaymentFormAssign')) {

    function BlockPaymentFormAssign($smarty) {

        $smarty->assign("blockpaymentformname", "blockpaymentform");
        $smarty->assign("blockpaymentformtitle", "Modalité de paiement en block");
        $smarty->assign("addblockpayment", "addblockpayment");
        $smarty->assign("blockfee", "blockfee");
        $smarty->assign("blockdelay", "blockdelay");

        $smarty->assign("num", "N°");
        $smarty->assign("blockpaymentlabel", "Libellé");
        $smarty->assign("blockfeelabel", "Frais");
        $smarty->assign("blockdelaylabel", "Date d'échéance ");

        $smarty->assign("blockpaymenteditedlink", "admin/edit_block_payment");
        $smarty->assign("blockpaymentdeletedlink", "admin/delete_block_payment");
    }

}

if (!function_exists('BlockPaymentListAssign')) {

    function BlockPaymentListAssign($smarty) {

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign('utils', '../../utils');
        $smarty->assign("addblockpayment", "addblockpayment");
        $smarty->assign("blockfee", "blockfee");
        $smarty->assign("blockdelay", "blockdelay");

        $smarty->assign("num", "N°");
        $smarty->assign("blockpaymentlabel", "Libellé");
        $smarty->assign("blockfeelabel", "Frais");
        $smarty->assign("blockdelaylabel", "Date d'échéance ");

        $smarty->assign("blockpaymenteditedlink", "../admin/edit_block_payment");
        $smarty->assign("blockpaymentdeletedlink", "../admin/delete_block_payment");
    }

}

if (!function_exists('BlockPaymentEditAssign')) {

    function BlockPaymentEditAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("blockpaymentformname", "blockpaymentform");
        $smarty->assign("blockpaymentformtitle", "Modalité de paiement en block");
        $smarty->assign("addblockpayment", "../../addblockpayment");
        $smarty->assign("blockfee", "blockfee");
        $smarty->assign("blockdelay", "blockdelay");

        $smarty->assign("num", "N°");
        $smarty->assign("blockpaymentlabel", "Libellé");
        $smarty->assign("blockfeelabel", "Frais");
        $smarty->assign("blockdelaylabel", "Date d'échéance ");

        $smarty->assign("blockpaymenteditedlink", "../../admin/edit_block_payment");
        $smarty->assign("blockpaymentdeletedlink", "../../admin/delete_block_payment");
        
        $smarty->assign("steppaymenteditedlink", "../../admin/edit_step_payment");
        $smarty->assign("steppaymentdeletedlink", "../../admin/delete_step_payment");
        
        ModalityEditLinkAssign($smarty);
    }

}

if (!function_exists('BlockPaymentDeleteAssign')) {

    function BlockPaymentDeleteAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addblockpayment", "../../addblockpayment");
        $smarty->assign("blockfee", "blockfee");
        $smarty->assign("blockdelay", "blockdelay");

        $smarty->assign("num", "N°");
        $smarty->assign("blockpaymentlabel", "Libellé");
        $smarty->assign("blockfeelabel", "Frais");
        $smarty->assign("blockdelaylabel", "Date d'échéance ");

        $smarty->assign("blockpaymenteditedlink", "../../admin/edit_block_payment");
        $smarty->assign("blockpaymentdeletedlink", "../../admin/delete_block_payment");
        
        $smarty->assign("steppaymenteditedlink", "../../admin/edit_step_payment");
        $smarty->assign("steppaymentdeletedlink", "../../admin/delete_step_payment");
        
        ModalityDeleteLinkAssign($smarty);
    }

}

if (!function_exists('BlockPaymentAddAssign')) {

    function BlockPaymentAddAssign($smarty) {

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');

        $smarty->assign("addblockpayment", "addblockpayment");
        $smarty->assign("blockfee", "blockfee");
        $smarty->assign("blockdelay", "blockdelay");

        $smarty->assign("num", "N°");
        $smarty->assign("blockpaymentlabel", "Libellé");
        $smarty->assign("blockfeelabel", "Frais");
        $smarty->assign("blockdelaylabel", "Date d'échéance ");

        $smarty->assign("blockpaymenteditedlink", "admin/edit_block_payment");
        $smarty->assign("blockpaymentdeletedlink", "admin/delete_block_payment");
        
        ModalityAddLinkAssign($smarty);
    }

}

//Step payment
if (!function_exists('StepPaymentFormAssign')) {

    function StepPaymentFormAssign($smarty) {

        $smarty->assign("steppaymentformname", "steppaymentform");
        $smarty->assign("steppaymentformtitle", "Modalité de paiement en échéance");
        $smarty->assign("addsteppayment", "addsteppayment");
        $smarty->assign("stepfee", "stepfee");
        $smarty->assign("stepnumber", "stepnumber");
        $smarty->assign("stepdelay", "stepdelay");

        $smarty->assign("num", "N°");
        $smarty->assign("steppaymentlabel", "Libellé");
        $smarty->assign("stepfeelabel", "Frais");
        $smarty->assign("stepnumberlabel", "Nombre d'échéance");
        $smarty->assign("stepdelaylabel", "Date d'échéance ");

        $smarty->assign("steppaymenteditedlink", "admin/edit_step_payment");
        $smarty->assign("steppaymentdeletedlink", "admin/delete_step_payment");
    }

}

if (!function_exists('StepPaymentListAssign')) {

    function StepPaymentListAssign($smarty) {

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        $smarty->assign("addsteppayment", "addsteppayment");
        $smarty->assign("stepfee", "stepfee");
        $smarty->assign("stepnumber", "stepnumber");
        $smarty->assign("stepdelay", "stepdelay");

        $smarty->assign("num", "N°");
        $smarty->assign("steppaymentlabel", "Libellé");
        $smarty->assign("stepfeelabel", "Frais");
        $smarty->assign("stepnumberlabel", "Nombre d'échéance");
        $smarty->assign("stepdelaylabel", "Date d'échéance ");

        $smarty->assign("steppaymenteditedlink", "../admin/edit_step_payment");
        $smarty->assign("steppaymentdeletedlink", "../admin/delete_step_payment");
    }

}

if (!function_exists('StepPaymentEditAssign')) {

    function StepPaymentEditAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("steppaymentformname", "steppaymentform");
        $smarty->assign("steppaymentformtitle", "Modalité de paiement en échéance");
        $smarty->assign("addsteppayment", "../../addsteppayment");
        $smarty->assign("stepfee", "stepfee");
        $smarty->assign("stepnumber", "stepnumber");
        $smarty->assign("stepdelay", "stepdelay");

        $smarty->assign("num", "N°");
        $smarty->assign("steppaymentlabel", "Libellé");
        $smarty->assign("stepfeelabel", "Frais");
        $smarty->assign("stepnumberlabel", "Nombre d'échéance");
        $smarty->assign("stepdelaylabel", "Date d'échéance ");

        $smarty->assign("steppaymenteditedlink", "../../admin/edit_step_payment");
        $smarty->assign("steppaymentdeletedlink", "../../admin/delete_step_payment");
        
        $smarty->assign("blockpaymenteditedlink", "../../admin/edit_block_payment");
        $smarty->assign("blockpaymentdeletedlink", "../../admin/delete_block_payment");
        
        ModalityEditLinkAssign($smarty);
    }

}

if (!function_exists('StepPaymentDeleteAssign')) {

    function StepPaymentDeleteAssign($smarty) {

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        $smarty->assign("addsteppayment", "../../addsteppayment");
        $smarty->assign("stepfee", "stepfee");
        $smarty->assign("stepnumber", "stepnumber");
        $smarty->assign("stepdelay", "stepdelay");

        $smarty->assign("num", "N°");
        $smarty->assign("steppaymentlabel", "Libellé");
        $smarty->assign("stepfeelabel", "Frais");
        $smarty->assign("stepnumberlabel", "Nombre d'échéance");
        $smarty->assign("stepdelaylabel", "Date d'échéance ");

        $smarty->assign("steppaymenteditedlink", "../../admin/edit_step_payment");
        $smarty->assign("steppaymentdeletedlink", "../../admin/delete_step_payment");
        
        $smarty->assign("blockpaymenteditedlink", "../../admin/edit_block_payment");
        $smarty->assign("blockpaymentdeletedlink", "../../admin/delete_block_payment");
        
        ModalityDeleteLinkAssign($smarty);
    }

}

if (!function_exists('StepPaymentAddAssign')) {

    function StepPaymentAddAssign($smarty) {

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');

        $smarty->assign("addsteppayment", "addsteppayment");
        $smarty->assign("stepfee", "stepfee");
        $smarty->assign("stepnumber", "stepnumber");
        $smarty->assign("stepdelay", "stepdelay");

        $smarty->assign("num", "N°");
        $smarty->assign("steppaymentlabel", "Libellé");
        $smarty->assign("stepfeelabel", "Frais");
        $smarty->assign("stepnumberlabel", "Nombre d'échéance");
        $smarty->assign("stepdelaylabel", "Date d'échéance ");

        $smarty->assign("steppaymenteditedlink", "admin/edit_step_payment");
        $smarty->assign("steppaymentdeletedlink", "admin/delete_step_payment");
        
        ModalityAddLinkAssign($smarty);
    }

}

// permission
if (!function_exists('PermissionBarAssign')) {

    function PermissionBarAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', 'admin/permission_form');
        $smarty->assign('list', 'admin/permission_list');
    }

}

if (!function_exists('PermissionAssign')) {

    function PermissionAssign($smarty) {

        $smarty->assign('addnew', 'admin/permission_form');
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
 
        $smarty->assign("permissioneditedlink", "admin/edit_permission");
        $smarty->assign("permissiondeletedlink", "admin/delete_permission");
        
        PermissionLinkAssign($smarty);
    }

}

if (!function_exists('PermissionFormAssign')) {

    function PermissionFormAssign($smarty) {

        $smarty->assign('addnew', '');
        $smarty->assign('list', '../admin/permission_list');
        
        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        
        $smarty->assign("permissionformname", "permissionform");
        $smarty->assign("permissionformtitle", "Permission");
        $smarty->assign("addpermission", "add_permission");
        $smarty->assign("permissionwording", "permissionwording");
        $smarty->assign("permissiondescription", "permissiondescription");

        $smarty->assign("num", "N°");
        $smarty->assign("permissionwordinglabel", "Libellé");
        $smarty->assign("permissiondescriptionlabel", "Description");

        $smarty->assign("permissionwordingdesc", "le libellé");
        $smarty->assign("permissiondescriptiondesc", "la description");

        $smarty->assign("permissioneditedlink", "admin/edit_permission");
        $smarty->assign("permissiondeletedlink", "admin/delete_permission");
        
        PermissionFormLinkAssign($smarty);
    }

}

if (!function_exists('PermissionListAssign')) {

    function PermissionListAssign($smarty) {
        
        $smarty->assign('addnew', '../admin/permission_form');
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        
        $smarty->assign("addpermission", "../../addpermission");

        $smarty->assign("permissionformname", "permissionform");
        $smarty->assign("permissionformtitle", "Permission");
        $smarty->assign("permissionwording", "permissionwording");
        $smarty->assign("permissiondescription", "permissiondescription");

        $smarty->assign("num", "N°");
        $smarty->assign("permissionwordinglabel", "Libellé");
        $smarty->assign("permissiondescriptionlabel", "Description");

        $smarty->assign("permissionwordingdesc", "le libellé");
        $smarty->assign("permissiondescriptiondesc", "la description");
        
        $smarty->assign("permissioneditedlink", "../admin/edit_permission");
        $smarty->assign("permissiondeletedlink", "../admin/delete_permission");
        
        PermissionListLinkAssign($smarty);
    }

}

if (!function_exists('PermissionEditAssign')) {

    function PermissionEditAssign($smarty) {

        $smarty->assign('addnew', '');
        $smarty->assign('list', '../../admin/permission_list');
        
        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        
        $smarty->assign("addpermission", "../../addpermission");
        $smarty->assign("permissioneditedlink", "../../admin/edit_permission");
        $smarty->assign("permissiondeletedlink", "../../admin/delete_permission");

        $smarty->assign("permissionformname", "permissionform");
        $smarty->assign("permissionformtitle", "Permission");
        $smarty->assign("permissionwording", "permissionwording");
        $smarty->assign("permissiondescription", "permissiondescription");

        $smarty->assign("num", "N°");
        $smarty->assign("permissionwordinglabel", "Libellé");
        $smarty->assign("permissiondescriptionlabel", "Description");

        $smarty->assign("permissionwordingdesc", "le libellé");
        $smarty->assign("permissiondescriptiondesc", "la description");
        
        PermissionEditLinkAssign($smarty);
    }

}

if (!function_exists('PermissionDeleteAssign')) {

    function PermissionDeleteAssign($smarty) {
        
        $smarty->assign('addnew', '../admin/permission_form');
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../../../assets/css/');
        $smarty->assign('page_js_url', '../../../assets/js/');
        
        $smarty->assign('permission', '../../permission');
        $smarty->assign("addpermission", "../../addpermission");
        $smarty->assign("permissioneditedlink", "../../admin/edit_permission");
        $smarty->assign("permissiondeletedlink", "../../admin/delete_permission");

        $smarty->assign("permissionformname", "permissionform");
        $smarty->assign("permissionformtitle", "Permission");
        $smarty->assign("permissionwording", "permissionwording");
        $smarty->assign("permissiondescription", "permissiondescription");

        $smarty->assign("num", "N°");
        $smarty->assign("permissionwordinglabel", "Libellé");
        $smarty->assign("permissiondescriptionlabel", "Description");

        $smarty->assign("permissionwordingdesc", "le libellé");
        $smarty->assign("permissiondescriptiondesc", "la description");
        
        PermissionDeleteLinkAssign($smarty);
    }

}

if (!function_exists('PermissionAddAssign')) {

    function PermissionAddAssign($smarty) {

        $smarty->assign('addnew', '../admin/permission_form');
        $smarty->assign('list', '');
        
        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');
        
        $smarty->assign("addpermission", "addpermission");

        $smarty->assign("permissionformname", "permissionform");
        $smarty->assign("permissionformtitle", "Permission");
        $smarty->assign("permissionwording", "permissionwording");
        $smarty->assign("permissiondescription", "permissiondescription");

        $smarty->assign("num", "N°");
        $smarty->assign("permissionwordinglabel", "Libellé");
        $smarty->assign("permissiondescriptionlabel", "Description");

        $smarty->assign("permissionwordingdesc", "le libellé");
        $smarty->assign("permissiondescriptiondesc", "la description");
        
        PermissionAddLinkAssign($smarty);
    }

}

//role
if (!function_exists('RoleBarAssign')) {

    function RoleBarAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', 'admin/role_form');
        $smarty->assign('list', 'admin/role_list');
    }

}

if (!function_exists('RoleAssign')) {

    function RoleAssign($smarty) {

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');
        
        $smarty->assign('addnew', 'admin/role_form');
        
        $smarty->assign("roleformname", "roleform");
        $smarty->assign("roleformtitle", "Rôle");
        $smarty->assign("rolewording", "rolewording");
        $smarty->assign("roledescription", "roledescription");

        $smarty->assign("num", "N°");
        $smarty->assign("rolewordinglabel", "Libellé");
        $smarty->assign("roledescriptionlabel", "Description");

        $smarty->assign("rolewordingdesc", "le libellé");
        $smarty->assign("roledescriptiondesc", "la description");

        $smarty->assign("addrole", "../addrole");
        $smarty->assign("cancelrole", "../cancelrole");
    }

}

if (!function_exists('RoleFormAssign')) {

    function RoleFormAssign($smarty) {
        $smarty->assign('addnew', '');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign('list', '../admin/role_list');
        $smarty->assign("roleformname", "roleform");
        $smarty->assign("roleformtitle", "Rôle");
        $smarty->assign("rolewording", "rolewording");
        $smarty->assign("roledescription", "roledescription");

        $smarty->assign("num", "N°");
        $smarty->assign("rolewordinglabel", "Libellé");
        $smarty->assign("roledescriptionlabel", "Description");

        $smarty->assign("rolewordingdesc", "le libellé");
        $smarty->assign("roledescriptiondesc", "la description");

        $smarty->assign("addrole", "../addrole");
        $smarty->assign("cancelrole", "../cancelrole");
        
        RoleFormLinkAssign($smarty);
    }

}
if (!function_exists('RoleListAssign')) {

    function RoleListAssign($smarty) {
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign("roleformname", "roleform");
        $smarty->assign("roleformtitle", "Rôle");
        $smarty->assign("rolewording", "rolewording");
        $smarty->assign("roledescription", "roledescription");

        $smarty->assign("num", "N°");
        $smarty->assign("rolewordinglabel", "Libellé");
        $smarty->assign("roledescriptionlabel", "Description");

        $smarty->assign("rolewordingdesc", "le libellé");
        $smarty->assign("roledescriptiondesc", "la description");

        $smarty->assign('addnew', '../admin/role_form');
        $smarty->assign('utils', '../utils');
        
         RoleListLinkAssign($smarty);
    }

}

//Users
if (!function_exists('UserBarAssign')) {

    function UserBarAssign($smarty) {

        $smarty->assign('havastatusbar', 'yes');
        $smarty->assign('addnew', 'admin/user_form');
        $smarty->assign('list', 'admin/user_list');
    }

}
if (!function_exists('UsersFormAssign')) {

    function UserFormAssign($smarty) {
        $smarty->assign('addnew', '');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign('list', '../admin/user_list');
        $smarty->assign("userformname", "userform");
        $smarty->assign("userformtitle", "Utilisateur");
        $smarty->assign("login", "login");
        $smarty->assign("password", "password");
        $smarty->assign("staff", "staff");
        $smarty->assign("uservalidated", "uservalidated");

        $smarty->assign("num", "N°");
        $smarty->assign("loginlabel", "Nom d'utilisateur");
        $smarty->assign("passwordlabel", "Mot de passe");
        $smarty->assign("stafflabel", "Personnel");
        $smarty->assign("uservalidatedlabel", "Actif");

        $smarty->assign("logindesc", "le nom d'utilisateur ou le pseudo ou le login");
        $smarty->assign("passworddesc", "le mot de passe");
        $smarty->assign("staffdesc", "le personnel");
        $smarty->assign("uservalidateddesc", "Activer");

        $smarty->assign("adduser", "../adduser");
        $smarty->assign("canceluser", "../canceluser");
        
        UserFormLinkAssign($smarty);
    }

}
if (!function_exists('UserAssign')) {

    function UserAssign($smarty) {
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../assets/css/');
        $smarty->assign('page_js_url', '../assets/js/');

        $smarty->assign("userformname", "userform");
        $smarty->assign("userformtitle", "Utilisateur");
        $smarty->assign("login", "login");
        $smarty->assign("password", "password");
        $smarty->assign("staff", "staff");
        $smarty->assign("uservalidated", "uservalidated");

        $smarty->assign("num", "N°");
        $smarty->assign("loginlabel", "Nom d'utilisateur");
        $smarty->assign("passwordlabel", "Mot de passe");
        $smarty->assign("stafflabel", "Personnel");
        $smarty->assign("uservalidatedlabel", "Actif");

        $smarty->assign("logindesc", "le nom d'utilisateur ou le pseudo ou le login");
        $smarty->assign("passworddesc", "le mot de passe");
        $smarty->assign("staffdesc", "le personnel");
        $smarty->assign("uservalidateddesc", "Activer");

        $smarty->assign('addnew', 'admin/user_form');

        UserAssign($smarty);
        
    }

}

if (!function_exists('UserListAssign')) {

    function UserListAssign($smarty) {
        $smarty->assign('list', '');

        $smarty->assign('page_css_url', '../../assets/css/');
        $smarty->assign('page_js_url', '../../assets/js/');

        $smarty->assign("userformname", "userform");
        $smarty->assign("userformtitle", "Utilisateur");
        $smarty->assign("login", "login");
        $smarty->assign("password", "password");
        $smarty->assign("staff", "staff");
        $smarty->assign("uservalidated", "uservalidated");
    $smarty->assign("num", "N°");
        $smarty->assign("loginlabel", "Nom d'utilisateur");
        $smarty->assign("passwordlabel", "Mot de passe");
        $smarty->assign("stafflabel", "Personnel");
        $smarty->assign("uservalidatedlabel", "Actif");

        $smarty->assign("logindesc", "le nom d'utilisateur ou le pseudo ou le login");
        $smarty->assign("passworddesc", "le mot de passe");
        $smarty->assign("staffdesc", "le personnel");
        $smarty->assign("uservalidateddesc", "Activer");

        $smarty->assign('addnew', '../admin/user_form');
        
        UserListLinkAssign($smarty);
    }

}
    

if (!function_exists('AdminCurrentLinkAssign')) {

    function AdminCurrentLinkAssign($smarty) {
        $smarty->assign('dashboardcurrent', '');
        $smarty->assign('utilscurrent', '');
        $smarty->assign('admincurrent', 'current');
        $smarty->assign('registrationcurrent', '');
        $smarty->assign('accountingcurrent', '');
        $smarty->assign('teachingcurrent', '');
        $smarty->assign('evaluationcurrent', '');
        $smarty->assign('staffcurrent', '');
        $smarty->assign('reportingcurrent', '');
        $smarty->assign('backupcurrent', '');
    }

}