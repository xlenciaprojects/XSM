<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class CRUD {

    function __construct() {
        
    }

    public function create($service, $entity) {
        $service->saveOne($entity);
    }

    public function delete($service, $id, $state) {
        $entity = $service->getOne($id);
        $entity->setState($state);
        $service->updateOne($entity);
    }

    public function read($service) {
        return $service->getAll();
    }
    
    public function size($service) {
        return $service->size();
    }
    
    public function read_sort_asc($service, $sortProperty) {
        return $service->getAllValidatedWithSortAndOrder($sortProperty, "ASC");
    }
    
    public function read_sort_desc($service, $sortProperty) {
        return $service->getAllValidatedWithSortAndOrder($sortProperty, "DESC");
    }

    public function update($service, $entity) {
        $service->updateOne($entity);
    }
    
    public function find($service, $id) {
        return $service->getOne($id);
    }
    
    public function build_entity_object_list($service){
        $list = $this->read($service);
        $data = new \ArrayIterator();
        foreach ($list as $item){ 
            $data->append($service->getOne($item->getId()));
        }
        return $data;
    }
    
    public function build_entity_object_list_sort_asc($service, $sortProperty){
        $list = $this->read_sort_asc($service, $sortProperty);
        $data = new \ArrayIterator();
        foreach ($list as $item){ 
            $data->append($service->getOne($item->getId()));
        }
        return $data;
    }
    
    public function build_entity_object_list_sort_desc($service, $sortProperty){
        $list = $this->read_sort_desc($service, $sortProperty);
        $data = new \ArrayIterator();
        foreach ($list as $item){ 
            $data->append($service->getOne($item->getId()));
        }
        return $data;
    }
    
    public function build_data_list($list){
        $data = new \ArrayIterator();
        foreach ($list as $item){ 
            $data->append($service->getOne($obj->getId()));
        }
        return $data;
    }

}
