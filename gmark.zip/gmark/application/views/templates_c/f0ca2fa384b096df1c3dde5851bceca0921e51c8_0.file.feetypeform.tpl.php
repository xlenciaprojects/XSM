<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/feetype/feetypeform.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6ab2cad6_45066144',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f0ca2fa384b096df1c3dde5851bceca0921e51c8' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/feetype/feetypeform.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6ab2cad6_45066144 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15341856858867a6ab2c372_02002959', "content");
}
/* {block "content"} */
class Block_15341856858867a6ab2c372_02002959 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <fieldset class="">
        <legend class=""><?php echo $_smarty_tpl->tpl_vars['feetypeformtitle']->value;?>
</legend>
        <form name="<?php echo $_smarty_tpl->tpl_vars['feetypeformname']->value;?>
" class="form-horizontal" action="<?php echo $_smarty_tpl->tpl_vars['addfeetype']->value;?>
" method="POST">
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['feetypewording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['feetypewordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['feetypewording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['feetypewordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['feetypewordingdesc']->value;?>
">
                </div>
            </div>

            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['feetypecode']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['feetypecodelabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['feetypecode']->value;?>
" class="form-control" type="text" id="idcode" value="<?php echo $_smarty_tpl->tpl_vars['feetypecodevalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['feetypecodedesc']->value;?>
">
                </div>
            </div>

             <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['feetypedescription']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['feetypedescriptionlabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['feetypedescription']->value;?>
" class="form-control" type="text" id="shortwording" value="<?php echo $_smarty_tpl->tpl_vars['feetypedescriptionvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['feetypedescriptiondesc']->value;?>
">
                </div>
            </div>

            <div class="float-right">
                <button type="submit" class="btn btn-success btn-sm "><?php echo $_smarty_tpl->tpl_vars['savelabel']->value;?>
</button>      
                <button type="reset" class="btn btn-danger btn-sm"><?php echo $_smarty_tpl->tpl_vars['cancellabel']->value;?>
</button>
            </div>
        </form>
    </fieldset> 
<?php
}
}
/* {/block "content"} */
}
