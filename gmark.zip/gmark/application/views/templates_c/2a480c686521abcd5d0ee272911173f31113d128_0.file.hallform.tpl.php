<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/hall/hallform.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6abac780_96997342',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2a480c686521abcd5d0ee272911173f31113d128' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/hall/hallform.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6abac780_96997342 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_23649106058867a6abac2e6_14717855', "content");
}
/* {block "content"} */
class Block_23649106058867a6abac2e6_14717855 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <fieldset class="">
        <legend class="">Classe</legend>
        <form class="form-horizontal" action="">
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="wording"><span>Libellé Long</span></label>
                <div class="col-sm-10">
                    <input class="form-control" type="text" id="wording" placeholder="la valeur du Libellé Long de la classe">
                </div>
            </div>
            
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="wording"><span>Libellé Moyen</span></label>
                <div class="col-sm-10">
                    <input class="form-control" type="text" id="wording" placeholder="la valeur du Libellé Moyen de la classe">
                </div>
            </div>
            
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="wording"><span>Libellé Court</span></label>
                <div class="col-sm-10">
                    <input class="form-control" type="text" id="wording" placeholder="la valeur du Libellé Court de la classe">
                </div>
            </div>

            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="shortwording"><span>Description</span></label>
                <div class="col-sm-10">
                    <input class="form-control" type="text" id="shortwording" placeholder="une briève description de la classe ">
                </div>
            </div>

            <div class="float-right">
                <button type="submit" class="btn btn-success btn-sm ">Enregistrer</button>      
                <button type="reset" class="btn btn-danger btn-sm">Annuler</button>

            </div>
        </form>
    </fieldset> 
<?php
}
}
/* {/block "content"} */
}
