<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/feetype/feetypepage.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6ab21ce0_62214827',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8b576a9d53861efdc1bcd6aa169d9fc0b518546d' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/feetype/feetypepage.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:utils/feetype/feetypeform.tpl' => 1,
    'file:utils/feetype/feetypelist.tpl' => 1,
  ),
),false)) {
function content_58867a6ab21ce0_62214827 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_47909913258867a6ab21667_79509018', "content");
}
/* {block "content"} */
class Block_47909913258867a6ab21667_79509018 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="col-sm-10 col-sm-push-1">
        <?php if (isset($_smarty_tpl->tpl_vars['info']->value) && $_smarty_tpl->tpl_vars['info']->value != '') {?>
            <div class="alert alert-info" role="alert"><?php echo $_smarty_tpl->tpl_vars['info']->value;?>
</div>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['success']->value) && $_smarty_tpl->tpl_vars['success']->value != '') {?>
            <div class="alert alert-success" role="alert"><?php echo $_smarty_tpl->tpl_vars['success']->value;?>
</div>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['warning']->value) && $_smarty_tpl->tpl_vars['warning']->value != '') {?>
            <div class="alert alert-warning" role="alert"><?php echo $_smarty_tpl->tpl_vars['warning']->value;?>
</div>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['error']->value) && $_smarty_tpl->tpl_vars['error']->value != '') {?>
            <div class="alert alert-danger" role="alert"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</div>
        <?php }?>
        <!-- formulaire -->
        <?php $_smarty_tpl->_subTemplateRender("file:utils/feetype/feetypeform.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <!-- Table -->
        <br>
        <?php $_smarty_tpl->_subTemplateRender("file:utils/feetype/feetypelist.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </div>
<?php
}
}
/* {/block "content"} */
}
