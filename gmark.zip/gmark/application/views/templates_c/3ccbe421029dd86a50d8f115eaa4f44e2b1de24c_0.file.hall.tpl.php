<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/hall/hall.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6aba9560_22247451',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3ccbe421029dd86a50d8f115eaa4f44e2b1de24c' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/hall/hall.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:utils/hall/hallform.tpl' => 1,
    'file:utils/hall/halllist.tpl' => 1,
  ),
),false)) {
function content_58867a6aba9560_22247451 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_186287857658867a6aba90b6_66285407', "content");
}
/* {block "content"} */
class Block_186287857658867a6aba90b6_66285407 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="col-sm-6 ">
        <!-- formulaire -->
        <?php $_smarty_tpl->_subTemplateRender("file:utils/hall/hallform.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <!-- Table -->
        <br>
        <?php $_smarty_tpl->_subTemplateRender("file:utils/hall/halllist.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </div>
<?php
}
}
/* {/block "content"} */
}
