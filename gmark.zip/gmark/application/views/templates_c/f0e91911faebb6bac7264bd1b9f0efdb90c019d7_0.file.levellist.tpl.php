<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/level/levellist.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6abdab06_24982780',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f0e91911faebb6bac7264bd1b9f0efdb90c019d7' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/level/levellist.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6abdab06_24982780 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_87453565858867a6abda397_09997101', "content");
}
/* {block "content"} */
class Block_87453565858867a6abda397_09997101 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="table">
        <div class="col-sm-3 col-md-3 pull-right">
            <input type="text" class="form-control" placeholder="Rechercher" name="q">
        </div>
        <table id="mytable" class="table table-bordred table-striped">
            <thead>
            <th><input type="checkbox" id="checkall" /></th>
            <th><?php echo $_smarty_tpl->tpl_vars['num']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['levelwordinglabel']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['levelcodelabel']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['leveldescriptionlabel']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['editlabel']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['deletelabel']->value;?>
</th>
            </thead>
            <tbody>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['leveldatalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                    <tr>
                        <td><input type="checkbox" class="checkthis" /></td>
                        <td><?php echo (isset($_smarty_tpl->tpl_vars['__smarty_foreach_data']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_data']->value['index'] : null);?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['data']->value->getWording();?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['data']->value->getcode();?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['data']->value->getDescription();?>
</td>
                        <td>
                            <p data-placement="top" data-toggle="tooltip" title="Edit">
                                <a href="<?php echo $_smarty_tpl->tpl_vars['leveleditedlink']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
" class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit" >
                                    <span class="glyphicon glyphicon-pencil"></span>
                                </a>
                            </p>
                        </td>
                        <td>
                            <p data-placement="top" data-toggle="tooltip" title="Delete">
                                <a href="<?php echo $_smarty_tpl->tpl_vars['leveldeletedlink']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" >
                                    <span class="glyphicon glyphicon-trash"></span>
                                </a>
                            </p>
                        </td>
                    </tr>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

            </tbody>
        </table>
    </div>
<?php
}
}
/* {/block "content"} */
}
