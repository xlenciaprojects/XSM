<?php
/* Smarty version 3.1.30, created on 2017-01-13 09:44:19
  from "/home/mundhaka/public_html/gmark/application/views/templates/dashboard/dashboard.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5878a17322d3f7_62925223',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bfd6e311db8fcce524b51f5566083109844b8612' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/dashboard/dashboard.tpl',
      1 => 1484297669,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.tpl' => 1,
    'file:nav/navbar.tpl' => 1,
  ),
),false)) {
function content_5878a17322d3f7_62925223 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php $_smarty_tpl->_assignInScope('nav', "nav");
$_smarty_tpl->_assignInScope('content', "content");
$_smarty_tpl->_subTemplateRender("file:nav/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2736764455878a17322c187_55525121', "container");
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:index.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block "container"} */
class Block_2736764455878a17322c187_55525121 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <h1>tableau de bord</h1>
<?php
}
}
/* {/block "container"} */
}
