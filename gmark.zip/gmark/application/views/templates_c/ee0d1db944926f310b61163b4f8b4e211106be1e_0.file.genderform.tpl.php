<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/gender/genderform.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6ab53622_82570927',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ee0d1db944926f310b61163b4f8b4e211106be1e' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/gender/genderform.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6ab53622_82570927 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_38390395558867a6ab52eb5_09179765', "content");
}
/* {block "content"} */
class Block_38390395558867a6ab52eb5_09179765 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <fieldset class="">
        <legend class=""><?php echo $_smarty_tpl->tpl_vars['genderformtitle']->value;?>
</legend>
        <form name="<?php echo $_smarty_tpl->tpl_vars['genderformname']->value;?>
" class="form-horizontal" action="<?php echo $_smarty_tpl->tpl_vars['addgender']->value;?>
" method="POST">
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['genderlongwording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['genderlongwordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['genderlongwording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['genderlongwordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['genderlongwordingdesc']->value;?>
">
                </div>
            </div>
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['gendermediumwording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['gendermediumwordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['gendermediumwording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['gendermediumwordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['gendermediumwordingdesc']->value;?>
">
                </div>
            </div>
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['gendershortwording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['gendershortwordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['gendershortwording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['gendershortwordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['gendershortwordingdesc']->value;?>
">
                </div>
            </div>

            <div class="float-right">
                <button type="submit" class="btn btn-success btn-sm "><?php echo $_smarty_tpl->tpl_vars['savelabel']->value;?>
</button>      
                <button type="reset" class="btn btn-danger btn-sm"><?php echo $_smarty_tpl->tpl_vars['cancellabel']->value;?>
</button>
            </div>
        </form>
    </fieldset> 
<?php
}
}
/* {/block "content"} */
}
