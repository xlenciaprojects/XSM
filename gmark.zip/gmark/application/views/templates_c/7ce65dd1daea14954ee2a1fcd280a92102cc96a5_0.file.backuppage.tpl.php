<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:51:04
  from "/home/mundhaka/public_html/gmark/application/views/templates/backup/backuppage.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867ac8f293f7_14342804',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7ce65dd1daea14954ee2a1fcd280a92102cc96a5' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/backup/backuppage.tpl',
      1 => 1484297669,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.tpl' => 1,
    'file:nav/navbar.tpl' => 1,
    'file:backup/backupform.tpl' => 1,
  ),
),false)) {
function content_58867ac8f293f7_14342804 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php $_smarty_tpl->_assignInScope('nav', "nav");
$_smarty_tpl->_assignInScope('content', "content");
$_smarty_tpl->_subTemplateRender("file:nav/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_38965644558867ac8f282d9_34328196', "container");
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:index.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block "container"} */
class Block_38965644558867ac8f282d9_34328196 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php $_smarty_tpl->_subTemplateRender("file:backup/backupform.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php
}
}
/* {/block "container"} */
}
