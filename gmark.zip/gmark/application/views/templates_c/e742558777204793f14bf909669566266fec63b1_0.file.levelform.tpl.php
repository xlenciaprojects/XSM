<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/level/levelform.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6abcbe78_89292806',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e742558777204793f14bf909669566266fec63b1' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/level/levelform.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6abcbe78_89292806 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_41170835258867a6abcb5b9_32322994', "content");
}
/* {block "content"} */
class Block_41170835258867a6abcb5b9_32322994 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <fieldset class="">
        <legend class=""><?php echo $_smarty_tpl->tpl_vars['levelformtitle']->value;?>
</legend>
        <form name="<?php echo $_smarty_tpl->tpl_vars['levelformname']->value;?>
" class="form-horizontal" action="<?php echo $_smarty_tpl->tpl_vars['addlevel']->value;?>
" method="POST">
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['levelwording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['levelwordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['levelwording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['levelwordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['levelwordingdesc']->value;?>
">
                </div>
            </div>

            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['levelcode']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['levelcodelabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['levelcode']->value;?>
" class="form-control" type="text" id="idcode" value="<?php echo $_smarty_tpl->tpl_vars['levelcodevalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['levelcodedesc']->value;?>
">
                </div>
            </div>

             <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['leveldescription']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['leveldescriptionlabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['leveldescription']->value;?>
" class="form-control" type="text" id="shortwording" value="<?php echo $_smarty_tpl->tpl_vars['leveldescriptionvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['leveldescriptiondesc']->value;?>
">
                </div>
            </div>

            <div class="float-right">
                <button type="submit" class="btn btn-success btn-sm "><?php echo $_smarty_tpl->tpl_vars['savelabel']->value;?>
</button>      
                <button type="reset" class="btn btn-danger btn-sm"><?php echo $_smarty_tpl->tpl_vars['cancellabel']->value;?>
</button>
            </div>
        </form>
    </fieldset> 
<?php
}
}
/* {/block "content"} */
}
