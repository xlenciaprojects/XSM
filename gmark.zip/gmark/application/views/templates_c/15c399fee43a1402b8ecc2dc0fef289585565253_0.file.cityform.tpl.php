<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/locality/cityform.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6ab048a6_85361761',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '15c399fee43a1402b8ecc2dc0fef289585565253' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/locality/cityform.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6ab048a6_85361761 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_85026852458867a6ab03c14_73650655', "content");
}
/* {block "content"} */
class Block_85026852458867a6ab03c14_73650655 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <fieldset class="">
        <legend class=""><?php echo $_smarty_tpl->tpl_vars['cityformtitle']->value;?>
</legend>
        <form name="<?php echo $_smarty_tpl->tpl_vars['cityformname']->value;?>
" class="form-horizontal" action="<?php echo $_smarty_tpl->tpl_vars['addcity']->value;?>
" method="POST">
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['citywording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['citywordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['citywording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['citywordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['citywordingdesc']->value;?>
">
                </div>
            </div>

            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['citydescription']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['citydescriptionlabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['citydescription']->value;?>
" class="form-control" type="text" id="shortwording" value="<?php echo $_smarty_tpl->tpl_vars['citydescriptionvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['citydescriptiondesc']->value;?>
">
                </div>
            </div>

            <div class="form-group form-group-sm">
                <label name="<?php echo $_smarty_tpl->tpl_vars['citycountry']->value;?>
" class="col-sm-2 control-label" for="country" ><span><?php echo $_smarty_tpl->tpl_vars['citycountrylabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <select name="<?php echo $_smarty_tpl->tpl_vars['citycountry']->value;?>
" class="form-control form-control-sm">  
                        <?php if (!isset($_smarty_tpl->tpl_vars['selected']->value) || ($_smarty_tpl->tpl_vars['selected']->value === '')) {?>
                            <option></option>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['datalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                                <option value="<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['data']->value->getWording();?>
</option>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                        <?php } else { ?>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['datalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                                <?php if (isset($_smarty_tpl->tpl_vars['selected']->value) && ($_smarty_tpl->tpl_vars['selected']->value === $_smarty_tpl->tpl_vars['data']->value->getId())) {?>
                                    <option value="<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['data']->value->getWording();?>
</option>

                                <?php }?>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['datalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                                <option value="<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['data']->value->getWording();?>
</option>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                        <?php }?>
                    </select>
                </div>
            </div>

            <div class="float-right">
                <button type="submit" class="btn btn-success btn-sm "><?php echo $_smarty_tpl->tpl_vars['savelabel']->value;?>
</button>      
                <button type="reset" class="btn btn-danger btn-sm"><?php echo $_smarty_tpl->tpl_vars['cancellabel']->value;?>
</button>
            </div>
        </form>
    </fieldset> 
<?php
}
}
/* {/block "content"} */
}
