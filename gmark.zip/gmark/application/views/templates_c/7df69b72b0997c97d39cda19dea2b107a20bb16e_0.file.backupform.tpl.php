<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:51:04
  from "/home/mundhaka/public_html/gmark/application/views/templates/backup/backupform.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867ac8f3c416_63012433',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7df69b72b0997c97d39cda19dea2b107a20bb16e' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/backup/backupform.tpl',
      1 => 1484297669,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867ac8f3c416_63012433 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_94426117058867ac8f3b928_78630529', "content");
?>

<?php }
/* {block "content"} */
class Block_94426117058867ac8f3b928_78630529 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <fieldset class="">
        <legend class=""><?php echo $_smarty_tpl->tpl_vars['backupformtitle']->value;?>
</legend>
        <form name="<?php echo $_smarty_tpl->tpl_vars['backupformname']->value;?>
" class="form-horizontal" action="" method="POST">
            <div class="">
                <button id="dobackup" type="submit" class="btn btn-success btn-sm "><?php echo $_smarty_tpl->tpl_vars['dobackuplabel']->value;?>
</button>
            </div>
        </form>
    </fieldset>  
    <?php echo '<script'; ?>
>
        $('button#dobackup').click(function (e) {
            e.preventDefault();
            var linkURL = "./dobackup";
            backup(linkURL);
        });
        function backup(linkURL) {
            swal({
                title: "Sauvegarde de données",
                text: "Vous êtes sur le point de faire la sauvegarde de vos données",
                type: "warning",
                showCancelButton: true
            }, function () {
                // Redirect the user
                window.location.href = linkURL;
            });
        }
    <?php echo '</script'; ?>
>
<?php
}
}
/* {/block "content"} */
}
