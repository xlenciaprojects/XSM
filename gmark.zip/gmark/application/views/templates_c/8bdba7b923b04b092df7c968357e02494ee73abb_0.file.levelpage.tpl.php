<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/level/levelpage.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6abbf9b6_83230164',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8bdba7b923b04b092df7c968357e02494ee73abb' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/level/levelpage.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:utils/level/levelform.tpl' => 1,
    'file:utils/level/levellist.tpl' => 1,
  ),
),false)) {
function content_58867a6abbf9b6_83230164 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_201341418158867a6abbf176_38143095', "content");
}
/* {block "content"} */
class Block_201341418158867a6abbf176_38143095 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="col-sm-10 col-sm-push-1">
        <?php if (isset($_smarty_tpl->tpl_vars['info']->value) && $_smarty_tpl->tpl_vars['info']->value != '') {?>
            <div class="alert alert-info" role="alert"><?php echo $_smarty_tpl->tpl_vars['info']->value;?>
</div>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['success']->value) && $_smarty_tpl->tpl_vars['success']->value != '') {?>
            <div class="alert alert-success" role="alert"><?php echo $_smarty_tpl->tpl_vars['success']->value;?>
</div>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['warning']->value) && $_smarty_tpl->tpl_vars['warning']->value != '') {?>
            <div class="alert alert-warning" role="alert"><?php echo $_smarty_tpl->tpl_vars['warning']->value;?>
</div>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['error']->value) && $_smarty_tpl->tpl_vars['error']->value != '') {?>
            <div class="alert alert-danger" role="alert"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</div>
        <?php }?>
        <!-- formulaire -->
        <?php $_smarty_tpl->_subTemplateRender("file:utils/level/levelform.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <!-- Table -->
        <br>
        <?php $_smarty_tpl->_subTemplateRender("file:utils/level/levellist.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </div>
<?php
}
}
/* {/block "content"} */
}
