<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/feetype/feetypelist.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6ab3a5b1_11303375',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '96e78b35b263335f40d880b8ae6508b5ed3830c2' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/feetype/feetypelist.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6ab3a5b1_11303375 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_161040556058867a6ab39de6_06098620', "content");
}
/* {block "content"} */
class Block_161040556058867a6ab39de6_06098620 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="table">
        <div class="col-sm-3 col-md-3 pull-right">
            <input type="text" class="form-control" placeholder="Rechercher" name="q">
        </div>
        <table id="mytable" class="table table-bordred table-striped">
            <thead>
            <th><input type="checkbox" id="checkall" /></th>
            <th><?php echo $_smarty_tpl->tpl_vars['num']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['feetypewordinglabel']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['feetypecodelabel']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['feetypedescriptionlabel']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['editlabel']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['deletelabel']->value;?>
</th>
            </thead>
            <tbody>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['feetypedatalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                    <tr>
                        <td><input type="checkbox" class="checkthis" /></td>
                        <td><?php echo (isset($_smarty_tpl->tpl_vars['__smarty_foreach_data']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_data']->value['index'] : null);?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['data']->value->getWording();?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['data']->value->getcode();?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['data']->value->getDescription();?>
</td>
                        <td>
                            <p data-placement="top" data-toggle="tooltip" title="Edit">
                                <a href="<?php echo $_smarty_tpl->tpl_vars['feetypeeditedlink']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
" class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit" >
                                    <span class="glyphicon glyphicon-pencil"></span>
                                </a>
                            </p>
                        </td>
                        <td>
                            <p data-placement="top" data-toggle="tooltip" title="Delete">
                                <a href="<?php echo $_smarty_tpl->tpl_vars['feetypedeletedlink']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" >
                                    <span class="glyphicon glyphicon-trash"></span>
                                </a>
                            </p>
                        </td>
                    </tr>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

            </tbody>
        </table>
    </div>
<?php
}
}
/* {/block "content"} */
}
