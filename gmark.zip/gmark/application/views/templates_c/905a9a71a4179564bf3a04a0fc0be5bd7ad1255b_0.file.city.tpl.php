<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/locality/city.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6aae8694_21227440',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '905a9a71a4179564bf3a04a0fc0be5bd7ad1255b' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/locality/city.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:utils/locality/cityform.tpl' => 1,
    'file:utils/locality/citylist.tpl' => 1,
  ),
),false)) {
function content_58867a6aae8694_21227440 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_72449601258867a6aae81f2_38181938', "content");
}
/* {block "content"} */
class Block_72449601258867a6aae81f2_38181938 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="col-lg-6">
        <!-- formulaire -->
        <?php $_smarty_tpl->_subTemplateRender("file:utils/locality/cityform.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <!-- Table -->
        <br><br><br>
        <?php $_smarty_tpl->_subTemplateRender("file:utils/locality/citylist.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </div>
<?php
}
}
/* {/block "content"} */
}
