<?php
/* Smarty version 3.1.30, created on 2017-01-13 09:42:48
  from "/home/mundhaka/public_html/gmark/application/views/templates/login/loginpage.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5878a1182aeb85_69961111',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '24e8256a508e59559f8092aec04fc5c9d5a85ffc' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/login/loginpage.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.tpl' => 1,
    'file:login/loginform.tpl' => 1,
  ),
),false)) {
function content_5878a1182aeb85_69961111 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php $_smarty_tpl->_assignInScope('content', "content");
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2137577645878a1182ad9b9_86746000', "container");
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:index.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block "container"} */
class Block_2137577645878a1182ad9b9_86746000 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php if (isset($_smarty_tpl->tpl_vars['error']->value) && $_smarty_tpl->tpl_vars['error']->value != '') {?>
        <div class="alert alert-danger" role="alert"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</div>
    <?php }?>
    <?php $_smarty_tpl->_subTemplateRender("file:login/loginform.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php
}
}
/* {/block "container"} */
}
