<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/hall/halllist.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6abafca9_83483920',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a81cd0ccd498fa8f964d6ee32c6c121ee5ccbf5c' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/hall/halllist.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6abafca9_83483920 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_81995746658867a6abaf7a7_67704286', "content");
}
/* {block "content"} */
class Block_81995746658867a6abaf7a7_67704286 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="table">
        
        <div class="form-group form-group-sm">
            <div class="col-sm-2 col-md-3 pull-right">
                <input type="text" class="form-control" placeholder="Rechercher" name="search">
            </div>
        </div>
        
        <table id="mytable" class="table table-bordred table-striped">
            <thead>

            <th><input type="checkbox" id="checkall" /></th>
            <th>Libellé Long</th>
            <th>Libellé Moyen</th>
            <th>Libellé Court</th>
            <th>Description</th>
            <th>Edit</th>
            <th>Delete</th>
            </thead>
            <tbody>
                <tr>
                    <td><input type="checkbox" class="checkthis" /></td>
                    <td>Sixième</td>
                    <td>6em</td>
                    <td>6e</td>
                    <td>Classe de Sixième</td>
                    <td><p data-placement="top" data-toggle="tooltip" title="Edit"><button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit" ><span class="glyphicon glyphicon-pencil"></span></button></p></td>
                    <td><p data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" ><span class="glyphicon glyphicon-trash"></span></button></p></td>
                </tr>
                <tr>
                    <td><input type="checkbox" class="checkthis" /></td>
                    <td>Troisième</td>
                    <td>3em</td>
                    <td>3e</td>
                    <td>Classe de Troisième</td>
                    <td><p data-placement="top" data-toggle="tooltip" title="Edit"><button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit" ><span class="glyphicon glyphicon-pencil"></span></button></p></td>
                    <td><p data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" ><span class="glyphicon glyphicon-trash"></span></button></p></td>
                </tr>
                <tr>
                    <td><input type="checkbox" class="checkthis" /></td>
                    <td>Cinquième </td>
                    <td>5em</td>
                    <td>5e</td>
                    <td>Classe de Cinquième</td>
                    <td><p data-placement="top" data-toggle="tooltip" title="Edit"><button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit" ><span class="glyphicon glyphicon-pencil"></span></button></p></td>
                    <td><p data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" ><span class="glyphicon glyphicon-trash"></span></button></p></td>
                </tr>
            </tbody>
        </table>
    </div>
<?php
}
}
/* {/block "content"} */
}
