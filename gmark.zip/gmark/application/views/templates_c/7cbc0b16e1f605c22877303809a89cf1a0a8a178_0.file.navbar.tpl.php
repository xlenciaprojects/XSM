<?php
/* Smarty version 3.1.30, created on 2017-01-13 09:44:19
  from "/home/mundhaka/public_html/gmark/application/views/templates/nav/navbar.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5878a17328ae12_51475172',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7cbc0b16e1f605c22877303809a89cf1a0a8a178' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/nav/navbar.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5878a17328ae12_51475172 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4308039835878a173289865_03303768', "nav");
}
/* {block "nav"} */
class Block_4308039835878a173289865_03303768 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <nav id="main-nav">
        
        <ul class="container_12">
            <li class="home <?php echo $_smarty_tpl->tpl_vars['dashboardcurrent']->value;?>
" title="Tableau de bord">
                <a title="" href="<?php echo $_smarty_tpl->tpl_vars['dashboard']->value;?>
">Home</a>
            </li>
            
            <?php if ($_smarty_tpl->tpl_vars['duty']->value === "Admin" || $_smarty_tpl->tpl_vars['duty']->value === "Secretaire") {?>
            <li class="write <?php echo $_smarty_tpl->tpl_vars['utilscurrent']->value;?>
" title="Données de base">
                <a title="Données de base" href="<?php echo $_smarty_tpl->tpl_vars['utils']->value;?>
">Données de base</a>
            </li>
            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['duty']->value === "Admin" || $_smarty_tpl->tpl_vars['duty']->value === "Secretaire") {?>

            <li class="settings <?php echo $_smarty_tpl->tpl_vars['admincurrent']->value;?>
">
                <a title="Administration" href="#">Administration</a>
                <ul>
                    
                    <li>
                        <a title="Add article" href="<?php echo $_smarty_tpl->tpl_vars['academicyear']->value;?>
">Année scolaire</a>
                    </li>
                    <li>
                        <a title="Add article" href="<?php echo $_smarty_tpl->tpl_vars['school']->value;?>
">Etablissement</a>
                    </li>
                    <li>
                        <a title="Add article" href="<?php echo $_smarty_tpl->tpl_vars['fee']->value;?>
">Frais</a>
                    </li>
                    <li>
                        <a title="Add article" href="<?php echo $_smarty_tpl->tpl_vars['modalitypayment']->value;?>
">Modalité de paiement</a>
                    </li>
                </ul>
            </li>
            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['duty']->value === "Admin" || $_smarty_tpl->tpl_vars['duty']->value === "Secretaire") {?>
            <li class="comments <?php echo $_smarty_tpl->tpl_vars['registrationcurrent']->value;?>
">
                <a title="Inscription" href="#">Inscription</a>
                <ul>
                    <li>
                        <a title="Manage" href="<?php echo $_smarty_tpl->tpl_vars['student']->value;?>
">Apprenant</a>
                    </li>
                    <li>
                        <a title="Spams" href="<?php echo $_smarty_tpl->tpl_vars['academicregistration']->value;?>
">Inscription Accadémique</a>
                    </li>
                    
                </ul>
            </li>
            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['duty']->value === "Admin" || $_smarty_tpl->tpl_vars['duty']->value === "Comptabilité") {?>
            <li class="comments <?php echo $_smarty_tpl->tpl_vars['accountingcurrent']->value;?>
">
                <a title="Comptabilité" href="#">Comptabilité</a>
                <ul>
                    <li>
                        <a title="Manage" href="<?php echo $_smarty_tpl->tpl_vars['payment']->value;?>
">Paiement</a>
                    </li>
                    
                </ul>
            </li>
            <?php }?>
            
            
            <?php if ($_smarty_tpl->tpl_vars['duty']->value === "Admin") {?>
            <li class="users <?php echo $_smarty_tpl->tpl_vars['staffcurrent']->value;?>
" title="Personnels">
                <a title="" href="<?php echo $_smarty_tpl->tpl_vars['staff']->value;?>
">Personnels</a>
                <ul>
                    <li>
                        <a title="Browse" href="<?php echo $_smarty_tpl->tpl_vars['post']->value;?>
">Postes</a>
                    </li>
                    <li>
                        <a title="Add user" href="<?php echo $_smarty_tpl->tpl_vars['personal']->value;?>
">Nouveau</a>
                    </li>
                    <li>
                        <a title="Settings" href="<?php echo $_smarty_tpl->tpl_vars['grh']->value;?>
">GRH</a>
                    </li>
                </ul>
            </li>
            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['duty']->value === "Admin" || $_smarty_tpl->tpl_vars['duty']->value === "Secretaire") {?>
            <li class="stats <?php echo $_smarty_tpl->tpl_vars['reportingcurrent']->value;?>
" title="Etats / Rapports">
                <a title="" href="#">Etats/Rapports</a>
                <ul>
                    <li>
                        <a title="Browse" href="<?php echo $_smarty_tpl->tpl_vars['classlist']->value;?>
">Listes d'appels</a>
                    </li>
                    <li>
                        <a title="Add user" href="<?php echo $_smarty_tpl->tpl_vars['minutes']->value;?>
">Proccès verbaux</a>
                    </li>
                    <li>
                        <a title="Settings" href="<?php echo $_smarty_tpl->tpl_vars['markreport']->value;?>
">Relevé de notes</a>
                    </li>
                    <li>
                        <a title="Settings" href="<?php echo $_smarty_tpl->tpl_vars['paymentorder']->value;?>
">Bon de paiement</a>
                    </li>
                    <li>
                        <a title="Settings" href="<?php echo $_smarty_tpl->tpl_vars['payslip']->value;?>
">Bulettin de paie</a>
                    </li>
                    <li>
                        <a title="Settings" href="<?php echo $_smarty_tpl->tpl_vars['statistic']->value;?>
">Statistique</a>
                    </li>
                    <li>
                        <a title="Settings" href="<?php echo $_smarty_tpl->tpl_vars['registrationcertificate']->value;?>
">Attestation d'incription</a>
                    </li>
                    <li>
                        <a title="Settings" href="<?php echo $_smarty_tpl->tpl_vars['certificateofemployement']->value;?>
">Attestation de travail</a>
                    </li>
                </ul>
            </li>
            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['duty']->value === "Admin" || $_smarty_tpl->tpl_vars['duty']->value === "Secretaire") {?>
            <li class="backup <?php echo $_smarty_tpl->tpl_vars['backupcurrent']->value;?>
" title="Sauvegarde">
                <a title="" href="<?php echo $_smarty_tpl->tpl_vars['backup']->value;?>
">Sauvegarde</a>
            </li>
            <?php }?>
        </ul>
        
        <div class="account col-lg-2">
            <ul id="status-infos">
                <li class="spaced">
                    Bienvenue:
                    <strong>Adminstrateur</strong>
                </li>
                <li>
                    <a class="button red" title="Logout" href="<?php echo $_smarty_tpl->tpl_vars['home']->value;?>
">
                        <span class="smaller">se déconnecter</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div id="sub-nav">
        <div class="container_12">
            <a class="nav-button" title="Help" href="<?php echo $_smarty_tpl->tpl_vars['help']->value;?>
">
                <b>Aide</b>
            </a>
        </div>
    </div>
    <div id="status-bar">
        <div class="container_12 col-lg-5">
            <span class="statusbartitle"><?php echo $_smarty_tpl->tpl_vars['statusbartitle']->value;?>
</span>
        </div>
        <div class="container_12 col-lg-3 year">
            <select name="<?php echo $_smarty_tpl->tpl_vars['currentyear']->value;?>
" class="">  
                <?php if (!isset($_smarty_tpl->tpl_vars['activated']->value) && ($_smarty_tpl->tpl_vars['activated']->value === '')) {?>
                    <option>Choisir</option>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['academicyeardatalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['data']->value->getWording();?>
</option>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                <?php } else { ?>
                    <option><?php echo $_smarty_tpl->tpl_vars['activated']->value;?>
</option>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['academicyeardatalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['data']->value->getWording();?>
</option>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                    <option>Choisir</option>
                <?php }?>

            </select>
        </div>
        <div class="container_12 col-lg-2">
        </div>
        <div class="container_12 float-right">
            <?php if (isset($_smarty_tpl->tpl_vars['havastatusbar']->value) && $_smarty_tpl->tpl_vars['havastatusbar']->value === 'yes') {?>
                <ul id="breadcrumb">
                    <?php if (isset($_smarty_tpl->tpl_vars['registrationfeelabel']->value) && $_smarty_tpl->tpl_vars['registrationfeelabel']->value != '') {?>
                        <li>
                            <a title="Nouveau frais d'inscription" href="<?php echo $_smarty_tpl->tpl_vars['registrationfee']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['registrationfeelabel']->value;?>
</a>
                        </li>
                    <?php }?>
                    <?php if (isset($_smarty_tpl->tpl_vars['schoolfeelabel']->value) && $_smarty_tpl->tpl_vars['schoolfeelabel']->value != '') {?>
                        <li>
                            <a title="Nouveau frais de scolarité" href="<?php echo $_smarty_tpl->tpl_vars['schoolfee']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['schoolfeelabel']->value;?>
</a>
                        </li>
                    <?php }?>
                    <?php if (isset($_smarty_tpl->tpl_vars['addnewlabel']->value) && $_smarty_tpl->tpl_vars['addnewlabel']->value != '') {?>
                        <li>
                            <a title="Ajouter nouveau" href="<?php echo $_smarty_tpl->tpl_vars['addnew']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['addnewlabel']->value;?>
</a>
                        </li>
                    <?php }?>
                    <?php if (isset($_smarty_tpl->tpl_vars['listlabel']->value) && $_smarty_tpl->tpl_vars['listlabel']->value != '') {?>
                        <li>
                            <a title="Liste des paiements" href="<?php echo $_smarty_tpl->tpl_vars['list']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['listlabel']->value;?>
</a>
                        </li>
                    <?php }?>
                </ul>
            <?php }?>
        </div>
    </div>
    <div id="header-shadow"></div>
<?php
}
}
/* {/block "nav"} */
}
