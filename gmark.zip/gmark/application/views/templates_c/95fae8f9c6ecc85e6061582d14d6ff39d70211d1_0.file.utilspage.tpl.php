<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/utilspage.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6a96abe1_29821413',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '95fae8f9c6ecc85e6061582d14d6ff39d70211d1' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/utilspage.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.tpl' => 1,
    'file:nav/navbar.tpl' => 1,
    'file:utils/locality/localitypage.tpl' => 1,
    'file:utils/feetype/feetypepage.tpl' => 1,
    'file:utils/gender/genderpage.tpl' => 1,
    'file:utils/hall/hallpage.tpl' => 1,
    'file:utils/level/levelpage.tpl' => 1,
  ),
),false)) {
function content_58867a6a96abe1_29821413 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php $_smarty_tpl->_assignInScope('nav', "nav");
$_smarty_tpl->_assignInScope('content', "content");
$_smarty_tpl->_subTemplateRender("file:nav/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_41136788058867a6a969695_50022774', "container");
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:index.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block "container"} */
class Block_41136788058867a6a969695_50022774 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="tabbed">
        <input name="tabbed" id="tabbed1" type="radio" <?php echo $_smarty_tpl->tpl_vars['localitychecked']->value;?>
>
        <section>
            <h1>
                <label for="tabbed1">Localités</label>
            </h1>
            <div>
                <?php $_smarty_tpl->_subTemplateRender("file:utils/locality/localitypage.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

            </div>
        </section>
            
        <input name="tabbed" id="tabbed4" type="radio" <?php echo $_smarty_tpl->tpl_vars['mentionchecked']->value;?>
>
        
        <input name="tabbed" id="tabbed8" type="radio"<?php echo $_smarty_tpl->tpl_vars['feetypechecked']->value;?>
>
        <section>
            <h1>
                <label for="tabbed8">Type de Frais</label>
            </h1>
            <div>
                <?php $_smarty_tpl->_subTemplateRender("file:utils/feetype/feetypepage.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


            </div>
        </section>
        <input name="tabbed" id="tabbed9" type="radio" <?php echo $_smarty_tpl->tpl_vars['genderchecked']->value;?>
>
        <section>
            <h1>
                <label for="tabbed9">Sexes</label>
            </h1>
            <div>
                <?php $_smarty_tpl->_subTemplateRender("file:utils/gender/genderpage.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

            </div>
        </section>
        <input name="tabbed" id="tabbed10" type="radio" <?php echo $_smarty_tpl->tpl_vars['hallchecked']->value;?>
>
        <section>
            <h1>
                <label for="tabbed10">Classes</label>
            </h1>
            <div>
                <?php $_smarty_tpl->_subTemplateRender("file:utils/hall/hallpage.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

            </div>
        </section>
        
        <input name="tabbed" id="tabbed13" type="radio" <?php echo $_smarty_tpl->tpl_vars['levelchecked']->value;?>
>
        <section>
            <h1>
                <label for="tabbed13">Niveau & Grade</label>
            </h1>
            <div>
                <?php $_smarty_tpl->_subTemplateRender("file:utils/level/levelpage.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

            </div>
        </section>
    </div>
<?php
}
}
/* {/block "container"} */
}
