<?php
/* Smarty version 3.1.30, created on 2017-01-13 09:42:48
  from "/home/mundhaka/public_html/gmark/application/views/templates/index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5878a118323b43_47803005',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd2f19fa046a61b5a34fcb5e20e848b96ccf1ad89' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/index.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5878a118323b43_47803005 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title><?php echo (($tmp = @$_smarty_tpl->tpl_vars['title']->value)===null||$tmp==='' ? 'gestion de notes' : $tmp);?>
</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
        <meta content="chrome=1" http-equiv="X-UA-Compatible">
        <meta content="Gmark est puissante application de gestion de notes" name="description">
        <meta content="noindex, follow" name="robots">
        <meta content="width=device-width, minimum-scale=1, maximum-scale=1" name="viewport">
        <link rel = "stylesheet" type = "text/css" href ="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_css_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['css_url']->value : $tmp);?>
style.css">
        <link rel = "stylesheet" type = "text/css" href ="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_css_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['css_url']->value : $tmp);?>
custom.css">
        <link rel = "stylesheet" type = "text/css" href ="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_css_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['css_url']->value : $tmp);?>
bootstrap.css">
        <link rel = "stylesheet" type = "text/css" href ="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_css_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['css_url']->value : $tmp);?>
bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href ="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_css_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['css_url']->value : $tmp);?>
bootstrap-theme.css">
        <link rel = "stylesheet" type = "text/css" href ="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_css_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['css_url']->value : $tmp);?>
bootstrap-theme.min.css">
        <link rel = "stylesheet" type = "text/css" href ="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_css_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['css_url']->value : $tmp);?>
bootstrap-duallistbox.css">
        <link rel = "stylesheet" type = "text/css" href ="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_css_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['css_url']->value : $tmp);?>
sweetalert.css">

        <?php echo '<script'; ?>
 src="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_js_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['js_url']->value : $tmp);?>
modernizr.custom.min.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 src="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_js_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['js_url']->value : $tmp);?>
bootstrap.min.js"><?php echo '</script'; ?>
> 
        <?php echo '<script'; ?>
 src="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_js_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['js_url']->value : $tmp);?>
jquery-2.1.3.min.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 src="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_js_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['js_url']->value : $tmp);?>
insctab1.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 src="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_js_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['js_url']->value : $tmp);?>
insctab2.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 src="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_js_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['js_url']->value : $tmp);?>
insctab3.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 src="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_js_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['js_url']->value : $tmp);?>
insctab4.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 src="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_js_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['js_url']->value : $tmp);?>
jquery.bootstrap-duallistbox.js"><?php echo '</script'; ?>
> 
        <?php echo '<script'; ?>
 src="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['page_js_url']->value)===null||$tmp==='' ? $_smarty_tpl->tpl_vars['js_url']->value : $tmp);?>
sweetalert.min.js"><?php echo '</script'; ?>
> 

    </head>
    <body>
        
        <?php if (isset($_smarty_tpl->tpl_vars['header']->value) && $_smarty_tpl->tpl_vars['header']->value === 'header') {?>
            <div class="header"> 
            <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17907808075878a11830fd81_83525111', "header");
?>

        </div>
    <?php }?>

    
    <?php if (isset($_smarty_tpl->tpl_vars['nav']->value) && $_smarty_tpl->tpl_vars['nav']->value === 'nav') {?>
        <div class="nav">
        <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3434346165878a118313130_63424032', "nav");
?>

    </div>
<?php }?>


<div class="main" id="container">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4307911575878a11831e817_98308918', "container");
?>

</div>


<?php if (isset($_smarty_tpl->tpl_vars['footer']->value) && $_smarty_tpl->tpl_vars['footer']->value === 'footer') {?>
    <div class="footer">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17590959625878a1183215f5_20998440', "footer");
?>

</div> 
<?php }?>





</body>
</html><?php }
/* {block "header"} */
class Block_17907808075878a11830fd81_83525111 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "header"} */
/* {block "nav"} */
class Block_3434346165878a118313130_63424032 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "nav"} */
/* {block "asideleft"} */
class Block_5273682355878a118317314_59487278 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "asideleft"} */
/* {block "content"} */
class Block_4636855905878a11831a457_87658277 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "content"} */
/* {block "asideright"} */
class Block_9597054495878a11831d830_34545367 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "asideright"} */
/* {block "container"} */
class Block_4307911575878a11831e817_98308918 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        
        <?php if (isset($_smarty_tpl->tpl_vars['asideleft']->value) && $_smarty_tpl->tpl_vars['asideleft']->value === 'asideleft') {?>
            <div class="aside-left span3">
            <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5273682355878a118317314_59487278', "asideleft", $this->tplIndex);
?>

        </div>
    <?php }?>

    
    <?php if (isset($_smarty_tpl->tpl_vars['content']->value) && $_smarty_tpl->tpl_vars['content']->value === 'content') {?>
        <div class="content span6">
        <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4636855905878a11831a457_87658277', "content", $this->tplIndex);
?>

    </div>
<?php }?>


<?php if (isset($_smarty_tpl->tpl_vars['asideright']->value) && $_smarty_tpl->tpl_vars['asideright']->value === 'asideright') {?>
    <div class="aside-right span3">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9597054495878a11831d830_34545367', "asideright", $this->tplIndex);
?>

</div>
<?php }
}
}
/* {/block "container"} */
/* {block "footer"} */
class Block_17590959625878a1183215f5_20998440 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "footer"} */
}
