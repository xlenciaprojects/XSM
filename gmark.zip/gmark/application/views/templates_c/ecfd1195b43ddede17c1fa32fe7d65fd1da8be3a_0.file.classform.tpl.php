<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/hall/classform.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6ab921d1_29686226',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ecfd1195b43ddede17c1fa32fe7d65fd1da8be3a' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/hall/classform.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6ab921d1_29686226 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_68488828858867a6ab91357_50198689', "content");
}
/* {block "content"} */
class Block_68488828858867a6ab91357_50198689 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <fieldset class="">
        <legend class=""><?php echo $_smarty_tpl->tpl_vars['classformtitle']->value;?>
</legend>
        <form name="<?php echo $_smarty_tpl->tpl_vars['classformname']->value;?>
" class="form-horizontal" action="<?php echo $_smarty_tpl->tpl_vars['addclass']->value;?>
" method="POST">
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['classlongwording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['classlongwordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['classlongwording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['classlongwordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['classlongwordingdesc']->value;?>
">
                </div>
            </div>
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['classmediumwording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['classmediumwordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['classmediumwording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['classmediumwordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['classmediumwordingdesc']->value;?>
">
                </div>
            </div>
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['classshortwording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['classshortwordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['classshortwording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['classshortwordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['classshortwordingdesc']->value;?>
">
                </div>
            </div>

            <div class="form-group form-group-sm">
                <label name="<?php echo $_smarty_tpl->tpl_vars['classlevel']->value;?>
" class="col-sm-2 control-label" for="level" ><span><?php echo $_smarty_tpl->tpl_vars['classlevellabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <select name="<?php echo $_smarty_tpl->tpl_vars['classlevel']->value;?>
" class="form-control form-control-sm">  
                        <?php if (!isset($_smarty_tpl->tpl_vars['selected']->value) || ($_smarty_tpl->tpl_vars['selected']->value === '')) {?>
                            <option></option>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['leveldatalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                                <option value="<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['data']->value->getWording();?>
</option>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                        <?php } else { ?>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['leveldatalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                                <?php if (isset($_smarty_tpl->tpl_vars['selected']->value) && ($_smarty_tpl->tpl_vars['selected']->value === $_smarty_tpl->tpl_vars['data']->value->getId())) {?>
                                    <option value="<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['data']->value->getWording();?>
</option>
                                <?php }?>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['leveldatalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                                <option value="<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
"><?php echo $_smarty_tpl->tpl_vars['data']->value->getWording();?>
</option>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                        <?php }?>

                    </select>
                </div>
            </div>

            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['classdescription']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['classdescriptionlabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['classdescription']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['classdescriptionvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['classdescriptiondesc']->value;?>
">
                </div>
            </div>

            <div class="float-right">
                <button type="submit" class="btn btn-success btn-sm "><?php echo $_smarty_tpl->tpl_vars['savelabel']->value;?>
</button>      
                <button type="reset" class="btn btn-danger btn-sm"><?php echo $_smarty_tpl->tpl_vars['cancellabel']->value;?>
</button>
            </div>
        </form>
    </fieldset> 
<?php
}
}
/* {/block "content"} */
}
