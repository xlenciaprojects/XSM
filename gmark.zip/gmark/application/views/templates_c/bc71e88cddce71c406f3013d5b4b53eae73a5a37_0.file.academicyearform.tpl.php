<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:44
  from "/home/mundhaka/public_html/gmark/application/views/templates/admin/academicyear/academicyearform.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a78ab1848_92770207',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bc71e88cddce71c406f3013d5b4b53eae73a5a37' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/admin/academicyear/academicyearform.tpl',
      1 => 1484297669,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a78ab1848_92770207 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_137525058258867a78ab09f1_94217074', "content");
}
/* {block "content"} */
class Block_137525058258867a78ab09f1_94217074 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <fieldset class="">
        <legend class=""><?php echo $_smarty_tpl->tpl_vars['academicyearformtitle']->value;?>
</legend>
        <form name="<?php echo $_smarty_tpl->tpl_vars['academicyearformname']->value;?>
" class="form-horizontal" action="<?php echo $_smarty_tpl->tpl_vars['addacademicyear']->value;?>
" method="POST">

            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['academicyearcode']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['academicyearcodelabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['academicyearcode']->value;?>
" class="form-control" type="text" id="idcode" value="<?php echo $_smarty_tpl->tpl_vars['academicyearcodevalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['academicyearcodedesc']->value;?>
">
                </div>
            </div>
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['academicyearwording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['academicyearwordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['academicyearwording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['academicyearwordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['academicyearwordingdesc']->value;?>
">
                </div>
            </div>
                
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['academicyearcurrent']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['academicyearcurrentlabel']->value;?>
</span></label>
                <div class="col-sm-2">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['academicyearcurrent']->value;?>
" class="form-control" type="checkbox" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['academicyearcurrentvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['academicyearcurrentdesc']->value;?>
">
                </div>
            </div>

            <div class="float-right">
                <button type="submit" class="btn btn-success btn-sm "><?php echo $_smarty_tpl->tpl_vars['savelabel']->value;?>
</button>      
                <button type="reset" class="btn btn-danger btn-sm"><?php echo $_smarty_tpl->tpl_vars['cancellabel']->value;?>
</button>
            </div>
        </form>
    </fieldset> 
<?php
}
}
/* {/block "content"} */
}
