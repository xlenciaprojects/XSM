<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:44
  from "/home/mundhaka/public_html/gmark/application/views/templates/admin/academicyear/academicyearpage.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a78a83076_07391591',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5b8049173d400dbdc22d7a5dbd2f563c4220c9ad' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/admin/academicyear/academicyearpage.tpl',
      1 => 1484297669,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:index.tpl' => 1,
    'file:nav/navbar.tpl' => 1,
    'file:admin/academicyear/academicyearform.tpl' => 1,
    'file:admin/academicyear/academicyearlist.tpl' => 1,
  ),
),false)) {
function content_58867a78a83076_07391591 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php $_smarty_tpl->_assignInScope('nav', "nav");
$_smarty_tpl->_assignInScope('content', "content");
$_smarty_tpl->_subTemplateRender("file:nav/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_169849643658867a78a812d6_72499281', "container");
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:index.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block "container"} */
class Block_169849643658867a78a812d6_72499281 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="col-sm-10 col-sm-push-1">
        <?php if (isset($_smarty_tpl->tpl_vars['info']->value) && $_smarty_tpl->tpl_vars['info']->value != '') {?>
            <div class="alert alert-info" role="alert"><?php echo $_smarty_tpl->tpl_vars['info']->value;?>
</div>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['success']->value) && $_smarty_tpl->tpl_vars['success']->value != '') {?>
            <div class="alert alert-success" role="alert"><?php echo $_smarty_tpl->tpl_vars['success']->value;?>
</div>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['warning']->value) && $_smarty_tpl->tpl_vars['warning']->value != '') {?>
            <div class="alert alert-warning" role="alert"><?php echo $_smarty_tpl->tpl_vars['warning']->value;?>
</div>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['error']->value) && $_smarty_tpl->tpl_vars['error']->value != '') {?>
            <div class="alert alert-danger" role="alert"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</div>
        <?php }?>
        <!-- formulaire -->
        <?php $_smarty_tpl->_subTemplateRender("file:admin/academicyear/academicyearform.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <!-- Table -->
        <br>
        <?php $_smarty_tpl->_subTemplateRender("file:admin/academicyear/academicyearlist.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </div>
<?php
}
}
/* {/block "container"} */
}
