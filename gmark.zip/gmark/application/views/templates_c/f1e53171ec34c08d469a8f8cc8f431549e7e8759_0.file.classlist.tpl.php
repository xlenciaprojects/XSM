<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/hall/classlist.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6aba29b0_69709945',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f1e53171ec34c08d469a8f8cc8f431549e7e8759' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/hall/classlist.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6aba29b0_69709945 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_45445724358867a6aba2072_70533849', "content");
}
/* {block "content"} */
class Block_45445724358867a6aba2072_70533849 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="table">
        <div class="col-sm-3 col-md-3 pull-right">
            <input type="text" class="form-control" placeholder="Rechercher" name="q">
        </div>
        <table id="mytable" class="table table-bordred table-striped">
            <thead>
            <th><input type="checkbox" id="checkall" /></th>
            <th><?php echo $_smarty_tpl->tpl_vars['num']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['classlongwordinglabel']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['classmediumwordinglabel']->value;?>
</th>
            
            <th><?php echo $_smarty_tpl->tpl_vars['editlabel']->value;?>
</th>
            <th><?php echo $_smarty_tpl->tpl_vars['deletelabel']->value;?>
</th>
            </thead>
            <tbody>
                <?php $_smarty_tpl->_assignInScope('index', 1);
?>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['classdatalist']->value, 'data');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['data']->value) {
?>
                    <tr>
                        <td><input type="checkbox" class="checkthis" /></td>
                        <td><?php echo $_smarty_tpl->tpl_vars['index']->value;?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['data']->value->getLong_wording();?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['data']->value->getMedium_wording();?>
</td>
                        
                        <td>
                            <p data-placement="top" data-toggle="tooltip" title="Edit">
                                <a href="<?php echo $_smarty_tpl->tpl_vars['classeditedlink']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
" class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit" >
                                    <span class="glyphicon glyphicon-pencil"></span>
                                </a>
                            </p>
                        </td>
                        <td>
                            <p data-placement="top" data-toggle="tooltip" title="Delete">
                                <a href="<?php echo $_smarty_tpl->tpl_vars['classdeletedlink']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['data']->value->getId();?>
" class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" >
                                    <span class="glyphicon glyphicon-trash"></span>
                                </a>
                            </p>
                        </td>
                    </tr>
                    <?php $_smarty_tpl->_assignInScope('index', $_smarty_tpl->tpl_vars['index']->value+1);
?>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

            </tbody>
        </table>
    </div>
<?php
}
}
/* {/block "content"} */
}
