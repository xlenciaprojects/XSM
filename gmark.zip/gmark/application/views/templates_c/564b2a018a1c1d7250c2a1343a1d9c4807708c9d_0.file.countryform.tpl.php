<?php
/* Smarty version 3.1.30, created on 2017-01-23 21:49:30
  from "/home/mundhaka/public_html/gmark/application/views/templates/utils/locality/countryform.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58867a6aac2f41_14803137',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '564b2a018a1c1d7250c2a1343a1d9c4807708c9d' => 
    array (
      0 => '/home/mundhaka/public_html/gmark/application/views/templates/utils/locality/countryform.tpl',
      1 => 1484297670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58867a6aac2f41_14803137 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_36477377758867a6aac2464_33244945', "content");
}
/* {block "content"} */
class Block_36477377758867a6aac2464_33244945 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <fieldset class="">
        <legend class=""><?php echo $_smarty_tpl->tpl_vars['countryformtitle']->value;?>
</legend>
        <form name="<?php echo $_smarty_tpl->tpl_vars['countryformname']->value;?>
" class="form-horizontal" action="<?php echo $_smarty_tpl->tpl_vars['addcountry']->value;?>
" method="POST">
            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['countrywording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['countrywordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['countrywording']->value;?>
" class="form-control" type="text" id="wording" value="<?php echo $_smarty_tpl->tpl_vars['countrywordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['countrywordingdesc']->value;?>
">
                </div>
            </div>

            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['countryshortwording']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['countryshortwordinglabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['countryshortwording']->value;?>
" class="form-control" type="text" id="shortwording" value="<?php echo $_smarty_tpl->tpl_vars['countryshortwordingvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['countryshortwordingdesc']->value;?>
">
                </div>
            </div>

            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['countrycode']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['countrycodelabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['countrycode']->value;?>
" class="form-control" type="text" id="idcode" value="<?php echo $_smarty_tpl->tpl_vars['countrycodevalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['countrycodedesc']->value;?>
">
                </div>
            </div>

            <div class="form-group form-group-sm">
                <label class="col-sm-2 control-label" for="<?php echo $_smarty_tpl->tpl_vars['countrynationality']->value;?>
"><span><?php echo $_smarty_tpl->tpl_vars['countrynationalitylabel']->value;?>
</span></label>
                <div class="col-sm-10">
                    <input name="<?php echo $_smarty_tpl->tpl_vars['countrynationality']->value;?>
" class="form-control" type="text" id="nationality" value="<?php echo $_smarty_tpl->tpl_vars['countrynationalityvalue']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['countrynationalitydesc']->value;?>
">
                </div>
            </div>

            <div class="float-right">
                <button type="submit" class="btn btn-success btn-sm "><?php echo $_smarty_tpl->tpl_vars['savelabel']->value;?>
</button>      
                <button type="reset" class="btn btn-danger btn-sm"><?php echo $_smarty_tpl->tpl_vars['cancellabel']->value;?>
</button>
            </div>
        </form>
    </fieldset> 
<?php
}
}
/* {/block "content"} */
}
