<?php

namespace daoImpl;

use dao\IMentionDAO ;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once APPPATH .'models/dao/IMentionDAO.php';
require_once APPPATH.'third_party/dmap/dmapimpl/DAO.php';
/**
 * Description of GenderDAO
 *
 * @author mundhaka
 */
class MentionDAO extends DAO implements IMentionDAO{
    //put your code here
}
