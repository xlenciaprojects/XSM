<?php

namespace daoImpl;

use dao\IFeeDAO;
use dmapimpl\DAO;
use daoImpl\ClassesDAO;
use daoImpl\AcademicYearDAO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once APPPATH . 'models/dao/IFeeDAO.php';
require_once APPPATH . 'models/daoImpl/ClassesDAO.php';
require_once APPPATH . 'models/daoImpl/AcademicYearDAO.php';
require_once APPPATH . 'third_party/dmap/dmapimpl/DAO.php';

/**
 * Description of GenderDAO
 *
 * @author mundhaka
 */
class FeeDAO extends DAO implements IFeeDAO {

    //put your code here

    private $feeTypeDAO;
    private $classDAO;
    private $academicYearDAO;

    //put your code here
    function __construct() {
        parent::__construct("Fee");
        $this->feeTypeDAO = new FeeTypeDAO();
        $this->classDAO = new ClassesDAO();
        $this->academicYearDAO = new AcademicYearDAO();
    }

    public function getAllByAcademicYear($pk) {
        $datalist = new \Doctrine\Common\Collections\ArrayCollection();
        $feeTable = $this->em->getClassMetadata(\entities\Fee::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT * FROM " . $feeTable . " f "
                . "WHERE f.academic_year_id = " . $pk . " AND f.state != 1 ");

        while ($row = $stmt->fetch()) {
            $fee_type = $this->feeTypeDAO->getOne($row["fee_type_id"]);
            $classes = $this->classDAO->getOne($row["class_id"]);
            $academic_year = $this->academicYearDAO->getOne($row["academic_year_id"]);
            $fee = new \entities\Fee($row["amount"], $row["state"], $academic_year, $fee_type, $classes);
            $fee->setId($row["id"]);
            $datalist->add($fee);
        }
        return $datalist;
    }

    public function getOne($pk) {
        $feeTable = $this->em->getClassMetadata(\entities\Fee::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT * FROM " . $feeTable . " f "
                . "WHERE id = " . $pk . " AND f.state != 1 ");

        $row = $stmt->fetch();
        $fee_type = $this->feeTypeDAO->getOne($row["fee_type_id"]);
        $classes = $this->classDAO->getOne($row["class_id"]);
        $academic_year = $this->academicYearDAO->getOne($row["academic_year_id"]);
        $fee = new \entities\Fee($row["amount"], $row["state"], $academic_year, $fee_type, $classes);
        $fee->setId($row["id"]);
        return $fee;
    }

    public function deleteStateOneById($pk) {
        $feeTable = $this->em->getClassMetadata(\entities\Fee::class)->getTableName();
        $this->em->getConnection()->query("UPDATE " . $feeTable . " SET state = 1 WHERE id = " . $pk);
    }

    public function updateOneFeeById($object, $pk) {
        $feeTable = $this->em->getClassMetadata(\entities\Fee::class)->getTableName();
        $this->em->getConnection()->query("UPDATE " . $feeTable . " SET amount = " . $object[0] . ", "
                . "fee_type_id = " . $object[1] . ", class_id = " . $object[2] . ", state = 2 WHERE id = " . $pk);
    }

}
