<?php

namespace daoImpl;

use dao\IAcademicYearDAO,
    dmapimpl\DAO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once APPPATH . 'models/dao/IAcademicYearDAO.php';
require_once APPPATH . 'third_party/dmap/dmapimpl/DAO.php';

/**
 * Description of AcademicYearDAO
 *
 * @author mundhaka
 */
class AcademicYearDAO extends DAO implements IAcademicYearDAO {

    function __construct() {
        parent::__construct("AcademicYear");
    }

    public function activated($pk) {
        $query_builder = $this->em->createQueryBuilder();
        $query_builder->select('e')
                ->from("entities\\" . $this->entity, 'e')
                ->where('e.state != :state AND e.id = :id')
                ->setParameter('state', 1)
                ->setParameter('id', $pk);
        $entity = $query_builder->getQuery()->getSingleResult();
        $entity->setCurrent("Oui");
        $this->updateOne($entity);
    }

    public function desactivated($pk) {
        $query_builder = $this->em->createQueryBuilder();
        $query_builder->select('e')
                ->from("entities\\" . $this->entity, 'e')
                ->where('e.state != :state AND e.id = :id')
                ->setParameter('state', 1)
                ->setParameter('id', $pk);
        $entity = $query_builder->getQuery()->getSingleResult();
        $entity->setCurrent("No");
        $this->updateOne($entity);
    }

    public function getActivated() {
        $query_builder = $this->em->createQueryBuilder();
        $query_builder->select('e')
                ->from("entities\\" . $this->entity, 'e')
                ->where('e.state != :state AND e.current = :current')
                ->setParameter('state', 1)
                ->setParameter('current', "Oui");
        try {
            return $query_builder->getQuery()->getSingleResult();
        } catch (NoResultException $ex) {
            return NULL;
        }
    }

    public function getCurrent() {
        $query_builder = $this->em->createQueryBuilder();
        $query_builder->select('e')
                ->from("entities\\" . $this->entity, 'e')
                ->where('e.state != :state')
                ->setParameter('state', 1);
        try {
            $datalist = $query_builder->getQuery()->getResult();
        } catch (NoResultException $ex) {
//            echo $ex->getMessage();
        }
        return $datalist;
    }

//put your code here
}
