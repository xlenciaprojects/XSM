<?php

namespace daoImpl;

use dao\IUsersDAO,
    dmapimpl\DAO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once APPPATH . 'models/dao/IUsersDAO.php';
require_once APPPATH . 'third_party/dmap/dmapimpl/DAO.php';

/**
 * Description of UserDAO
 *
 * @author amen
 */
class UsersDAO extends DAO implements IUsersDAO {

    public function saveAll($objects) {
        foreach ($objects as $object) {
            $this->saveOne($object);
        }
    }

    public function saveOne($object) {
        $userTable = $this->em->getClassMetadata(\entities\Users::class)->getTableName();
        $stmt = $this->em->getConnection()->query("INSERT INTO " . $userTable .
                "(staff_id, login, password, state, validated) "
                . "VALUES(" . $object[0] . ",'" . $object[1] . "','" . $object[2] . "'," . $object[3] . ",'" . $object[4] . "')");
        $stmt->execute();
    }

}
