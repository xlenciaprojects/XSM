<?php

namespace daoImpl;

use dao\IStudentDAO;
use daoImpl\PersonInfoDAO,
    daoImpl\GenderDAO,
    daoImpl\CityDAO,
    daoImpl\CountryDAO,
    daoImpl\SchoolDAO;
use dmapimpl\DAO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once APPPATH . 'models/dao/IStudentDAO.php';
require_once APPPATH . 'models/daoImpl/PersonInfoDAO.php';
require_once APPPATH . 'models/daoImpl/GenderDAO.php';
require_once APPPATH . 'models/daoImpl/CityDAO.php';
require_once APPPATH . 'models/daoImpl/CountryDAO.php';
require_once APPPATH . 'models/daoImpl/SchoolDAO.php';
require_once APPPATH . 'third_party/dmap/dmapimpl/DAO.php';

/**
 * Description of GenderDAO
 *
 * @author mundhaka
 */
class StudentDAO extends DAO implements IStudentDAO {

    private $genderDAO;
    private $cityDAO;
    private $countryDAO;
    private $schoolDAO;
    private $personInfoDAO;

    //put your code here
    function __construct() {
        parent::__construct("Student");
        $this->genderDAO = new GenderDAO("Gender");
        $this->cityDAO = new CityDAO("City");
        $this->countryDAO = new CountryDAO("Country");
        $this->schoolDAO = new SchoolDAO("School");
        $this->personInfoDAO = new PersonInfoDAO("PersonInfo");
    }

    public function size() {
        return count($this->getAll());
    }

    public function getAll() {
        $meta = $this->em->getClassMetadata(\entities\Student::class);
        $tableName = $meta->getTableName();
        $datalist = $this->em->getConnection()->executeQuery("select * from " . $tableName)->fetchAll();
//        $query_builder = $this->em->createQueryBuilder();
////        $query_builder = $this->em->createQueryBuilder('SELECT s FROM entities\\Student s, '
////                . 'entities\\PersonInfo pi, entities\\Gender g, entities\\City ci, entities\\Country c, entities\\School sc '
////                . 'WHERE s.person_info = pi AND pi.gender=g AND pi.birth_city = ci '
////                . 'AND pi.nationality = c AND pi.old_school = sc AND ci.country = c');
////        print_r($query_builder);
//        $query_builder->select('s')
//                ->from('entities\\Student', 's')
//                ->from('entities\\PersonInfo', 'pi')
//                ->from('entities\\Gender', 'g')
//                ->from('entities\\Country', 'c')
//                ->from('entities\\City', 'ci')
//                ->from('entities\\School', 'sc')
////                ->where('s.person_info = pi')
//                ->addSelect('s')
//                ->addSelect('pi')
//                ->addSelect('g')
//                ->addSelect('c')
//                ->addSelect('ci')
//                ->addSelect('sc');
//        try {
//            $datalist = $query_builder->getQuery()->getResult();
//        } catch (NoResultException $ex) {
//            echo $ex->getMessage();
//        }
        return $datalist;
    }

    public function getAllValidated() {
        $query = $this->em->getRepository('entities\\' . $this->entity);
        return $query->findAll();
//        $query_builder = $this->em->createQueryBuilder();
//        $query_builder->select('s')
//                ->from('entities\\Student', 's')
//                ->where('e.state != :state')
//                ->setParameter('state', 1);
//        try {
//            $datalist = $query_builder->getQuery()->getResult();
//        } catch (NoResultException $ex) {
//            echo $ex->getMessage();
//        }
//        return $datalist;
    }

    public function getAllValidatedWithSortAndOrder($sortProperty, $sortAsc) {
        $datalist = new \Doctrine\Common\Collections\ArrayCollection();
        $studentTable = $this->em->getClassMetadata(\entities\Student::class)->getTableName();
        $personInfoTable = $this->em->getClassMetadata(\entities\PersonInfo::class)->getTableName();
        $genderTable = $this->em->getClassMetadata(\entities\Gender::class)->getTableName();
        $cityTable = $this->em->getClassMetadata(\entities\City::class)->getTableName();
        $countryTable = $this->em->getClassMetadata(\entities\Country::class)->getTableName();
        $schoolTable = $this->em->getClassMetadata(\entities\School::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT s.id AS sid,s.state AS ss,"
                . "s.validated AS sv,pi.id AS pid,pi.last_name,pi.first_name,pi.guardian_name,"
                . "pi.guardian_phone,pi.guardian_mail,pi.adress,pi.birth_date, "
                . "pi.matricule,pi.blood_group,pi.picture,pi.create_date,pi.gender_id,pi.city_id,pi.country_id,pi.school_id "
                . "FROM " . $studentTable . " s," . $personInfoTable . " pi," . $genderTable . " g,"
                . $cityTable . " ci," . $countryTable . " co," . $schoolTable . " sc "
                . "WHERE s.person_info_id = pi.id AND pi.gender_id = g.id "
                . "AND pi.city_id = ci.id AND pi.country_id = co.id "
                . "AND pi.school_id = sc.id AND ci.country_id = co.id AND s.state != 1 "
                . "ORDER BY pi.last_name,pi.first_name ASC");

        while ($row = $stmt->fetch()) {
            $gender = $this->genderDAO->getOne($row["gender_id"]);
            $birth_city = $this->cityDAO->getOne($row["city_id"]);
            $nationality = $this->countryDAO->getOne($row["country_id"]);
            $old_school = $this->schoolDAO->getOne($row["school_id"]);
            $personInfo = new \entities\PersonInfo($row["last_name"], $row["first_name"], $row["guardian_name"], $row["guardian_mail"], $row["guardian_phone"], $row["adress"], $row["birth_date"], $row["matricule"], $row["blood_group"], $row["picture"], $row["create_date"], $gender, $birth_city, $nationality, $old_school);
            $personInfo->setId($row["pid"]);
            $student = new \entities\Student($row["ss"], $row["sv"], $personInfo);
            $student->setId($row["sid"]);
            $datalist->add($student);
        }
        return $datalist;
    }

    public function getOne($pk) {
//            print_r($pk);
//        $datalist = new \Doctrine\Common\Collections\ArrayCollection();
        $studentTable = $this->em->getClassMetadata(\entities\Student::class)->getTableName();
        $personInfoTable = $this->em->getClassMetadata(\entities\PersonInfo::class)->getTableName();
        $genderTable = $this->em->getClassMetadata(\entities\Gender::class)->getTableName();
        $cityTable = $this->em->getClassMetadata(\entities\City::class)->getTableName();
        $countryTable = $this->em->getClassMetadata(\entities\Country::class)->getTableName();
        $schoolTable = $this->em->getClassMetadata(\entities\School::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT s.id AS sid,s.state AS ss,"
                . "s.validated AS sv,pi.id AS pid,pi.last_name,pi.first_name,pi.guardian_name,"
                . "pi.guardian_phone,pi.guardian_mail,pi.adress,pi.birth_date, "
                . "pi.matricule,pi.blood_group,pi.picture,pi.create_date,pi.gender_id,pi.city_id,pi.country_id,pi.school_id "
                . "FROM " . $studentTable . " s," . $personInfoTable . " pi," . $genderTable . " g,"
                . $cityTable . " ci," . $countryTable . " co," . $schoolTable . " sc "
                . "WHERE s.id = " . $pk . " AND s.person_info_id = pi.id AND pi.gender_id = g.id "
                . "AND pi.city_id = ci.id AND pi.country_id = co.id "
                . "AND pi.school_id = sc.id AND ci.country_id = co.id AND s.state != 1");

        $row = $stmt->fetch();
        $gender = $this->genderDAO->getOne($row["gender_id"]);
        $birth_city = $this->cityDAO->getOne($row["city_id"]);
        $nationality = $this->countryDAO->getOne($row["country_id"]);
        $old_school = $this->schoolDAO->getOne($row["school_id"]);
        $personInfo = new \entities\PersonInfo($row["last_name"], $row["first_name"], $row["guardian_name"], $row["guardian_mail"], $row["guardian_phone"], $row["adress"], $row["birth_date"], $row["matricule"], $row["blood_group"], $row["picture"], $row["create_date"], $gender, $birth_city, $nationality, $old_school);
        $personInfo->setId($row["pid"]);
        $student = new \entities\Student($row["ss"], $row["sv"], $personInfo);
        $student->setId($row["sid"]);
//            $datalist->add($student);
        return $student;
    }

    public function getAllForRegistration($acyId) {
        $datalist = new \Doctrine\Common\Collections\ArrayCollection();
        $studentTable = $this->em->getClassMetadata(\entities\Student::class)->getTableName();
        $personInfoTable = $this->em->getClassMetadata(\entities\PersonInfo::class)->getTableName();
        $genderTable = $this->em->getClassMetadata(\entities\Gender::class)->getTableName();
        $cityTable = $this->em->getClassMetadata(\entities\City::class)->getTableName();
        $countryTable = $this->em->getClassMetadata(\entities\Country::class)->getTableName();
        $schoolTable = $this->em->getClassMetadata(\entities\School::class)->getTableName();
        $paymentTable = $this->em->getClassMetadata(\entities\Payment::class)->getTableName();
        $registrationTable = $this->em->getClassMetadata(\entities\Registration::class)->getTableName();
//        $academicYearTable = $this->em->getClassMetadata(\entities\AcademicYear::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT DISTINCT s.id AS sid,s.state AS ss,"
                . "s.validated AS sv,pi.id AS pid,pi.last_name,pi.first_name,pi.guardian_name,"
                . "pi.guardian_phone,pi.guardian_mail,pi.adress,pi.birth_date, "
                . "pi.matricule,pi.blood_group,pi.picture,pi.create_date,pi.gender_id,pi.city_id,pi.country_id,pi.school_id "
                . "FROM " . $studentTable . " s," . $personInfoTable . " pi," . $genderTable . " g,"
                . $cityTable . " ci," . $countryTable . " co," . $schoolTable . " sc,". $paymentTable . " pa "
                . "WHERE s.person_info_id = pi.id AND pi.gender_id = g.id "
                . "AND pi.city_id = ci.id AND pi.country_id = co.id AND pi.school_id = sc.id "
                . "AND ci.country_id = co.id AND pa.student_id = s.id AND s.id NOT IN(SELECT r.student_id FROM " . $registrationTable . " r WHERE r.academic_year_id = ".$acyId.")  "
                . "AND s.state != 1 "
                . "ORDER BY pi.last_name,pi.first_name ASC");

        while ($row = $stmt->fetch()) {
            $gender = $this->genderDAO->getOne($row["gender_id"]);
            $birth_city = $this->cityDAO->getOne($row["city_id"]);
            $nationality = $this->countryDAO->getOne($row["country_id"]);
            $old_school = $this->schoolDAO->getOne($row["school_id"]);
            $personInfo = new \entities\PersonInfo($row["last_name"], $row["first_name"], $row["guardian_name"], $row["guardian_mail"], $row["guardian_phone"], $row["adress"], $row["birth_date"], $row["matricule"], $row["blood_group"], $row["picture"], $row["create_date"], $gender, $birth_city, $nationality, $old_school);
            $personInfo->setId($row["pid"]);
            $student = new \entities\Student($row["ss"], $row["sv"], $personInfo);
            $student->setId($row["sid"]);
            $datalist->add($student);
        }
        return $datalist;
    }
    
    
    public function getAllForRegistrationFeePayment($acyId) {
        $datalist = new \Doctrine\Common\Collections\ArrayCollection();
        $studentTable = $this->em->getClassMetadata(\entities\Student::class)->getTableName();
        $personInfoTable = $this->em->getClassMetadata(\entities\PersonInfo::class)->getTableName();
        $genderTable = $this->em->getClassMetadata(\entities\Gender::class)->getTableName();
        $cityTable = $this->em->getClassMetadata(\entities\City::class)->getTableName();
        $countryTable = $this->em->getClassMetadata(\entities\Country::class)->getTableName();
        $schoolTable = $this->em->getClassMetadata(\entities\School::class)->getTableName();
        $paymentTable = $this->em->getClassMetadata(\entities\Payment::class)->getTableName();
        $modalityPaymentTable = $this->em->getClassMetadata(\entities\ModalityPayment::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT s.id AS sid,s.state AS ss,"
                . "s.validated AS sv,pi.id AS pid,pi.last_name,pi.first_name,pi.guardian_name,"
                . "pi.guardian_phone,pi.guardian_mail,pi.adress,pi.birth_date, "
                . "pi.matricule,pi.blood_group,pi.picture,pi.create_date,pi.gender_id,pi.city_id,pi.country_id,pi.school_id "
                . "FROM " . $studentTable . " s," . $personInfoTable . " pi," . $genderTable . " g,"
                . $cityTable . " ci," . $countryTable . " co," . $schoolTable . " sc "
                . "WHERE s.person_info_id = pi.id AND pi.gender_id = g.id "
                . "AND pi.city_id = ci.id AND pi.country_id = co.id AND pi.school_id = sc.id "
                . "AND ci.country_id = co.id AND s.id NOT IN("
                . "SELECT student_id FROM " . $paymentTable . " pa, ".$modalityPaymentTable. " m "
                . "WHERE pa.modality_payment_id = m.id AND m.dtype = 'B' AND pa.academic_year_id = ".$acyId.")  "
                . "AND s.state != 1 "
                . "ORDER BY pi.last_name,pi.first_name ASC");

        while ($row = $stmt->fetch()) {
            $gender = $this->genderDAO->getOne($row["gender_id"]);
            $birth_city = $this->cityDAO->getOne($row["city_id"]);
            $nationality = $this->countryDAO->getOne($row["country_id"]);
            $old_school = $this->schoolDAO->getOne($row["school_id"]);
            $personInfo = new \entities\PersonInfo($row["last_name"], $row["first_name"], $row["guardian_name"], $row["guardian_mail"], $row["guardian_phone"], $row["adress"], $row["birth_date"], $row["matricule"], $row["blood_group"], $row["picture"], $row["create_date"], $gender, $birth_city, $nationality, $old_school);
            $personInfo->setId($row["pid"]);
            $student = new \entities\Student($row["ss"], $row["sv"], $personInfo);
            $student->setId($row["sid"]);
            $datalist->add($student);
        }
        return $datalist;
    }
    
    public function deleteStateOneById($pk) {
        $studentTable = $this->em->getClassMetadata(\entities\Student::class)->getTableName();
         $stmt = $this->em->getConnection()->query("UPDATE " . $studentTable ." SET state = 1 WHERE id = ".$pk);
    }

    public function updateOneStudentById($object, $pk1, $pk2) {
        $studentTable = $this->em->getClassMetadata(\entities\Student::class)->getTableName();
        $personInfoTable = $this->em->getClassMetadata(\entities\PersonInfo::class)->getTableName();
        $stmt = $this->em->getConnection()->query("UPDATE " . $personInfoTable ." SET last_name = '".$object[0]."', "
                . "first_name = '".$object[1]."', guardian_name = '".$object[2]."', guardian_mail = '".$object[3]."', "
                . "guardian_phone = '".$object[4]."', adress = '".$object[5]."', birth_date = '".$object[6]."', "
                . "blood_group = '".$object[7]."', gender_id = ".$object[8].", city_id = ".$object[9].", "
                . "country_id = ".$object[10].", school_id = ".$object[11].", state = 2 WHERE id = ".$pk1);
        $stmt = $this->em->getConnection()->query("UPDATE " . $studentTable ." SET state = 2 WHERE id = ".$pk2);
    }

}
