<?php

namespace daoImpl;

use dao\IClassesDAO,
    dmapimpl\DAO;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once APPPATH .'models/dao/IClassesDAO.php';
require_once APPPATH.'third_party/dmap/dmapimpl/DAO.php';
/**
 * Description of GenderDAO
 *
 * @author mundhaka
 */
class ClassesDAO extends DAO implements IClassesDAO{
    //put your code here
    function __construct() {
        parent::__construct("Classes");
    }

}
