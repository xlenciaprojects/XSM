<?php
namespace daoImpl;

use dao\IStaffDAO ;
use daoImpl\PersonInfoDAO,
    daoImpl\GenderDAO,
    daoImpl\CityDAO,
    daoImpl\CountryDAO,
    daoImpl\SchoolDAO;
use dmapimpl\DAO;

use \Doctrine\Common\Collections\ArrayCollection;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once APPPATH .'models/dao/IStaffDAO.php';
require_once APPPATH . 'models/daoImpl/PersonInfoDAO.php';
require_once APPPATH . 'models/daoImpl/GenderDAO.php';
require_once APPPATH . 'models/daoImpl/CityDAO.php';
require_once APPPATH . 'models/daoImpl/CountryDAO.php';
require_once APPPATH . 'models/daoImpl/SchoolDAO.php';
require_once APPPATH . 'third_party/dmap/dmapimpl/DAO.php';
/**
 * Description of GenderDAO
 *
 * @author mundhaka
 */
class StaffDAO extends DAO implements IStaffDAO{

    private $genderDAO;
    private $cityDAO;
    private $countryDAO;
    private $schoolDAO;
    private $personInfoDAO;

    //put your code here
    function __construct() {
        parent::__construct("Staff");
        $this->genderDAO = new GenderDAO("Gender");
        $this->cityDAO = new CityDAO("City");
        $this->countryDAO = new CountryDAO("Country");
        $this->schoolDAO = new SchoolDAO("School");
        $this->personInfoDAO = new PersonInfoDAO("PersonInfo");
    }

    public function size() {
        return count($this->getAll());
    }

    public function getAll() {
        $meta = $this->em->getClassMetadata(\entities\Staff::class);
        $tableName = $meta->getTableName();
        $datalist = $this->em->getConnection()->executeQuery("select * from " . $tableName)->fetchAll();
        return $datalist;
    }

    public function getAllValidated() {
        $query = $this->em->getRepository('entities\\' . $this->entity);
        return $query->findAll();
    }

    public function getAllValidatedWithSortAndOrder($sortProperty, $sortAsc) {
        $datalist = new ArrayCollection();
        $staffTable = $this->em->getClassMetadata(\entities\Staff::class)->getTableName();
        $personInfoTable = $this->em->getClassMetadata(\entities\PersonInfo::class)->getTableName();
        $genderTable = $this->em->getClassMetadata(\entities\Gender::class)->getTableName();
        $cityTable = $this->em->getClassMetadata(\entities\City::class)->getTableName();
        $countryTable = $this->em->getClassMetadata(\entities\Country::class)->getTableName();
        $schoolTable = $this->em->getClassMetadata(\entities\School::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT s.id AS sid,s.state AS ss,"
                . "s.validated AS sv,pi.id AS pid,pi.last_name,pi.first_name,pi.guardian_name,"
                . "pi.guardian_phone,pi.guardian_mail,pi.adress,pi.birth_date, "
                . "pi.matricule,pi.blood_group,pi.picture,pi.create_date,pi.gender_id,pi.city_id,pi.country_id,pi.school_id "
                . "FROM " . $staffTable . " s," . $personInfoTable . " pi," . $genderTable . " g,"
                . $cityTable . " ci," . $countryTable . " co," . $schoolTable . " sc "
                . "WHERE s.person_info_id = pi.id AND pi.gender_id = g.id "
                . "AND pi.city_id = ci.id AND pi.country_id = co.id "
                . "AND pi.school_id = sc.id AND ci.country_id = co.id AND s.state != 1 "
                . "ORDER BY pi.last_name,pi.first_name ASC");

        while ($row = $stmt->fetch()) {
            $gender = $this->genderDAO->getOne($row["gender_id"]);
            $birth_city = $this->cityDAO->getOne($row["city_id"]);
            $nationality = $this->countryDAO->getOne($row["country_id"]);
            $old_school = $this->schoolDAO->getOne($row["school_id"]);
            $personInfo = new \entities\PersonInfo($row["last_name"], $row["first_name"], $row["guardian_name"], $row["guardian_mail"], $row["guardian_phone"], $row["adress"], $row["birth_date"], $row["matricule"], $row["blood_group"], $row["picture"], $row["create_date"], $gender, $birth_city, $nationality, $old_school);
            $personInfo->setId($row["pid"]);
            $staff = new \entities\Staff($row["ss"], $row["sv"], $personInfo);
            $staff->setId($row["sid"]);
            $datalist->add($staff);
        }
        return $datalist;
    }

    public function getOne($pk) {
        $staffTable = $this->em->getClassMetadata(\entities\Staff::class)->getTableName();
        $personInfoTable = $this->em->getClassMetadata(\entities\PersonInfo::class)->getTableName();
        $genderTable = $this->em->getClassMetadata(\entities\Gender::class)->getTableName();
        $cityTable = $this->em->getClassMetadata(\entities\City::class)->getTableName();
        $countryTable = $this->em->getClassMetadata(\entities\Country::class)->getTableName();
        $schoolTable = $this->em->getClassMetadata(\entities\School::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT s.id AS sid,s.state AS ss,"
                . "s.validated AS sv,pi.id AS pid,pi.last_name,pi.first_name,pi.guardian_name,"
                . "pi.guardian_phone,pi.guardian_mail,pi.adress,pi.birth_date, "
                . "pi.matricule,pi.blood_group,pi.picture,pi.create_date,pi.gender_id,pi.city_id,pi.country_id,pi.school_id "
                . "FROM " . $staffTable . " s," . $personInfoTable . " pi," . $genderTable . " g,"
                . $cityTable . " ci," . $countryTable . " co," . $schoolTable . " sc "
                . "WHERE s.id = " . $pk . " AND s.person_info_id = pi.id AND pi.gender_id = g.id "
                . "AND pi.city_id = ci.id AND pi.country_id = co.id "
                . "AND pi.school_id = sc.id AND ci.country_id = co.id AND s.state != 1");

        $row = $stmt->fetch();
        $gender = $this->genderDAO->getOne($row["gender_id"]);
        $birth_city = $this->cityDAO->getOne($row["city_id"]);
        $nationality = $this->countryDAO->getOne($row["country_id"]);
        $old_school = $this->schoolDAO->getOne($row["school_id"]);
        $personInfo = new \entities\PersonInfo($row["last_name"], $row["first_name"], $row["guardian_name"], $row["guardian_mail"], $row["guardian_phone"], $row["adress"], $row["birth_date"], $row["matricule"], $row["blood_group"], $row["picture"], $row["create_date"], $gender, $birth_city, $nationality, $old_school);
        $personInfo->setId($row["pid"]);
        $staff = new \entities\Staff($row["ss"], $row["sv"], $personInfo);
        $staff->setId($row["sid"]);
        return $staff;
    }

    public function getAllForUsers() {
        $datalist = new ArrayCollection();
        $query_builder = $this->em->createQueryBuilder();
        $query_builder->select('s')
                ->from('entities\\Student', 's')
                ->leftjoin('s.person_info', 'pi')
                ->addSelect('s')
                ->leftjoin('pi.gender', 'g')
                ->addSelect('pi')
                ->leftjoin('pi.birth_city', 'ci')
                ->addSelect('pi')
                ->leftjoin('pi.nationality', 'c')
                ->addSelect('pi')
                ->leftjoin('pi.old_school', 'sc')
                ->addSelect('pi')
                ->leftjoin('ci.country','co')
                ->addSelect('ci')
                ;
//        $query_builder->select('ci')
//                ->from('entities\\City', 'ci')
//                ->leftjoin('ci.country','co')
//                ->addSelect('ci');
        
        print_r($query_builder->getQuery()->getSql());
        try {
            $datalist = $query_builder->getQuery()->getResult();
        } catch (NoResultException $ex) {
            echo $ex->getMessage();
        }
        return $datalist;
    }

     public function saveOne($object){
         $userTable = $this->em->getClassMetadata(\entities\Users::class)->getTableName();
        print_r($object[0]);
        $stmt = $this->em->getConnection()->query("INSERT INTO " . $paymentTable .
                "(student_id,fee_id,block_payment_id,academic_year_id,amount_paid,payment_date,state) "
                . "VALUES(" . $object[0] . "," . $object[1] . "," . $object[2] . "," . $object[3] . "," . $object[4] . ",'" . $object[5] . "'," . $object[6] . ")");
        $stmt->execute();
     }
}
