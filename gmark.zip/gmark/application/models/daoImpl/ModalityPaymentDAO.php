<?php

namespace daoImpl;

use dao\IModalityPaymentDAO,
    daoImpl\FeeDAO,
    daoImpl\FeeTypeDAO,
    daoImpl\LevelDAO,
    daoImpl\AcademicYearDAO,
    dmapimpl\DAO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once APPPATH . 'models/dao/IModalityPaymentDAO.php';
require_once APPPATH . 'models/daoImpl/FeeDAO.php';
require_once APPPATH . 'models/daoImpl/FeeTypeDAO.php';
require_once APPPATH . 'models/daoImpl/LevelDAO.php';
require_once APPPATH . 'models/daoImpl/AcademicYearDAO.php';
require_once APPPATH . 'third_party/dmap/dmapimpl/DAO.php';

/**
 * Description of ModalityPaymentDAO
 *
 * @author mundhaka
 */
class ModalityPaymentDAO extends DAO implements IModalityPaymentDAO {

    private $feeDAO;
    private $feeTypeDAO;
    private $classDAO;
    private $academicYearDAO;
    private $modalityPayment;

    function __construct() {
        parent::__construct("ModalityPayment");
        $this->feeDAO = new FeeDAO("Fee");
        $this->feeTypeDAO = new FeeTypeDAO("FeeType");
        $this->classDAO = new ClassesDAO();
        $this->academicYearDAO = new AcademicYearDAO("AcademicYear");
    }

    public function saveOne($object) {
        $modalityPaymentTable = $this->em->getClassMetadata(\entities\ModalityPayment::class)->getTableName();
        $this->em->getConnection()->query("INSERT INTO " . $modalityPaymentTable .
                "(fee_id,academic_year_id,dtype,delay,step_number,state) "
                . "VALUES(" . $object[0] . "," . $object[1] . ",'" . $object[2] . "',"
                . "'" . $object[3] . "'," . $object[4] . "," . $object[5] . ")");
    }

    public function getAllModality() {
        $datalist = new \Doctrine\Common\Collections\ArrayCollection();
        $modalityPaymentTable = $this->em->getClassMetadata(\entities\ModalityPayment::class)->getTableName();
        $feeTable = $this->em->getClassMetadata(\entities\Fee::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT m.id AS mid,m.dtype,m.step_number,m.delay,m.state AS ms,"
                . "f.id AS fid,f.amount,f.state AS fs, f.fee_type_id,f.academic_year_id,f.class_id "
                . "FROM " . $modalityPaymentTable . " m," . $feeTable . " f "
                . "WHERE m.fee_id = f.id AND m.state != 1 ");

        while ($row = $stmt->fetch()) {
            $fee_type = $this->feeTypeDAO->getOne($row["fee_type_id"]);
            $academic_year = $this->academicYearDAO->getOne($row["academic_year_id"]);
            $class = $this->classDAO->getOne($row["class_id"]);
            $fee = new \entities\Fee($row["amount"], $row["fs"], $academic_year, $fee_type, $class);
            $fee->setId($row["fid"]);
            $modalityPayment = new \entities\ModalityPayment($row["dtype"], $row["delay"], $row["step_number"], $row["fs"], $fee, $academic_year);
            $modalityPayment->setId($row["mid"]);
            $datalist->add($modalityPayment);
        }
        return $datalist;
    }

    public function getAllBlockPayment() {
        $datalist = new \Doctrine\Common\Collections\ArrayCollection();
        $modalityPaymentTable = $this->em->getClassMetadata(\entities\ModalityPayment::class)->getTableName();
        $feeTable = $this->em->getClassMetadata(\entities\Fee::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT m.id AS mid,m.dtype,m.step_number,m.delay,m.state AS ms,"
                . "f.id AS fid,f.amount,f.state AS fs, f.fee_type_id,f.academic_year_id,f.class_id "
                . "FROM " . $modalityPaymentTable . " m," . $feeTable . " f "
                . "WHERE m.fee_id = f.id AND m.state != 1 AND m.dtype = 'B' ");

        while ($row = $stmt->fetch()) {
            $fee_type = $this->feeTypeDAO->getOne($row["fee_type_id"]);
            $academic_year = $this->academicYearDAO->getOne($row["academic_year_id"]);
            $class = $this->classDAO->getOne($row["class_id"]);
            $fee = new \entities\Fee($row["amount"], $row["fs"], $academic_year, $fee_type, $class);
            $fee->setId($row["fid"]);
            $modalityPayment = new \entities\ModalityPayment($row["dtype"], $row["delay"], $row["step_number"], $row["fs"], $fee, $academic_year);
            $modalityPayment->setId($row["mid"]);
            $datalist->add($modalityPayment);
        }
        return $datalist;
    }

    public function getAllStepPayment() {
        $datalist = new \Doctrine\Common\Collections\ArrayCollection();
        $modalityPaymentTable = $this->em->getClassMetadata(\entities\ModalityPayment::class)->getTableName();
        $feeTable = $this->em->getClassMetadata(\entities\Fee::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT m.id AS mid,m.dtype,m.step_number,m.delay,m.state AS ms,"
                . "f.id AS fid,f.amount,f.state AS fs, f.fee_type_id,f.academic_year_id,f.class_id "
                . "FROM " . $modalityPaymentTable . " m," . $feeTable . " f "
                . "WHERE m.fee_id = f.id AND m.state != 1 AND m.dtype = 'S' ");

        while ($row = $stmt->fetch()) {
            $fee_type = $this->feeTypeDAO->getOne($row["fee_type_id"]);
            $academic_year = $this->academicYearDAO->getOne($row["academic_year_id"]);
            $class = $this->classDAO->getOne($row["class_id"]);
            $fee = new \entities\Fee($row["amount"], $row["fs"], $academic_year, $fee_type, $class);
            $fee->setId($row["fid"]);
            $modalityPayment = new \entities\ModalityPayment($row["dtype"], $row["delay"], $row["step_number"], $row["fs"], $fee, $academic_year);
            $modalityPayment->setId($row["mid"]);
            $datalist->add($modalityPayment);
        }
        return $datalist;
    }

    public function getOne($pk) {
        $modalityPaymentTable = $this->em->getClassMetadata(\entities\ModalityPayment::class)->getTableName();
        $feeTable = $this->em->getClassMetadata(\entities\Fee::class)->getTableName();
        $stmt = $this->em->getConnection()->query("SELECT m.id AS mid,m.dtype,m.step_number,m.delay,m.state AS ms,"
                . "f.id AS fid,f.amount,f.state AS fs, f.fee_type_id,f.academic_year_id,f.class_id "
                . "FROM " . $modalityPaymentTable . " m," . $feeTable . " f "
                . "WHERE m.fee_id = f.id AND m.state != 1 AND m.id = " . $pk);
        
        $row = $stmt->fetch();
        $fee_type = $this->feeTypeDAO->getOne($row["fee_type_id"]);
        $academic_year = $this->academicYearDAO->getOne($row["academic_year_id"]);
        $class = $this->classDAO->getOne($row["class_id"]);
        $fee = new \entities\Fee($row["amount"], $row["fs"], $academic_year, $fee_type, $class);
        $fee->setId($row["fid"]);
        $modalityPayment = new \entities\ModalityPayment($row["dtype"], $row["delay"], $row["step_number"], $row["fs"], $fee, $academic_year);
        $modalityPayment->setId($row["mid"]);
        return $modalityPayment;
    }

    public function deleteStateOneById($pk) {
        $modalityPaymentTable = $this->em->getClassMetadata(\entities\ModalityPayment::class)->getTableName();
        $this->em->getConnection()->query("UPDATE " . $modalityPaymentTable . " SET state = 1 WHERE id = " . $pk);
    }

    public function updateOneBlocModalityById($object, $pk) {
        $modalityPaymentTable = $this->em->getClassMetadata(\entities\ModalityPayment::class)->getTableName();
        $this->em->getConnection()->query("UPDATE " . $modalityPaymentTable . " SET delay = '" . $object[0] . "', "
                . "fee_id = " . $object[1] . ", state = 2 WHERE id = " . $pk);
    }
    
     public function updateOneStepModalityById($object, $pk) {
        $modalityPaymentTable = $this->em->getClassMetadata(\entities\ModalityPayment::class)->getTableName();
        $this->em->getConnection()->query("UPDATE " . $modalityPaymentTable . " SET delay = '" . $object[0] . "', "
                . "step_number = " . $object[1] .", fee_id = " . $object[2] . ", state = 2 WHERE id = " . $pk);
    }

}
