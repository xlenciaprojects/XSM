<?php
namespace dao;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mundhaka
 */
interface IStudentDAO {
    //put your code here
    public function size();
    
    public function getAll();
    
    public function getAllValidated();
    
    public function getAllValidatedWithSortAndOrder($sortProperty, $sortAsc);
    
    public function getOne($pk);
    
    public function saveOne($object);
    
    public function getAllForRegistration($acyId);
    
    public function getAllForRegistrationFeePayment($acyId);
    
    public function updateOneStudentById($object, $pk1, $pk2);
    
}
