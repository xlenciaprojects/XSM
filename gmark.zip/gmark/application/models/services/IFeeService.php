<?php

namespace services;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mundhaka
 */
interface IFeeService {

    //put your code here
    public function getAllByAcademicYear($pk);

    public function getOne($pk);
    
    public function deleteStateOneById($pk);

    public function updateOneFeeById($object, $pk);
}
