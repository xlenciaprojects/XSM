<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Person
 * @author mundhaka
 * @Entity
 * @InheritanceType("SINGLE_TABLE")
 * @DiscriminatorColumn(name="dtype", type="string")
 * @DiscriminatorMap({"Person" = "Person", "S" = "student", "P" = "staff"})
 * @Table(name="persons")
 * */
abstract class Person implements \Serializable {

     /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;
    
    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;

    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="validated")
     * */
    private $validated = 0;
    
    /**
     * @OneToOne(targetEntity="personinfo", inversedBy="person", fetch="EAGER", cascade={"persist", "remove", "merge","select"})
     * @JoinColumn(name="person_info_id", nullable=false, referencedColumnName="id")
     * */
    private $person_info;
    
    function __construct($state, $person_info) {
        $this->state = $state;
        $this->validated = 0;
        $this->person_info = $person_info;
    }
    function getId() {
        return $this->id;
    }

    function getState() {
        return $this->state;
    }

    function getValidated() {
        return $this->validated;
    }

    function getPerson_info() {
        return $this->person_info;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setState($state) {
        $this->state = $state;
    }

    function setValidated($validated) {
        $this->validated = $validated;
    }

    function setPerson_info($person_info) {
        $this->person_info = $person_info;
    }

        
        /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
