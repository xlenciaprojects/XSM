<?php

namespace entities;
    
use Doctrine\Common\Collections\ArrayCollection;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Student
 * @author mundhaka
 * @Entity
 * @Table(name="students")
 */
class Student implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;
    
    /**
     * @var integer
     * @Column(type="integer", nullable=false, name="validated")
     * */
    private $validated = 0;
    
    /**
     * @OneToOne(targetEntity="payment", mappedBy="student")
     * */
    private $payments;
    
    /**
     * @OneToOne(targetEntity="registration", mappedBy="student")
     * */
    private $students;

    /**
     * @OneToOne(targetEntity="personinfo", cascade={"persist", "remove", "merge"})
     * @JoinColumn(name="person_info_id", nullable=false, referencedColumnName="id")
     * */
    private $person_info;

    function __construct($state, $validated, $person_info) {
        $this->state = $state;
        $this->validated = $validated;
        $this->person_info = $person_info;
//        $this->payments = new ArrayCollection();
    }

    function getId() {
        return $this->id;
    }

    function getState() {
        return $this->state;
    }

    function getValidated() {
        return $this->validated;
    }

    function getPayments() {
        return $this->payments;
    }

    function getPerson_info() {
        return $this->person_info;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setState($state) {
        $this->state = $state;
    }

    function setValidated($validated) {
        $this->validated = $validated;
    }

    function setPayments($payments) {
        $this->payments = $payments;
    }

    function setPerson_info($person_info) {
        $this->person_info = $person_info;
    }
     
    public function __toString() {
        return $this->person_info->__toString();
    }

        /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
