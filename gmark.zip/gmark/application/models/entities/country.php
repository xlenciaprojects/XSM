<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * MappedSuperclass
 */

use Doctrine\Common\Collections\ArrayCollection;

/**
 * Country
 * @author mundhaka
 * @Entity
 * @Table(name="countries")
 */
class Country implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="wording")
     * */
    private $wording;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="short_wording")
     * */
    private $shortWording;

    /**
     * @var string
     * @Column(type="string", nullable=false, name="code")
     * */
    private $code;

    /**
     * @var string
     * @Column(type="string", nullable=false, name="nationality")
     * */
    private $nationality;

    /**
     * @OneToMany(targetEntity="city", mappedBy="country")
     * */
    private $cities;
    
     /**
     * @OneToMany(targetEntity="personinfo", mappedBy="nationality")
     * */
    private $person_infos;

    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;

    function __construct($wording, $shortWording, $code, $nationality, $state) {
        $this->wording = $wording;
        $this->shortWording = $shortWording;
        $this->code = $code;
        $this->nationality = $nationality;
        $this->state = $state;
        $this->person_infos = new ArrayCollection();
    }

    function getId() {
        return $this->id;
    }

    function getWording() {
        return $this->wording;
    }

    function getShortWording() {
        return $this->shortWording;
    }

    function getCode() {
        return $this->code;
    }

    function getNationality() {
        return $this->nationality;
    }

    function getCities() {
        return $this->cities;
    }

    function getPerson_infos() {
        return $this->person_infos;
    }

    function getState() {
        return $this->state;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setWording($wording) {
        $this->wording = $wording;
    }

    function setShortWording($shortWording) {
        $this->shortWording = $shortWording;
    }

    function setCode($code) {
        $this->code = $code;
    }

    function setNationality($nationality) {
        $this->nationality = $nationality;
    }

    function setCities($cities) {
        $this->cities = $cities;
    }

    function setPerson_infos($person_infos) {
        $this->person_infos = $person_infos;
    }

    function setState($state) {
        $this->state = $state;
    }

        
    public function __toString() {
        return $this->getWording();
    }

    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
