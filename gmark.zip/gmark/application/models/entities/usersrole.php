<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * MappedSuperclass
 */

//use Doctrine\Common\Collections\ArrayCollection;

/**
 * UsersRole
 * @author mundhaka
 * @Entity
 * @Table(name="usersroles")
 */
class UsersRole implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @ManyToOne(targetEntity="users", inversedBy="user_roles", fetch="EAGER")
     * @JoinColumn(name="users_id", nullable=false, referencedColumnName="id")
     * */
    private $users;
    
    /**
     * @ManyToOne(targetEntity="role", inversedBy="user_roles", fetch="EAGER")
     * @JoinColumn(name="role_id", nullable=false, referencedColumnName="id")
     * */
    private $role;
    
    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;

    function __construct($users, $role, $state) {
        $this->users = $users;
        $this->role = $role;
        $this->state = $state;
    }

    function getId() {
        return $this->id;
    }

    function getUsers() {
        return $this->users;
    }

    function getRole() {
        return $this->role;
    }

    function getState() {
        return $this->state;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setUsers($users) {
        $this->users = $users;
    }

    function setRole($role) {
        $this->role = $role;
    }

    function setState($state) {
        $this->state = $state;
    }

        public function __toString() {
        return $this->getId();
    }

    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
