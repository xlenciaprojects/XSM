<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * MappedSuperclass
 */

use Doctrine\Common\Collections\ArrayCollection;

/**
 * Permission
 * @author mundhaka
 * @Entity
 * @Table(name="permissions")
 */
class Permission implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="wording")
     * */
    private $wording;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="description")
     * */
    private $description;

    /**
     * @OneToMany(targetEntity="rolepermission", mappedBy="permission")
     * */
    private $role_permissions;

    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;

    function __construct($wording, $description, $state) {
        $this->wording = $wording;
        $this->description = $description;
        $this->role_permissions = new ArrayCollection();
        $this->state = $state;
    }
    function getId() {
        return $this->id;
    }

    function getWording() {
        return $this->wording;
    }

    function getDescription() {
        return $this->description;
    }

    function getRole_permissions() {
        return $this->role_permissions;
    }

    function getState() {
        return $this->state;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setWording($wording) {
        $this->wording = $wording;
    }

    function setDescription($description) {
        $this->description = $description;
    }

    function setRole_permissions($role_permissions) {
        $this->role_permissions = $role_permissions;
    }

    function setState($state) {
        $this->state = $state;
    }
    
    public function __toString() {
        return $this->getWording();
    }

    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
