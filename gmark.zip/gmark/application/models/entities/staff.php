<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Staff
 * @author mundhaka
 * @Entity
 * @Table(name="staffs")
 */
class Staff implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;
    
     /**
     * @var integer
     * @Column(type="integer", nullable=false, name="validated")
     * */
    private $validated = 0;

    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;

    /**
     * @OneToOne(targetEntity="personinfo", inversedBy="staff", fetch="EAGER", cascade={"persist", "remove", "merge"})
     * @JoinColumn(name="person_info_id", nullable=false, referencedColumnName="id")
     * */
    private $person_info;
    
    
    /**
     * @OneToOne(targetEntity="users", mappedBy="staff")
     * */
    private $users;
    
    function __construct($validated, $state, $person_info) {
        $this->validated = $validated;
        $this->state = $state;
        $this->person_info = $person_info;
    }

    function getId() {
        return $this->id;
    }

    function getValidated() {
        return $this->validated;
    }

    function getState() {
        return $this->state;
    }

    function getPerson_info() {
        return $this->person_info;
    }

    function getUsers() {
        return $this->users;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setValidated($validated) {
        $this->validated = $validated;
    }

    function setState($state) {
        $this->state = $state;
    }

    function setPerson_info($person_info) {
        $this->person_info = $person_info;
    }

    function setUsers($users) {
        $this->users = $users;
    }

        public function __toString() {
        return $this->person_info->__toString();
    }    
    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }


}
