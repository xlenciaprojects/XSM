<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * MappedSuperclass
 */

use Doctrine\Common\Collections\ArrayCollection;

/**
 * ModalityPayment
 * @author mundhaka
 * @Entity
 * @Table(name="modality_payments")
 */
class ModalityPayment implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="dtype")
     * */
    private $dtype;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="delay")
     * */
    private $delay;

    /**
     * @var integer
     * @Column(type="integer",nullable=false, name="step_number")
     * */
    private $stepNumber;

    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;

    /**
     * @ManyToOne(targetEntity="fee", inversedBy="modality_payments", fetch="EAGER")
     * @JoinColumn(name="fee_id", nullable=false, referencedColumnName="id")
     * */
    private $fee;

    /**
     * @ManyToOne(targetEntity="academicyear", inversedBy="modality_payments", fetch="EAGER")
     * @JoinColumn(name="academic_year_id", nullable=false, referencedColumnName="id")
     * */
    private $academic_year;

    /**
     * @OneToMany(targetEntity="payment", mappedBy="modality_payment")
     * */
    private $payments;

    function __construct($dtype, $delay, $stepNumber, $state, $fee, $academic_year) {
        $this->dtype = $dtype;
        $this->delay = $delay;
        $this->stepNumber = $stepNumber;
        $this->state = $state;
        $this->fee = $fee;
        $this->academic_year = $academic_year;
        $this->payments = new ArrayCollection();
    }

    function getId() {
        return $this->id;
    }

    function getDtype() {
        return $this->dtype;
    }

    function getDelay() {
        return $this->delay;
    }

    function getStepNumber() {
        return $this->stepNumber;
    }

    function getState() {
        return $this->state;
    }

    function getFee() {
        return $this->fee;
    }

    function getAcademic_year() {
        return $this->academic_year;
    }

    function getPayments() {
        return $this->payments;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setDtype($dtype) {
        $this->dtype = $dtype;
    }

    function setDelay($delay) {
        $this->delay = $delay;
    }

    function setStepNumber($stepNumber) {
        $this->stepNumber = $stepNumber;
    }

    function setState($state) {
        $this->state = $state;
    }

    function setFee($fee) {
        $this->fee = $fee;
    }

    function setAcademic_year($academic_year) {
        $this->academic_year = $academic_year;
    }

    function setPayments($payments) {
        $this->payments = $payments;
    }

    public function __toString() {
        if($this->stepNumber > 1){
            return $this->fee . " : " . $this->stepNumber . " tranche(s)";
        }
         return $this->fee." : bloc";
    }

    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
