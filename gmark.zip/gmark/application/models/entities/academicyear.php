<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace entities;

use Doctrine\Common\Collections\ArrayCollection;

/**
 * AcademicYear
 * @author mundhaka
 * @Entity
 * @Table(name="academicyears")
 */
class AcademicYear implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="wording")
     * */
    private $wording;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="code")
     * */
    private $code;

    /**
     * @var string
     * @Column(type="string",nullable=true, name="statut")
     * */
    private $current;

    /**
     * @var integer
     * @Column(type="integer", nullable=false, name="état")
     * */
    private $state = 0;

    /**
     * @OneToMany(targetEntity="fee", mappedBy="academic_year")
     * */
    private $fees;

    /**
     * @OneToMany(targetEntity="modalitypayment", mappedBy="academic_year")
     * */
    private $modality_payments;

    /**
     * @OneToMany(targetEntity="payment", mappedBy="academic_year")
     * */
    private $payments;

    /**
     * @OneToMany(targetEntity="payment", mappedBy="academic_year")
     * */
    private $registrations;

    function __construct($wording, $code, $current, $state) {
        $this->wording = $wording;
        $this->code = $code;
        $this->current = $current;
        $this->state = $state;
        $this->fees = new ArrayCollection();
        $this->modality_payments = new ArrayCollection();
        $this->payments = new ArrayCollection();
    }

    function getId() {
        return $this->id;
    }

    function getWording() {
        return $this->wording;
    }

    function getCode() {
        return $this->code;
    }

    function getCurrent() {
        return $this->current;
    }

    function getState() {
        return $this->state;
    }

    function getFees() {
        return $this->fees;
    }

    function getModality_payments() {
        return $this->modality_payments;
    }

    function getPayments() {
        return $this->payments;
    }

    function getRegistrations() {
        return $this->registrations;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setWording($wording) {
        $this->wording = $wording;
    }

    function setCode($code) {
        $this->code = $code;
    }

    function setCurrent($current) {
        $this->current = $current;
    }

    function setState($state) {
        $this->state = $state;
    }

    function setFees($fees) {
        $this->fees = $fees;
    }

    function setModality_payments($modality_payments) {
        $this->modality_payments = $modality_payments;
    }

    function setPayments($payments) {
        $this->payments = $payments;
    }

    function setRegistrations($registrations) {
        $this->registrations = $registrations;
    }

    public function __toString() {
        return $this->wording;
    }

    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
