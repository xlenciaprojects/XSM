<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * MappedSuperclass
 */

use Doctrine\Common\Collections\ArrayCollection;

/**
 * Fee
 * @author mundhaka
 * @Entity
 * @Table(name="fees")
 */
class Fee implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     * @Column(type="integer",nullable=false, name="amount")
     * */
    private $amount;

    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;

    /**
     * @ManyToOne(targetEntity="academicyear", inversedBy="fees", fetch="EAGER")
     * @JoinColumn(name="academic_year_id", nullable=false, referencedColumnName="id")
     * */
    private $academic_year;

    /**
     * @ManyToOne(targetEntity="feetype", inversedBy="fees", fetch="EAGER")
     * @JoinColumn(name="fee_type_id", nullable=false, referencedColumnName="id")
     * */
    private $fee_type;

    /**
     * @ManyToOne(targetEntity="classes", inversedBy="fees", fetch="EAGER")
     * @JoinColumn(name="class_id", nullable=false, referencedColumnName="id")
     * */
    private $classes;

    /**
     * @OneToMany(targetEntity="modalitypayment", mappedBy="fee")
     * */
    private $modality_payments;

    /**
     * @OneToMany(targetEntity="payment", mappedBy="fee")
     * */
    private $payments;

    function __construct($amount, $state, $academic_year, $fee_type, $classes) {
        $this->amount = $amount;
        $this->state = $state;
        $this->academic_year = $academic_year;
        $this->fee_type = $fee_type;
        $this->classes = $classes;
        $this->modality_payments = new ArrayCollection();
        $this->payments = new ArrayCollection();
    }

    function getId() {
        return $this->id;
    }

    function getAmount() {
        return $this->amount;
    }

    function getState() {
        return $this->state;
    }

    function getAcademic_year() {
        return $this->academic_year;
    }

    function getFee_type() {
        return $this->fee_type;
    }

    function getClasses() {
        return $this->classes;
    }

    function getModality_payments() {
        return $this->modality_payments;
    }

    function getPayments() {
        return $this->payments;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setAmount($amount) {
        $this->amount = $amount;
    }

    function setState($state) {
        $this->state = $state;
    }

    function setAcademic_year($academic_year) {
        $this->academic_year = $academic_year;
    }

    function setFee_type($fee_type) {
        $this->fee_type = $fee_type;
    }

    function setClasses($classes) {
        $this->classes = $classes;
    }

    function setModality_payments($modality_payments) {
        $this->modality_payments = $modality_payments;
    }

    function setPayments($payments) {
        $this->payments = $payments;
    }

    public function __toString() {
        return $this->classes . " - " . $this->fee_type->getWording();
    }

    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
