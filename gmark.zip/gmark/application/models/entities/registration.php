<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * MappedSuperclass
 */

//use Doctrine\Common\Collections\ArrayCollection;

/**
 * Registration
 * @author mundhaka
 * @Entity
 * @MappedSuperclass
 * @Table(name="registrations")
 */
class Registration implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="registration_date")
     * */
    private $registration_date;

    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;

    /**
     * @ManyToOne(targetEntity="student", inversedBy="payments", fetch="EAGER")
     * @JoinColumn(name="student_id", nullable=false, referencedColumnName="id")
     * */
    private $student;

    /**
     * @ManyToOne(targetEntity="academicyear", inversedBy="payments", fetch="EAGER")
     * @JoinColumn(name="academic_year_id", nullable=false, referencedColumnName="id")
     * */
    private $academic_year;
    
    function __construct($registration_date, $state, $student, $academic_year) {
        $this->registration_date = $registration_date;
        $this->state = $state;
        $this->student = $student;
        $this->academic_year = $academic_year;
    }

    function getId() {
        return $this->id;
    }

    function getRegistration_date() {
        return $this->registration_date;
    }

    function getState() {
        return $this->state;
    }

    function getStudent() {
        return $this->student;
    }

    function getAcademic_year() {
        return $this->academic_year;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setRegistration_date($registration_date) {
        $this->registration_date = $registration_date;
    }

    function setState($state) {
        $this->state = $state;
    }

    function setStudent($student) {
        $this->student = $student;
    }

    function setAcademic_year($academic_year) {
        $this->academic_year = $academic_year;
    }

        public function __toString() {
        return $this->student->__toString();
    }

    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
