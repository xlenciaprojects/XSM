<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * MappedSuperclass
 */

use Doctrine\Common\Collections\ArrayCollection;

/**
 * City
 * @author mundhaka
 * @Entity
 * @MappedSuperclass
 * @Table(name="cities")
 */
class City implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="wording")
     * */
    private $wording;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="description")
     * */
    private $description;

    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;

    /**
     * @ManyToOne(targetEntity="country", inversedBy="cities", fetch="EAGER")
     * @JoinColumn(name="country_id", nullable=false, referencedColumnName="id")
     * */
    private $country;
    
    /**
     * @OneToMany(targetEntity="personinfo", mappedBy="birth_city")
     * */
    private $person_infos;

    function __construct($wording, $description, $state, $country) {
        $this->wording = $wording;
        $this->description = $description;
        $this->state = $state;
        $this->country = $country;
        $this->person_infos = new ArrayCollection();
    }

    function getCountryWording() {
        return $this->getCountry()->getWording();
    }
    
    function getId() {
        return $this->id;
    }

    function getWording() {
        return $this->wording;
    }

    function getDescription() {
        return $this->description;
    }

    function getState() {
        return $this->state;
    }

    function getCountry() {
        return $this->country;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setWording($wording) {
        $this->wording = $wording;
    }

    function setDescription($description) {
        $this->description = $description;
    }

    function setState($state) {
        $this->state = $state;
    }

    function setCountry($country) {
        $this->country = $country;
    }
    
    public function __toString() {
        return $this->getWording();
    }

    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
