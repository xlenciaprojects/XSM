<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * MappedSuperclass
 */

use Doctrine\Common\Collections\ArrayCollection;

/**
 * StepPayment
 * @author mundhaka
 * @Entity
 * @MappedSuperclass
 * @Table(name="step_payments")
 */
class StepPayment implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     * @Column(type="string",nullable=false, name="delay")
     * */
    private $delay;
    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;
    
    /**
     * @OneToMany(targetEntity="payment", mappedBy="step_payment")
     * */
    private $payments;
    
    function __construct($delay, $state) {
        $this->delay = $delay;
        $this->state = $state;
        $this->payments = new ArrayCollection();
    }

    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
