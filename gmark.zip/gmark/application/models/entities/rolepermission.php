<?php

namespace entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * MappedSuperclass
 */

use Doctrine\Common\Collections\ArrayCollection;

/**
 * RolePermission
 * @author mundhaka
 * @Entity
 * @Table(name="rolepermissions")
 */
class RolePermission implements \Serializable {

    /**
     * @var int
     * @Id
     * @Column(type="integer",unique=true, nullable=false,name="id")
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @ManyToOne(targetEntity="permission", inversedBy="role_permissions", fetch="EAGER", cascade={"persist", "remove", "merge"})
     * @JoinColumn(name="permission_id", nullable=false, referencedColumnName="id")
     * */
    private $permission;
    
    /**
     * @ManyToOne(targetEntity="role", inversedBy="role_permissions", fetch="EAGER", cascade={"persist", "remove", "merge"})
     * @JoinColumn(name="role_id", nullable=false, referencedColumnName="id")
     * */
    private $role;
    
    /**
     * @var boolean
     * @Column(type="integer", nullable=false, name="state")
     * */
    private $state = 0;

    function __construct($permission, $role, $state) {
        $this->permission = $permission;
        $this->role = $role;
        $this->state = $state;
    }
    function getId() {
        return $this->id;
    }

    function getPermission() {
        return $this->permission;
    }

    function getRole() {
        return $this->role;
    }

    function getState() {
        return $this->state;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setPermission($permission) {
        $this->permission = $permission;
    }

    function setRole($role) {
        $this->role = $role;
    }

    function setState($state) {
        $this->state = $state;
    }
    
    public function __toString() {
        return $this->getId();
    }

    /**
     * @see \Serializable::serialize()
     */
    public function serialize() {
        return serialize(array(
            $this->id
        ));
    }

    /**
     * @see \Serializable::unserialize()
     */
    public function unserialize($serialized) {
        list (
                $this->id
                ) = unserialize($serialized);
    }

}
