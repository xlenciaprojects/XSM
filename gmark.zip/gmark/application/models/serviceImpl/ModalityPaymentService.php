<?php

namespace serviceImpl;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use services\IModalityPaymentService,
    daoImpl\ModalityPaymentDAO,
    dmapimpl\Service
;
use \Doctrine\Common\Collections\ArrayCollection;

require_once APPPATH . 'models/services/IModalityPaymentService.php';
require_once APPPATH . 'models/daoImpl/ModalityPaymentDAO.php';
require_once APPPATH . 'third_party/dmap/dmapimpl/Service.php';

/**
 * Description of ModalityPayment
 *
 * @author mundhaka
 */
class ModalityPaymentService extends Service implements IModalityPaymentService {

    private $modalityPaymentDAO;

    function __construct() {
        parent::__construct("ModalityPayment");
        $this->modalityPaymentDAO = new ModalityPaymentDAO();
    }

    public function saveOne($object){
        return $this->getModalityPaymentDAO()->saveOne($object);
    }
    
    public function getAllModality(){
        return $this->getModalityPaymentDAO()->getAllModality();
    }
    
    public function getAllBlockPayment() {
        return $this->getModalityPaymentDAO()->getAllBlockPayment();
    }

    public function getAllStepPayment() {
        return $this->getModalityPaymentDAO()->getAllStepPayment();
    }
    
    public function getOne($pk){
        return $this->getModalityPaymentDAO()->getOne($pk);
    }
    
    public function deleteStateOneById($pk){
        return $this->getModalityPaymentDAO()->deleteStateOneById($pk);
    }

    public function updateOneBlocModalityById($object, $pk){
        return $this->getModalityPaymentDAO()->updateOneBlocModalityById($object, $pk);
    }
    
    public function updateOneStepModalityById($object, $pk){
        return $this->getModalityPaymentDAO()->updateOneStepModalityById($object, $pk);
    }
    
    function getModalityPaymentDAO() {
        return $this->modalityPaymentDAO;
    }

    function setModalityPaymentDAO($modalityPaymentDAO) {
        $this->modalityPaymentDAO = $modalityPaymentDAO;
    }

}
