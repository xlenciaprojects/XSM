<?php

namespace serviceImpl;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use services\IFeeService,
    daoImpl\FeeDAO,
    dmapimpl\Service;

require APPPATH . 'models/services/IFeeService.php';
require_once APPPATH . 'third_party/dmap/dmapimpl/Service.php';

/**
 * Description of GenderServiceImpl
 *
 * @author mundhaka
 */
class FeeService extends Service implements IFeeService {

    //put your code here
    private $feeDAO;

    function __construct() {
        parent::__construct("Fee");
        $this->feeDAO = new FeeDAO();
    }

    public function getAllByAcademicYear($pk) {
        return $this->getFeeDAO()->getAllByAcademicYear($pk);
    }

    public function getOne($pk) {
         return $this->getFeeDAO()->getOne($pk);
    }
    
    public function deleteStateOneById($pk){
        return $this->getFeeDAO()->deleteStateOneById($pk);
    }

    public function updateOneFeeById($object, $pk){
        return $this->getFeeDAO()->updateOneFeeById($object, $pk);
    }
    
    function getFeeDAO() {
        return $this->feeDAO;
    }

    function setFeeDAO($feeDAO) {
        $this->feeDAO = $feeDAO;
    }

}
