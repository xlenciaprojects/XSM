<?php

namespace serviceImpl;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use services\IStudentService,
    daoImpl\StudentDAO,
    dmapimpl\Service;
//use \Doctrine\Common\Collections\ArrayCollection;

require_once APPPATH . 'models/services/IStudentService.php';
require_once APPPATH . 'models/serviceImpl/PersonInfoService.php';
require_once APPPATH . 'models/daoImpl/StudentDAO.php';
require_once APPPATH . 'third_party/dmap/dmapimpl/Service.php';

/**
 * Description of GenderServiceImpl
 *
 * @author mundhaka
 */
class StudentService extends Service implements IStudentService {

    //put your code here
    private $studentDAO;

    function __construct() {
        parent::__construct("Student");
        $this->studentDAO = new StudentDAO();
    }

    public function size() {
        return $this->getStudentDAO()->size();
    }

    public function getAll() {
        return $this->getStudentDAO()->getAll();
    }

    public function getAllValidated() {
        return $this->getStudentDAO()->getAllValidated();
    }

    public function getAllValidatedWithSortAndOrder($sortProperty, $sortAsc) {
        return $this->getStudentDAO()->getAllValidatedWithSortAndOrder($sortProperty, $sortAsc);
    }

    public function getOne($pk) {
        return $this->getStudentDAO()->getOne($pk);
    }

    public function getAllForRegistration($acyId) {
        return $this->getStudentDAO()->getAllForRegistration($acyId);
    }
    
    public function getAllForRegistrationFeePayment($acyId){
        return $this->getStudentDAO()->getAllForRegistrationFeePayment($acyId);
    }

    public function deleteStateOneById($pk) {
        return $this->getStudentDAO()->deleteStateOneById($pk);
    }
    
    public function updateOneStudentById($object, $pk1, $pk2){
        return $this->getStudentDAO()->updateOneStudentById($object, $pk1, $pk2);
    }
    
    function getStudentDAO() {
        return $this->studentDAO;
    }

    function setStudentDAO($studentDAO) {
        $this->studentDAO = $studentDAO;
    }

}
