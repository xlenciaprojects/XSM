<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace serviceImpl;

use services\ISchoolService,
        dmapimpl\Service;

require APPPATH . 'models/services/ISchoolService.php';
require_once APPPATH.'third_party/dmap/dmapimpl/Service.php';

/**
 * Description of GenderServiceImpl
 *
 * @author mundhaka
 */
class SchoolService extends Service implements ISchoolService{
    //put your code here
}