<?php
namespace serviceImpl;

use services\IUsersService,
    dmapimpl\Service,
    daoImpl\UsersDAO;


require_once APPPATH.'third_party/dmap/dmapimpl/Service.php';
require_once APPPATH . 'models/services/IUsersService.php';
require_once APPPATH . 'models/daoImpl/UsersDAO.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AgenceService
 *
 * @author Mick El
 */
class UsersService extends Service implements IUsersService{
    
     private $usersDAO;

    function __construct($entity) {
        parent::__construct($entity);
        $this->usersDAO = new UsersDAO($entity);
    }

    public function getOne($object) {
        return $this->usersDAO->getOne($object);
    }
    public function saveAll($objects) {
        return $this->usersDAO->saveAll($objects);
    }

    public function saveOne($object) {
        return $this->usersDAO->saveOne($object);
    }
    
    function getUsersDAO() {
        return $this->usersDAO;
    }

    function setUsersDAO($usersDAO) {
        $this->usersDAO = $usersDAO;
    }

}
