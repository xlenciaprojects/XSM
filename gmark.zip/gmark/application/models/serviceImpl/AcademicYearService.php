<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace serviceImpl;

use services\IAcademicYearService,
    dmapimpl\Service
//    dao\IAcademicYearDAO,
//    daoImpl\AcademicYearDAO
        ;

require_once APPPATH . 'models/services/IAcademicYearService.php';
//require_once APPPATH . 'models/daoImpl/AcademicYearDAO.php';
require_once APPPATH.'third_party/dmap/dmapimpl/Service.php';
/**
 * Description of AcademicYear
 *
 * @author mundhaka
 */
class AcademicYearService extends Service implements IAcademicYearService {
    
    function __construct() {
        parent::__construct("AcademicYear");
    }

    public function activated($pk) {
        $this->getDao()->activated($pk);
    }

    public function desactivated($pk) {
        $this->getDao()->desactivated($pk);
    }

    public function getActivated() {
        return $this->getDao()->getActivated();
    }

    public function getCurrent() {
        $this->getDao()->getCurrent();
    }

}
