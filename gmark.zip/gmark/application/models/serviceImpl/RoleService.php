<?php
namespace serviceImpl;

use services\IRoleService,
        dmapimpl\Service;

require_once APPPATH . 'models/services/IRoleService.php';
require_once APPPATH.'third_party/dmap/dmapimpl/Service.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AgenceService
 *
 * @author Mick El
 */
class RoleService extends Service implements IRoleService{
    //put your code here
}
